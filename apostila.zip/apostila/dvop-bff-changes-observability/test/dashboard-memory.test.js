// Forces in-memory upload mode (no writable folder) to exercise the memory-store
// code paths in the dashboard route. The config object is mutated before the app
// is imported; this file runs in its own process, so it does not affect others.
import { describe, it, afterEach } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';
process.env.BASE_PATH = '/painel';

const { config } = await import('../src/config/env.js');
config.HAS_PERSISTENT_UPLOADS = false;
config.UPLOAD_FOLDER = null;

const { default: app } = await import('../src/app.js');
const { sharedDashboardState } = await import('../src/services/state.js');
const request = (await import('supertest')).default;
const nock = (await import('nock')).default;

const API = 'https://api.github.com';

async function authedAgent() {
  const agent = request.agent(app);
  nock(API).get('/user').reply(200, { login: 'octocat' });
  const res = await agent.post('/painel/set-token').send({ token: 'ghp_validtoken1234567890' });
  assert.equal(res.status, 200);
  return agent;
}

describe('dashboard (in-memory uploads)', () => {
  afterEach(() => nock.cleanAll());

  it('stores an uploaded CSV in memory and renders from it', async () => {
    const agent = await authedAgent();
    const csv = 'parent,planned_start_date,description\nCHGM,2026-06-19 10:00,nourl';
    const up = await agent.post('/painel/').attach('csv_file', Buffer.from(csv), 'mem.csv');
    assert.equal(up.status, 302);

    const res = await agent.get('/painel/');
    assert.equal(res.status, 200);
    assert.match(res.text, /Acompanhamento de Changes/);
  });

  it('selects an in-memory CSV', async () => {
    sharedDashboardState.memoryCsvStore.set(
      'manual.csv',
      'parent,planned_start_date,description\nCHGN,2026-06-19 09:00,nourl',
    );
    const agent = await authedAgent();
    const res = await agent.get('/painel/?csv=manual.csv');
    assert.equal(res.status, 200);
    assert.match(res.text, /Acompanhamento de Changes/);
  });
});
