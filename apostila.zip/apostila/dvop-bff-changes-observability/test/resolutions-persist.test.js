import { describe, it, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

// Mesmo padrão de state-persist.test.js: prepara o DATA_DIR e semeia o arquivo
// ANTES de importar o módulo, porque a carga do disco acontece no import.
process.env.NODE_ENV = 'test';
const DATA_DIR = path.join(os.tmpdir(), 'dvop-resolutions-persist-test');
fs.rmSync(DATA_DIR, { recursive: true, force: true });
fs.mkdirSync(DATA_DIR, { recursive: true });
process.env.DATA_DIR = DATA_DIR;

const FILE = path.join(DATA_DIR, 'resolutions.json');
fs.writeFileSync(
  FILE,
  JSON.stringify({
    'id-existente': {
      id: 'id-existente',
      signature: 'sig-do-disco',
      repository: 'org/repo',
      category: 'permission',
      solution: 'resolução que já estava no volume',
      createdAt: '2026-08-01T00:00:00.000Z',
    },
  }),
);

const { findResolutions, addResolution } = await import('../src/services/resolutions.js');

describe('catálogo de resoluções — persistência entre reinícios', () => {
  after(() => fs.rmSync(DATA_DIR, { recursive: true, force: true }));

  it('carrega o que já estava no volume ao subir', () => {
    const achados = findResolutions({ signature: 'sig-do-disco', repository: 'org/repo' });
    assert.equal(achados.length, 1);
    assert.equal(achados[0].solution, 'resolução que já estava no volume');
  });

  it('acrescenta ao arquivo sem perder o que havia', () => {
    addResolution({ signature: 'sig-nova', repository: 'org/repo', solution: 'nova resolução' });
    const emDisco = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    assert.equal(Object.keys(emDisco).length, 2);
    assert.equal(emDisco['id-existente'].solution, 'resolução que já estava no volume');
  });
});
