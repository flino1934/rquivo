import { describe, it, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

// Configure env vars BEFORE importing any module under test so env.js picks
// them up at load time (same pattern used in state-persist.test.js).
process.env.NODE_ENV = 'test';
const UPLOAD_FOLDER = path.join(os.tmpdir(), 'dvop-cleanup-test');
fs.rmSync(UPLOAD_FOLDER, { recursive: true, force: true });
fs.mkdirSync(UPLOAD_FOLDER, { recursive: true });
process.env.UPLOAD_FOLDER = UPLOAD_FOLDER;
process.env.UPLOAD_RETENTION_DAYS = '30';

const { pruneOldUploads } = await import('../src/services/cleanup.js');
const { sharedDashboardState } = await import('../src/services/state.js');

// Write a CSV file to the temp folder with its mtime set to `daysAgo` days in
// the past. Returns the full file path.
function makeFile(name, daysAgo) {
  const filePath = path.join(UPLOAD_FOLDER, name);
  fs.writeFileSync(filePath, 'col_a,col_b\n1,2');
  const mtime = new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000);
  fs.utimesSync(filePath, mtime, mtime);
  return filePath;
}

describe('pruneOldUploads', () => {
  after(() => fs.rmSync(UPLOAD_FOLDER, { recursive: true, force: true }));

  it('removes files older than the retention period', () => {
    const old = makeFile('2020-01-01__00-00_expired.csv', 31);
    const { removed } = pruneOldUploads();
    assert.ok(removed >= 1, 'at least one file should be removed');
    assert.equal(fs.existsSync(old), false, 'expired file must be deleted');
  });

  it('keeps files within the retention period', () => {
    const recent = makeFile('2026-06-21__10-00_recent.csv', 1);
    pruneOldUploads();
    assert.equal(fs.existsSync(recent), true, 'recent file must be kept');
    fs.unlinkSync(recent);
  });

  it('skips the currently active CSV even when expired', () => {
    const active = makeFile('2020-01-01__00-00_active.csv', 40);
    sharedDashboardState.activeCsvName = '2020-01-01__00-00_active.csv';
    pruneOldUploads();
    assert.equal(fs.existsSync(active), true, 'active file must not be deleted');
    sharedDashboardState.activeCsvName = null;
    fs.unlinkSync(active);
  });

  it('remove também arquivos que não são CSV — uploads rejeitados envelhecem igual', () => {
    const orfao = makeFile('2020-01-01__00-00_bad.txt', 45);
    const { removed } = pruneOldUploads();
    assert.ok(removed >= 1);
    assert.equal(fs.existsSync(orfao), false, 'órfão antigo deve ser apagado');
  });

  it('preserva .gitkeep e annotations.json por mais antigos que sejam', () => {
    const gitkeep = makeFile('.gitkeep', 400);
    const anotacoes = makeFile('annotations.json', 400);
    pruneOldUploads();
    assert.equal(fs.existsSync(gitkeep), true, '.gitkeep deve sobreviver');
    assert.equal(fs.existsSync(anotacoes), true, 'annotations.json deve sobreviver');
    fs.unlinkSync(gitkeep);
    fs.unlinkSync(anotacoes);
  });

  it('não tenta apagar diretórios', () => {
    const dir = path.join(UPLOAD_FOLDER, 'subpasta');
    fs.mkdirSync(dir, { recursive: true });
    const antiga = new Date(Date.now() - 400 * 24 * 60 * 60 * 1000);
    fs.utimesSync(dir, antiga, antiga);
    const { errors } = pruneOldUploads();
    assert.equal(errors, 0);
    assert.equal(fs.existsSync(dir), true, 'diretório deve ser ignorado');
    fs.rmSync(dir, { recursive: true, force: true });
  });

  it('returns { removed: 0, errors: 0 } when the folder is empty', () => {
    const result = pruneOldUploads();
    assert.deepEqual(result, { removed: 0, errors: 0 });
  });
});
