import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

const { buildExportWorkbook, exportFilename } = await import('../src/services/export.js');

describe('buildExportWorkbook', () => {
  it('builds a workbook mapping every status symbol', async () => {
    const rows = [
      {
        index: 1,
        CHANGE: 'A',
        HORARIO: '2026-06-19 10:00:00',
        url: 'https://github.com/o/r/actions/runs/1',
        status: 'Success',
        rerunChecked: true,
        comment: 'ok',
      },
      { index: 2, CHANGE: 'B', status: 'Failure' },
      { index: 3, status: 'Waiting' },
      { index: 4, status: 'Cancelled' },
      { index: 5, status: 'Whatever' },
      { index: 6 },
    ];
    const wb = buildExportWorkbook(rows);
    const buf = await wb.xlsx.writeBuffer();
    assert.ok(buf.length > 0);
  });
});

describe('exportFilename', () => {
  it('produces a timestamped xlsx filename', () => {
    assert.match(exportFilename(), /^painel_export_\d+\.xlsx$/);
  });
});
