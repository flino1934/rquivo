// Exercises the Redis session-store branch in app.js: when REDIS_URL is set but
// the client cannot be created, the app must fall back to the in-memory store.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';
process.env.BASE_PATH = '/painel';
process.env.REDIS_URL = 'http://invalid-redis-url';

const { default: app } = await import('../src/app.js');
const request = (await import('supertest')).default;

describe('redis session store fallback', () => {
  it('falls back to MemoryStore when Redis init fails', async () => {
    const res = await request(app).get('/painel/healthz');
    assert.equal(res.status, 200);
  });
});
