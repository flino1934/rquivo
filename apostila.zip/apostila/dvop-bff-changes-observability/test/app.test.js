import { describe, it, afterEach } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';
process.env.BASE_PATH = '/painel';

const { default: app } = await import('../src/app.js');
const request = (await import('supertest')).default;
const nock = (await import('nock')).default;

describe('health endpoints', () => {
  it('GET /healthz returns 200', async () => {
    const res = await request(app).get('/healthz');
    assert.equal(res.status, 200);
    assert.equal(res.body.status, 'ok');
  });

  it('GET /painel/healthz returns 200', async () => {
    const res = await request(app).get('/painel/healthz');
    assert.equal(res.status, 200);
    assert.equal(res.body.status, 'ok');
  });
});

describe('dashboard root', () => {
  it('GET /painel/ renders the token-setup page when no token is configured', async () => {
    const res = await request(app).get('/painel/');
    assert.equal(res.status, 200);
    assert.match(res.headers['content-type'] || '', /text\/html/);
  });

  it('GET /painel/api/workflow-data returns 401 without a token', async () => {
    const res = await request(app).get('/painel/api/workflow-data');
    assert.equal(res.status, 401);
  });
});

describe('dashboard annotations', () => {
  it('rejects a request without a url', async () => {
    const res = await request(app).post('/painel/api/dashboard-annotation').send({ comment: 'hi' });
    assert.equal(res.status, 400);
  });

  it('stores a comment annotation', async () => {
    const url = 'https://github.com/owner/repo/actions/runs/999';
    const res = await request(app)
      .post('/painel/api/dashboard-annotation')
      .send({ url, comment: 'check this' });
    assert.equal(res.status, 200);
    assert.equal(res.body.success, true);
    assert.equal(res.body.annotation.comment, 'check this');
  });
});

describe('set-token', () => {
  afterEach(() => nock.cleanAll());

  it('rejects an invalid token format', async () => {
    const res = await request(app).post('/painel/set-token').send({ token: 'invalid token' });
    assert.equal(res.status, 400);
  });

  it('accepts a valid token verified against GitHub', async () => {
    nock('https://api.github.com').get('/user').reply(200, { login: 'octocat' });
    const res = await request(app).post('/painel/set-token').send({ token: 'ghp_validtoken1234567890' });
    assert.equal(res.status, 200);
    assert.equal(res.body.success, true);
  });
});

describe('xlsx export', () => {
  it('rejects an empty export', async () => {
    const res = await request(app).post('/painel/export/xlsx').send({ rows: [] });
    assert.equal(res.status, 400);
  });

  it('returns an xlsx workbook for provided rows', async () => {
    const rows = [
      {
        index: 1,
        CHANGE: 'CHG1',
        HORARIO: '2025-10-21 14:30:00',
        url: 'https://github.com/o/r/actions/runs/1',
        status: 'Success',
        rerunChecked: true,
        comment: 'ok',
      },
    ];
    const res = await request(app).post('/painel/export/xlsx').send({ rows });
    assert.equal(res.status, 200);
    assert.match(res.headers['content-type'] || '', /spreadsheetml/);
  });
});
