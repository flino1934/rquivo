import { describe, it, before, after, afterEach } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';
process.env.BASE_PATH = '/painel';

// Set before importing the app: the config snapshots process.env at import time.
process.env.AGENTIX_BASE_URL = 'https://agentix.example.com/v2/api';
process.env.AGENTIX_TENANT_ID = 'DVOP';
process.env.AGENTIX_TOKEN = 'tok-estatico';
process.env.AGENTIX_ENTITY_NAME = 'changes-observability-agent';
process.env.AGENTIX_BUNDLE = 'dvop-agx-ssol-changes-observability';
process.env.AGENTIX_ENTITY_VERSION = '0.1.0';

const { default: app } = await import('../src/app.js');
const request = (await import('supertest')).default;
const nock = (await import('nock')).default;

const API = 'https://api.github.com';
const AGENTIX = 'https://agentix.example.com';
const TOKEN = 'ghp_validtoken1234567890';
const RUN_URL = 'https://github.com/owner/repo/actions/runs/123';
const JOBS_PATH = '/repos/owner/repo/actions/runs/123/jobs';

async function authedAgent() {
  const agent = request.agent(app);
  nock(API).get('/user').reply(200, { login: 'octocat' });
  const res = await agent.post('/painel/set-token').send({ token: TOKEN });
  assert.equal(res.status, 200);
  return agent;
}

describe('POST /api/agentix-analyze (integração configurada)', () => {
  // supertest levanta o app num socket local, que precisa continuar acessível.
  before(() => nock.disableNetConnect() || nock.enableNetConnect('127.0.0.1'));
  after(() => nock.enableNetConnect());
  afterEach(() => nock.cleanAll());

  it('baixa os logs da execução, chama a AgentiX e devolve a análise', async () => {
    const agent = await authedAgent();

    const jobs = {
      jobs: [
        {
          id: 2,
          name: 'test',
          workflow_name: 'Deploy',
          conclusion: 'failure',
          steps: [{ name: 'npm test', conclusion: 'failure' }],
        },
      ],
    };
    // getFailureContext lê o endpoint de jobs uma única vez.
    nock(API).get(JOBS_PATH).reply(200, jobs);
    nock(API)
      .get('/repos/owner/repo/actions/jobs/2/logs')
      .reply(200, `Error: assertion failed
token=ghp_abcdefghijklmnopqrstuvwxyz012345`);

    const resposta = {
      status: 'analyzed',
      category: 'test',
      confidence: 'high',
      summary: 'A suíte de testes quebrou.',
      root_cause: 'Uma asserção falhou.',
      evidence: [{ line: 'Error: assertion failed', why: 'é a primeira falha real' }],
      suggested_actions: ['Rodar npm test localmente.'],
      affected_components: ['test'],
    };

    nock(AGENTIX)
      .post('/v2/api/sessions/invoke', (body) => {
        const request = JSON.parse(body.payload.input);
        assert.equal(request.repository, 'owner/repo');
        assert.equal(request.workflow, 'Deploy');
        assert.equal(request.run_id, '123');
        assert.match(request.logs, /Error: assertion failed/);
        // Segredo que apareceu no log bruto não pode sair daqui.
        assert.ok(!request.logs.includes('ghp_abcdefghijklmnopqrstuvwxyz012345'));
        assert.equal(body.bundle, 'dvop-agx-ssol-changes-observability');
        assert.equal(body.entity_name, 'changes-observability-agent');
        return true;
      })
      .reply(200, { session_id: 'sess-9', status: 'CREATED' });
    nock(AGENTIX).get('/v2/api/sessions/sess-9').reply(200, { state: 'DONE' });
    // A resposta não vem no detalhe da sessão: vive em /artifacts.partial_output.
    nock(AGENTIX).get('/v2/api/sessions/sess-9/artifacts').reply(200, { partial_output: resposta });

    const res = await agent.post('/painel/api/agentix-analyze').send({ url: RUN_URL, change: 'CHG1', status: 'Failure' });
    assert.equal(res.status, 200);
    assert.equal(res.body.analysis.summary, 'A suíte de testes quebrou.');
    assert.equal(res.body.analysis.category, 'test');
    assert.equal(res.body.sessionId, 'sess-9');
  });

  it('registra a resolução e a devolve na próxima análise da mesma falha', async () => {
    const agent = await authedAgent();

    const jobs = { jobs: [{ id: 2, name: 'test', workflow_name: 'Deploy', conclusion: 'failure' }] };
    const resposta = {
      status: 'analyzed',
      category: 'permission',
      summary: 'Key Vault negou a leitura do segredo.',
      root_cause: 'O service principal não tem secrets get.',
      evidence: [{ line: "##[error]does not have secrets get permission on key vault 'kv001'", why: 'primeira falha' }],
      suggested_actions: ['Conceder a permissão.'],
    };

    // 1ª análise: catálogo vazio, nada relacionado.
    nock(API).get(JOBS_PATH).reply(200, jobs);
    nock(API).get('/repos/owner/repo/actions/jobs/2/logs').reply(200, 'ERROR: negado');
    nock(AGENTIX).post('/v2/api/sessions/invoke').reply(200, { session_id: 'sess-r1' });
    nock(AGENTIX).get('/v2/api/sessions/sess-r1').reply(200, { state: 'DONE' });
    nock(AGENTIX).get('/v2/api/sessions/sess-r1/artifacts').reply(200, { partial_output: resposta });

    const primeira = await agent.post('/painel/api/agentix-analyze').send({ url: RUN_URL, change: 'CHG1' });
    assert.equal(primeira.status, 200);
    assert.deepEqual(primeira.body.related, []);
    assert.ok(primeira.body.signature, 'a análise deve produzir uma assinatura');

    // Registra o que resolveu. A causa vai igual à da IA => feedback positivo.
    nock(AGENTIX).post('/v2/api/sessions/sess-r1/feedback', (b) => b.feedback === 'positive').reply(200, {});
    const salvo = await agent.post('/painel/api/resolutions').send({
      url: RUN_URL,
      change: 'CHG1',
      signature: primeira.body.signature,
      category: resposta.category,
      problem: resposta.summary,
      cause: resposta.root_cause,
      agentCause: resposta.root_cause,
      repository: primeira.body.repository,
      solution: 'Concedida a permissão secrets get ao SPN.',
      sessionId: 'sess-r1',
    });
    assert.equal(salvo.status, 200);
    assert.equal(salvo.body.resolution.author, 'octocat');

    // 2ª análise da mesma falha: a resolução anterior vem junto.
    nock(API).get(JOBS_PATH).reply(200, jobs);
    nock(API).get('/repos/owner/repo/actions/jobs/2/logs').reply(200, 'ERROR: negado de novo');
    nock(AGENTIX).post('/v2/api/sessions/invoke').reply(200, { session_id: 'sess-r2' });
    nock(AGENTIX).get('/v2/api/sessions/sess-r2').reply(200, { state: 'DONE' });
    nock(AGENTIX).get('/v2/api/sessions/sess-r2/artifacts').reply(200, { partial_output: resposta });

    const segunda = await agent.post('/painel/api/agentix-analyze').send({ url: RUN_URL, change: 'CHG2' });
    assert.equal(segunda.body.related.length, 1);
    assert.equal(segunda.body.related[0].solution, 'Concedida a permissão secrets get ao SPN.');
    assert.equal(segunda.body.related[0].match, 'exact');
  });

  it('recusa uma resolução sem descrição do que resolveu', async () => {
    const agent = await authedAgent();
    const res = await agent.post('/painel/api/resolutions').send({ url: RUN_URL, solution: '   ' });
    assert.equal(res.status, 400);
    assert.match(res.body.error, /o que resolveu/i);
  });

  it('rejeita uma url de execução inválida', async () => {
    const agent = await authedAgent();
    const res = await agent.post('/painel/api/agentix-analyze').send({ url: 'https://example.com/qualquer' });
    assert.equal(res.status, 400);
    assert.match(res.body.error, /url de execução inválida/);
  });

  it('devolve 502 quando a AgentiX falha, sem derrubar a requisição', async () => {
    const agent = await authedAgent();
    nock(API).get(JOBS_PATH).reply(200, { jobs: [] });
    nock(AGENTIX).post('/v2/api/sessions/invoke').reply(500, { detail: 'boom' });

    const res = await agent.post('/painel/api/agentix-analyze').send({ url: RUN_URL });
    assert.equal(res.status, 502);
    assert.match(res.body.error, /Falha ao analisar na AgentiX/);
  });
});
