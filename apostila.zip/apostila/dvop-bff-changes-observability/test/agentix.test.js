import { describe, it, before, after, afterEach } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';

// Configured before importing the app config, which snapshots process.env once.
process.env.AGENTIX_BASE_URL = 'https://agentix.example.com/v2/api';
process.env.AGENTIX_TENANT_ID = 'DVOP';
process.env.AGENTIX_KEYCLOAK_URL = 'https://agentix.example.com:444/realms/Omega-AGX';
process.env.AGENTIX_CLIENT_ID = 'agx-front';
process.env.AGENTIX_USERNAME = 'u123456';
process.env.AGENTIX_PASSWORD = 'segredo';
process.env.AGENTIX_ENTITY_TYPE = 'agent';
process.env.AGENTIX_ENTITY_NAME = 'analise-falha-pipeline';
process.env.AGENTIX_ENTITY_VERSION = '1.0.0';
process.env.AGENTIX_BUNDLE = 'changes-observability';

const { buildFailureAnalysisPayload, formatFailedLogs, maskSecrets, parseAnalysis } = await import('../src/services/agentixPayload.js');
const { trimLogTail, getFailedJobLogs } = await import('../src/services/github.js');
const agentix = await import('../src/services/agentixClient.js');
const nock = (await import('nock')).default;

const API = 'https://api.github.com';
const JOBS_PATH = '/repos/owner/repo/actions/runs/123/jobs';
const AGENTIX = 'https://agentix.example.com';
const KEYCLOAK_PATH = '/realms/Omega-AGX/protocol/openid-connect/token';

// Quebra de linha como constante: evita escapes dentro dos casos de teste.
const NL = String.fromCharCode(10);

describe('trimLogTail', () => {
  it('remove o timestamp ISO que o GitHub prefixa em cada linha', () => {
    const raw = '2026-08-19T12:00:00.1234567Z npm ERR! code ELIFECYCLE';
    assert.equal(trimLogTail(raw), 'npm ERR! code ELIFECYCLE');
  });

  it('devolve o log inteiro quando ele cabe no orçamento', () => {
    const raw = Array.from({ length: 500 }, (_, i) => `linha ${i}`).join(NL);
    const out = trimLogTail(raw);
    assert.ok(!out.includes('omitido'));
    assert.match(out, /^linha 0/);
    assert.match(out, /linha 499$/);
  });

  it('preserva a PRIMEIRA falha, não só o final, quando precisa cortar', () => {
    const raw = [
      ...Array.from({ length: 200 }, (_, i) => `setup ruidoso ${i}`),
      '##[error]a causa real da falha',
      ...Array.from({ length: 400 }, (_, i) => `consequencia ${i}`),
    ].join(NL);
    // Orçamento menor que o log inteiro, mas suficiente a partir do erro.
    const out = trimLogTail(raw, 6_000);
    assert.match(out, /##\[error\]a causa real da falha/);
    assert.match(out, /trecho do log omitido/);
    // O setup anterior ao erro é o que deve ter sido descartado.
    assert.ok(!out.includes('setup ruidoso 0'));
  });

  it('mantém contexto antes do erro, não só a linha do erro', () => {
    const raw = [
      ...Array.from({ length: 300 }, (_, i) => `ruido ${i}`),
      'Run npm test',
      '##[error]falhou',
    ].join(NL);
    const out = trimLogTail(raw, 2_000);
    assert.match(out, /Run npm test/);
  });

  it('descarta o meio quando nem a partir do erro cabe', () => {
    const raw = [
      'ERROR: inicio da falha',
      ...Array.from({ length: 5_000 }, (_, i) => `linha ${i}`),
      'fim do job',
    ].join(NL);
    const out = trimLogTail(raw, 4_000);
    assert.match(out, /ERROR: inicio da falha/);
    assert.match(out, /fim do job$/);
    assert.match(out, /trecho do log omitido/);
    assert.ok(out.length <= 4_200);
  });

  it('cai para o final quando não há marcador de erro reconhecível', () => {
    const raw = Array.from({ length: 5_000 }, (_, i) => `linha ${i}`).join(NL);
    const out = trimLogTail(raw, 2_000);
    assert.match(out, /linha 4999$/);
  });

  it('descarta linhas em branco e devolve string vazia para entrada vazia', () => {
    assert.equal(trimLogTail(['', '', '  ', ''].join(NL)), '');
    assert.equal(trimLogTail(null), '');
  });
});

describe('getFailedJobLogs', () => {
  before(() => nock.disableNetConnect());
  after(() => nock.enableNetConnect());
  afterEach(() => nock.cleanAll());

  const jobsBody = {
    jobs: [
      { id: 1, name: 'build', conclusion: 'success' },
      { id: 2, name: 'test', conclusion: 'failure' },
    ],
  };

  it('follows the 302 to the signed blob URL and returns the trimmed log', async () => {
    nock(API).get(JOBS_PATH).reply(200, jobsBody);
    nock(API)
      .get('/repos/owner/repo/actions/jobs/2/logs')
      .reply(302, '', { location: 'https://productionresults.blob.core.windows.net/logs/2?sig=abc' });
    nock('https://productionresults.blob.core.windows.net')
      .get('/logs/2')
      .query(true)
      .reply(200, '2026-08-19T12:00:00.0000000Z Error: test failed');

    const logs = await getFailedJobLogs('owner', 'repo', '123');
    assert.equal(logs.length, 1);
    assert.equal(logs[0].job, 'test');
    assert.equal(logs[0].log, 'Error: test failed');
  });

  it('accepts an inline 200 body instead of a redirect', async () => {
    nock(API).get(JOBS_PATH).reply(200, jobsBody);
    nock(API).get('/repos/owner/repo/actions/jobs/2/logs').reply(200, 'boom');
    const logs = await getFailedJobLogs('owner', 'repo', '123');
    assert.equal(logs[0].log, 'boom');
  });

  it('refuses a redirect to a plaintext or untrusted host', async () => {
    nock(API).get(JOBS_PATH).reply(200, jobsBody);
    nock(API)
      .get('/repos/owner/repo/actions/jobs/2/logs')
      .reply(302, '', { location: 'http://evil.example.com/logs' });

    const logs = await getFailedJobLogs('owner', 'repo', '123');
    assert.equal(logs.length, 1);
    assert.equal(logs[0].log, '');
  });

  it('returns the job with an empty log when the download fails', async () => {
    nock(API).get(JOBS_PATH).reply(200, jobsBody);
    nock(API).get('/repos/owner/repo/actions/jobs/2/logs').reply(410);
    const logs = await getFailedJobLogs('owner', 'repo', '123');
    assert.deepEqual(logs, [{ job: 'test', jobId: 2, log: '' }]);
  });

  it('returns an empty list when the jobs lookup fails', async () => {
    nock(API).get(JOBS_PATH).reply(500);
    assert.deepEqual(await getFailedJobLogs('owner', 'repo', '123'), []);
  });

  it('caps the number of failed jobs it downloads', async () => {
    nock(API)
      .get(JOBS_PATH)
      .reply(200, {
        jobs: Array.from({ length: 6 }, (_, i) => ({ id: i, name: `job-${i}`, conclusion: 'failure' })),
      });
    for (let i = 0; i < 3; i += 1) {
      nock(API).get(`/repos/owner/repo/actions/jobs/${i}/logs`).reply(200, `log ${i}`);
    }
    const logs = await getFailedJobLogs('owner', 'repo', '123');
    assert.equal(logs.length, 3);
  });
});

describe('buildFailureAnalysisPayload', () => {
  it('monta o contrato documentado no AGENTS.md do agente publicado', () => {
    const payload = buildFailureAnalysisPayload({
      repository: 'owner/repo',
      workflow: 'Deploy',
      runId: '123',
      status: 'failure',
      failedLogs: [{ job: 'test', jobId: 2, log: 'Error: boom' }],
    });
    const request = JSON.parse(payload.input);
    assert.equal(request.repository, 'owner/repo');
    assert.equal(request.workflow, 'Deploy');
    assert.equal(request.run_id, '123');
    assert.equal(request.status, 'failure');
    assert.match(request.logs, /===== JOB: test =====/);
    assert.match(request.logs, /Error: boom/);
  });

  it('inclui as resoluções conhecidas, só com os campos que o agente usa', () => {
    const request = JSON.parse(
      buildFailureAnalysisPayload({
        repository: 'owner/repo',
        failedLogs: [{ job: 'a', log: 'ERROR: x' }],
        knownResolutions: [
          {
            match: 'exact',
            problem: 'Key Vault negou',
            cause: 'faltava secrets get',
            solution: 'concedida a permissão',
            createdAt: '2026-08-19T21:00:00.000Z',
            change: 'CHG1',
            // Ruído de prompt: não deve viajar.
            id: 'uuid-interno',
            author: 'octocat',
            sessionId: 'sess-1',
          },
        ],
      }).input,
    );
    assert.equal(request.known_resolutions.length, 1);
    assert.deepEqual(Object.keys(request.known_resolutions[0]).sort(), [
      'cause',
      'change',
      'match',
      'problem',
      'recorded_at',
      'solution',
    ]);
    assert.equal(request.known_resolutions[0].recorded_at, '2026-08-19');
  });

  it('rotula como related qualquer match que não seja exato', () => {
    const request = JSON.parse(
      buildFailureAnalysisPayload({
        failedLogs: [{ job: 'a', log: 'x' }],
        knownResolutions: [{ match: 'qualquer-coisa', solution: 'y' }],
      }).input,
    );
    assert.equal(request.known_resolutions[0].match, 'related');
  });

  it('omite known_resolutions quando não há registro utilizável', () => {
    const semNada = JSON.parse(buildFailureAnalysisPayload({ failedLogs: [{ job: 'a', log: 'x' }] }).input);
    assert.equal(semNada.known_resolutions, undefined);

    const semSolucao = JSON.parse(
      buildFailureAnalysisPayload({
        failedLogs: [{ job: 'a', log: 'x' }],
        knownResolutions: [{ match: 'exact', problem: 'sem solução registrada' }],
      }).input,
    );
    assert.equal(semSolucao.known_resolutions, undefined);
  });

  it('omite campos desconhecidos em vez de inventar valores', () => {
    const request = JSON.parse(buildFailureAnalysisPayload({ failedLogs: [{ job: 'a', log: 'x' }] }).input);
    assert.deepEqual(Object.keys(request), ['logs']);
  });

  it('cai para os steps que falharam quando nenhum log foi obtido', () => {
    const request = JSON.parse(
      buildFailureAnalysisPayload({
        failedSteps: [{ job: 'test', name: 'npm test', conclusion: 'failure' }],
        failedLogs: [],
      }).input,
    );
    assert.match(request.logs, /Nenhum log bruto disponível/);
    assert.match(request.logs, /test: npm test \(failure\)/);
  });

  it('nunca envia um pedido sem logs', () => {
    const request = JSON.parse(buildFailureAnalysisPayload({}).input);
    assert.equal(request.logs, 'Nenhum log disponível para esta execução.');
  });
});

describe('maskSecrets', () => {
  it('mascara tokens do GitHub, JWTs e chaves AWS', () => {
    const out = maskSecrets(
      'ghp_abcdefghijklmnopqrstuvwxyz012345 github_pat_11ABCDEFG0aBcDeFgHiJkL AKIAIOSFODNN7EXAMPLE',
    );
    assert.ok(!out.includes('ghp_abcdefghijklmnopqrstuvwxyz012345'));
    assert.ok(!out.includes('github_pat_11ABCDEFG0aBcDeFgHiJkL'));
    assert.ok(!out.includes('AKIAIOSFODNN7EXAMPLE'));
    assert.match(out, /\[REDACTED\]/);
  });

  it('mascara valores rotulados mantendo o rótulo legível', () => {
    // O rótulo mais próximo do valor é o que sobrevive — aqui, `Bearer`.
    const out = maskSecrets('Authorization: Bearer abcdef1234567890');
    assert.equal(out, 'Authorization: Bearer [REDACTED]');

    const linha = maskSecrets('api_key="s3cr3t-value-longo"');
    assert.ok(!linha.includes('s3cr3t-value-longo'));
    assert.match(linha, /^api_key="?\[REDACTED\]/);
  });

  it('mascara assinaturas em URLs e credenciais em connection strings', () => {
    const url = maskSecrets('https://blob.core.windows.net/x?sig=Zm9vYmFyMTIz&comp=block');
    assert.ok(!url.includes('Zm9vYmFyMTIz'));
    const conn = maskSecrets('postgres://usuario:senhaSuperSecreta@db.interno:5432/app');
    assert.ok(!conn.includes('senhaSuperSecreta'));
  });

  it('mascara e-mails, que aparecem de rotina em log de esteira corporativa', () => {
    const out = maskSecrets('Acionar: daniel.roda@bradesco.com.br - infdpcaas@corpr.bradesco.com.br');
    assert.equal(out, 'Acionar: [EMAIL] - [EMAIL]');
  });

  it('deixa passar texto comum sem alterações', () => {
    const plain = `npm ERR! code ELIFECYCLE
Test suite failed to run`;
    assert.equal(maskSecrets(plain), plain);
  });
});

describe('formatFailedLogs', () => {
  it('reporta quantos jobs ficaram de fora em vez de omiti-los em silêncio', () => {
    const huge = 'x'.repeat(121_000);
    const out = formatFailedLogs([
      { job: 'a', log: huge },
      { job: 'b', log: 'segundo' },
    ]);
    assert.match(out, /===== JOB: a =====/);
    assert.ok(!out.includes('===== JOB: b ====='));
    assert.match(out, /1 job\(s\) com falha omitido\(s\)/);
  });

  it('devolve string vazia quando não há log aproveitável', () => {
    assert.equal(formatFailedLogs([{ job: 'a', log: '' }]), '');
    assert.equal(formatFailedLogs([]), '');
  });

  it('mascara segredos antes de montar o bloco', () => {
    const out = formatFailedLogs([{ job: 'a', log: 'token=ghp_abcdefghijklmnopqrstuvwxyz012345' }]);
    assert.ok(!out.includes('ghp_abcdefghijklmnopqrstuvwxyz012345'));
  });
});

describe('parseAnalysis', () => {
  it('lê o objeto JSON puro que o agente deve devolver', () => {
    const parsed = parseAnalysis('{"status":"analyzed","category":"test","summary":"quebrou"}');
    assert.equal(parsed.category, 'test');
  });

  it('recupera o objeto mesmo com cerca de código ou texto em volta', () => {
    const fenced = ['```json', '{"summary":"ok"}', '```'].join('\n');
    assert.equal(parseAnalysis(fenced).summary, 'ok');
    assert.equal(parseAnalysis('Segue a análise: {"summary":"ok"} Espero ter ajudado.').summary, 'ok');
  });

  it('devolve null quando não há objeto algum', () => {
    assert.equal(parseAnalysis('desculpe, não consegui analisar'), null);
    assert.equal(parseAnalysis(''), null);
  });
});

describe('agentixClient — configuração', () => {
  it('reports itself configured with the env set for these tests', () => {
    assert.equal(agentix.isConfigured(), true);
    assert.deepEqual(agentix.missingConfig(), []);
  });
});

describe('agentixClient — fetchAnalysis', () => {
  before(() => nock.disableNetConnect());
  after(() => nock.enableNetConnect());
  afterEach(() => {
    nock.cleanAll();
    agentix.resetTokenCache();
  });

  function mockToken() {
    return nock(`${AGENTIX}:444`)
      .post(KEYCLOAK_PATH, (body) => body.grant_type === 'password')
      .reply(200, { access_token: 'tok-123', expires_in: 300 });
  }

  it('prefere partial_output de /artifacts, que já vem parseado', async () => {
    mockToken();
    nock(AGENTIX)
      .get('/v2/api/sessions/s1/artifacts')
      .reply(200, { partial_output: { summary: 'quebrou', category: 'permission' }, files: [], event_outputs: [] });

    const out = await agentix.fetchAnalysis('s1');
    assert.equal(out.summary, 'quebrou');
  });

  it('cai para o turno assistant de /messages quando não há partial_output', async () => {
    mockToken();
    nock(AGENTIX).get('/v2/api/sessions/s2/artifacts').reply(200, { partial_output: null, files: [] });
    nock(AGENTIX)
      .get('/v2/api/sessions/s2/messages')
      .reply(200, [
        { role: 'system', content: 'instrucoes' },
        { role: 'user', content: 'logs' },
        { role: 'assistant', content: '{"summary":"da mensagem"}' },
      ]);

    assert.equal(await agentix.fetchAnalysis('s2'), '{"summary":"da mensagem"}');
  });

  it('cai para /messages também quando /artifacts falha', async () => {
    mockToken();
    nock(AGENTIX).get('/v2/api/sessions/s3/artifacts').reply(404);
    nock(AGENTIX).get('/v2/api/sessions/s3/messages').reply(200, [{ role: 'assistant', content: 'resposta' }]);

    assert.equal(await agentix.fetchAnalysis('s3'), 'resposta');
  });

  it('devolve null quando nenhum dos dois tem resposta', async () => {
    mockToken();
    nock(AGENTIX).get('/v2/api/sessions/s4/artifacts').reply(200, { partial_output: null });
    nock(AGENTIX).get('/v2/api/sessions/s4/messages').reply(200, [{ role: 'user', content: 'so o pedido' }]);

    assert.equal(await agentix.fetchAnalysis('s4'), null);
  });
});

describe('agentixClient — analyzeFailure', () => {
  before(() => nock.disableNetConnect());
  after(() => nock.enableNetConnect());
  afterEach(() => {
    nock.cleanAll();
    agentix.resetTokenCache();
  });

  function mockToken() {
    return nock(`${AGENTIX}:444`)
      // nock parses the form-urlencoded body into an object.
      .post(KEYCLOAK_PATH, (body) => body.grant_type === 'password' && body.client_id === 'agx-front')
      .reply(200, { access_token: 'tok-123', expires_in: 300 });
  }

  it('logs in, invokes the entity and returns the analysis', async () => {
    mockToken();
    nock(AGENTIX, { reqheaders: { authorization: 'Bearer tok-123', 'x-tenant-id': 'DVOP' } })
      .post('/v2/api/sessions/invoke', (body) => {
        assert.equal(body.entity_type, 'agent');
        assert.equal(body.entity_name, 'analise-falha-pipeline');
        assert.equal(body.bundle, 'changes-observability');
        assert.equal(body.payload.input, 'analise isso');
        assert.equal(body.constants.run_url, 'https://github.com/o/r/actions/runs/1');
        return true;
      })
      .reply(200, { session_id: 'sess-1', status: 'CREATED' });
    // Sessão real reporta o estado em `state`, e a resposta vive em /artifacts.
    nock(AGENTIX).get('/v2/api/sessions/sess-1').reply(200, { state: 'DONE' });
    nock(AGENTIX)
      .get('/v2/api/sessions/sess-1/artifacts')
      .reply(200, { partial_output: { summary: 'A causa foi X.' } });

    const out = await agentix.analyzeFailure({
      input: 'analise isso',
      constants: { run_url: 'https://github.com/o/r/actions/runs/1' },
    });
    assert.equal(out.sessionId, 'sess-1');
    assert.equal(out.analysis.summary, 'A causa foi X.');
  });

  it('polls while the session is still running', async () => {
    mockToken();
    nock(AGENTIX).post('/v2/api/sessions/invoke').reply(200, { session_id: 'sess-2', status: 'CREATED' });
    nock(AGENTIX).get('/v2/api/sessions/sess-2').reply(200, { state: 'RUNNING' });
    nock(AGENTIX).get('/v2/api/sessions/sess-2').reply(200, { state: 'DONE', output: 'pronto' });

    const session = await agentix.invokeSession({ input: 'x', constants: {} });
    const final = await agentix.waitForSession(session.sessionId, { timeoutMs: 5_000, intervalMs: 10 });
    assert.equal(agentix.sessionState(final), 'DONE');
  });

  it('surfaces a FAILED session as an error', async () => {
    mockToken();
    nock(AGENTIX).post('/v2/api/sessions/invoke').reply(200, { session_id: 'sess-3' });
    nock(AGENTIX).get('/v2/api/sessions/sess-3').reply(200, { state: 'FAILED', error_message: 'modelo indisponível' });

    await assert.rejects(agentix.analyzeFailure({ input: 'x', constants: {} }), /modelo indisponível/);
  });

  it('surfaces an AWAITING (HITL) session as an error instead of hanging', async () => {
    mockToken();
    nock(AGENTIX).post('/v2/api/sessions/invoke').reply(200, { session_id: 'sess-4' });
    nock(AGENTIX).get('/v2/api/sessions/sess-4').reply(200, { state: 'AWAITING' });

    await assert.rejects(agentix.analyzeFailure({ input: 'x', constants: {} }), /intervenção humana/);
  });

  it('não envia o campo version (é a versão do bundle, não a do agente)', async () => {
    mockToken();
    let enviado = null;
    nock(AGENTIX)
      .post('/v2/api/sessions/invoke', (body) => {
        enviado = body;
        return true;
      })
      .reply(201, { session_id: 'sess-v' });

    await agentix.invokeSession({ input: 'x', constants: {} });
    assert.equal(enviado.version, undefined);
    assert.equal(enviado.entity_version, '1.0.0');
    assert.equal(enviado.bundle, 'changes-observability');
  });

  it('mostra o detalhe do erro da API, não só o código HTTP', async () => {
    mockToken();
    nock(AGENTIX)
      .post('/v2/api/sessions/invoke')
      .reply(422, { detail: "Bundle 'x' not found" });

    await assert.rejects(agentix.invokeSession({ input: 'x', constants: {} }), /Bundle 'x' not found/);
  });

  it('lê a mensagem quando o registry bloqueia por versão, em vez de despejar o JSON', async () => {
    mockToken();
    nock(AGENTIX)
      .post('/v2/api/sessions/invoke')
      .reply(409, {
        detail: {
          message: "Execution blocked: bundle 'b' version '0.1.0.dev2' is not fully approved.",
          blockers: [{ type: 'agent', name: 'changes-observability-agent', version: '0.1.0', reason: 'requested_version_not_found' }],
        },
      });

    await assert.rejects(
      agentix.invokeSession({ input: 'x', constants: {} }),
      /Execution blocked.*changes-observability-agent@0\.1\.0 \(requested_version_not_found\)/,
    );
  });

  it('formata o erro de validação do FastAPI (detail em array)', async () => {
    mockToken();
    nock(AGENTIX)
      .post('/v2/api/sessions/invoke')
      .reply(422, { detail: [{ loc: ['body', 'bundle'], msg: 'Field required' }] });

    await assert.rejects(agentix.invokeSession({ input: 'x', constants: {} }), /body\.bundle: Field required/);
  });

  it('fails clearly when no session_id comes back', async () => {
    mockToken();
    nock(AGENTIX).post('/v2/api/sessions/invoke').reply(200, {});
    await assert.rejects(agentix.invokeSession({ input: 'x', constants: {} }), /session_id/);
  });

  it('times out instead of polling forever', async () => {
    mockToken();
    nock(AGENTIX).get('/v2/api/sessions/sess-5').times(3).reply(200, { state: 'RUNNING' });
    await assert.rejects(
      agentix.waitForSession('sess-5', { timeoutMs: 60, intervalMs: 10 }),
      /Tempo esgotado/,
    );
  });

  it('reuses the cached token across calls', async () => {
    const tokenScope = mockToken();
    nock(AGENTIX).post('/v2/api/sessions/invoke').twice().reply(200, { session_id: 'sess-6' });
    await agentix.invokeSession({ input: 'x', constants: {} });
    await agentix.invokeSession({ input: 'y', constants: {} });
    assert.ok(tokenScope.isDone());
    assert.equal(nock.pendingMocks().length, 0);
  });
});
