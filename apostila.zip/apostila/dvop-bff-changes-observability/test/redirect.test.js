import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';
process.env.BASE_PATH = '/painel';

const { safeRedirect } = await import('../src/lib/redirect.js');

function fakeRes() {
  return {
    redirectedTo: null,
    redirect(url) {
      this.redirectedTo = url;
    },
  };
}

describe('safeRedirect', () => {
  it('redirects to BASE_PATH by default', () => {
    const res = fakeRes();
    safeRedirect(res);
    assert.equal(res.redirectedTo, '/painel');
  });

  it('redirects to a sub path within the app', () => {
    const res = fakeRes();
    safeRedirect(res, 'foo');
    assert.equal(res.redirectedTo, '/painel/foo');
  });

  it('blocks open-redirect attempts', () => {
    const res = fakeRes();
    safeRedirect(res, 'http://evil.com');
    assert.equal(res.redirectedTo, '/painel');
  });
});
