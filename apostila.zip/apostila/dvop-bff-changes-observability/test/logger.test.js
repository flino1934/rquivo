// Imports the logger with a development environment so the default debug level
// path is exercised and every sink (error/warn/log) is reached.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'development';
delete process.env.LOG_LEVEL;

const { logger } = await import('../src/lib/logger.js');

describe('logger', () => {
  it('exposes the leveled methods and emits without throwing', () => {
    assert.equal(typeof logger.error, 'function');
    logger.error('err');
    logger.warn('warn');
    logger.info('info');
    logger.debug('debug');
  });
});
