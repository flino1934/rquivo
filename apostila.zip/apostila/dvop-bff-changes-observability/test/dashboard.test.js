import { describe, it, afterEach } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';
process.env.BASE_PATH = '/painel';

const { default: app } = await import('../src/app.js');
const { config } = await import('../src/config/env.js');
const fs = (await import('node:fs')).default;
const uploadFolder = config.UPLOAD_FOLDER;
const request = (await import('supertest')).default;
const nock = (await import('nock')).default;

const API = 'https://api.github.com';
const TOKEN = 'ghp_validtoken1234567890';

// Returns a supertest agent (persists the session cookie) already authenticated.
async function authedAgent() {
  const agent = request.agent(app);
  nock(API).get('/user').reply(200, { login: 'octocat' });
  const res = await agent.post('/painel/set-token').send({ token: TOKEN });
  assert.equal(res.status, 200);
  return agent;
}

describe('dashboard (authenticated)', () => {
  afterEach(() => nock.cleanAll());

  it('renders the dashboard when a token is configured', async () => {
    const agent = await authedAgent();
    const res = await agent.get('/painel/');
    assert.equal(res.status, 200);
    assert.match(res.headers['content-type'] || '', /text\/html/);
    assert.match(res.text, /Acompanhamento de Changes/);
  });

  it('serves the workflow-data JSON feed', async () => {
    const agent = await authedAgent();
    const res = await agent.get('/painel/api/workflow-data');
    assert.equal(res.status, 200);
    assert.equal(res.body.success, true);
    assert.ok(Array.isArray(res.body.rows));
  });

  it('accepts a CSV upload', async () => {
    const agent = await authedAgent();
    const csv = 'parent,planned_start_date,description\nCHG1,2026-06-19 10:00,nourl';
    const res = await agent.post('/painel/').attach('csv_file', Buffer.from(csv), 'test.csv');
    assert.equal(res.status, 302);
  });

  it('ignores a non-csv upload (redirects) sem gravá-lo em disco', async () => {
    const agent = await authedAgent();
    const antes = fs.existsSync(uploadFolder) ? fs.readdirSync(uploadFolder) : [];
    const res = await agent.post('/painel/').attach('csv_file', Buffer.from('x'), 'bad.txt');
    assert.equal(res.status, 302);
    const depois = fs.existsSync(uploadFolder) ? fs.readdirSync(uploadFolder) : [];
    // O multer grava antes de a rota validar; o fileFilter é o que impede o órfão.
    assert.deepEqual(depois, antes, 'upload rejeitado não pode deixar arquivo na pasta');
  });

  it('answers 503 on the AgentiX analysis when the integration is not configured', async () => {
    const agent = await authedAgent();
    const res = await agent
      .post('/painel/api/agentix-analyze')
      .send({ url: 'https://github.com/owner/repo/actions/runs/123' });
    assert.equal(res.status, 503);
    assert.match(res.body.error, /não configurada/);
  });

  it('removes the session token', async () => {
    const agent = await authedAgent();
    const res = await agent.post('/painel/remove-token');
    assert.equal(res.status, 200);
    assert.equal(res.body.success, true);
  });
});
