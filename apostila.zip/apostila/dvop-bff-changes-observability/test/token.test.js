import { describe, it, afterEach } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';
process.env.BASE_PATH = '/painel';

const { default: app } = await import('../src/app.js');
const request = (await import('supertest')).default;
const nock = (await import('nock')).default;

const API = 'https://api.github.com';
const TOKEN = 'ghp_validtoken1234567890';

describe('set-token error handling', () => {
  afterEach(() => nock.cleanAll());

  it('rejects a missing token', async () => {
    const res = await request(app).post('/painel/set-token').send({});
    assert.equal(res.status, 400);
  });

  it('maps a 401 from GitHub to a 400', async () => {
    nock(API).get('/user').reply(401, {});
    const res = await request(app).post('/painel/set-token').send({ token: TOKEN });
    assert.equal(res.status, 400);
  });

  it('maps a 403 from GitHub to a 400', async () => {
    nock(API).get('/user').reply(403, {});
    const res = await request(app).post('/painel/set-token').send({ token: TOKEN });
    assert.equal(res.status, 400);
  });

  it('maps a connectivity error to a 500', async () => {
    nock(API).get('/user').replyWithError('boom');
    const res = await request(app).post('/painel/set-token').send({ token: TOKEN });
    assert.equal(res.status, 500);
  });
});
