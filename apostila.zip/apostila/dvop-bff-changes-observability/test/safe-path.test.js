import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { isSafeCsvName, resolveCsvWithin, sanitizeDirPath } from '../src/lib/safe-path.js';

describe('isSafeCsvName', () => {
  it('accepts normal csv names', () => {
    assert.equal(isSafeCsvName('change_task.csv'), true);
    assert.equal(isSafeCsvName('2026-06-18__21-11_change_task.csv'), true);
    assert.equal(isSafeCsvName('My Report.csv'), true);
  });

  it('rejects traversal, separators and bad extensions', () => {
    assert.equal(isSafeCsvName('../secret.csv'), false);
    assert.equal(isSafeCsvName('a/b.csv'), false);
    assert.equal(isSafeCsvName('a\\b.csv'), false);
    assert.equal(isSafeCsvName('evil.txt'), false);
  });

  it('rejects empty, non-string and overlong names', () => {
    assert.equal(isSafeCsvName(''), false);
    assert.equal(isSafeCsvName(null), false);
    assert.equal(isSafeCsvName(42), false);
    assert.equal(isSafeCsvName('a'.repeat(201) + '.csv'), false);
  });
});

describe('resolveCsvWithin', () => {
  it('resolves a valid name inside the base dir', () => {
    const base = path.resolve('uploads');
    assert.equal(resolveCsvWithin(base, 'ok.csv'), path.join(base, 'ok.csv'));
  });

  it('rejects traversal and invalid names', () => {
    assert.equal(resolveCsvWithin('uploads', '../x.csv'), null);
    assert.equal(resolveCsvWithin('uploads', 'x.txt'), null);
  });
});

describe('sanitizeDirPath', () => {
  it('normalizes valid directory paths', () => {
    assert.equal(sanitizeDirPath('uploads'), path.resolve('uploads'));
    assert.equal(sanitizeDirPath('/tmp/uploads'), path.resolve('/tmp/uploads'));
  });

  it('rejects null bytes, injection and empty values', () => {
    assert.equal(sanitizeDirPath('bad\0dir'), null);
    assert.equal(sanitizeDirPath('/etc/$(x)'), null);
    assert.equal(sanitizeDirPath(''), null);
    assert.equal(sanitizeDirPath(null), null);
  });
});
