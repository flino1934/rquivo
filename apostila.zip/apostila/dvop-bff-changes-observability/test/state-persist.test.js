import { describe, it, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

// Configure a temporary DATA_DIR BEFORE importing the module under test, so the
// state module picks up annotation persistence at load time.
process.env.NODE_ENV = 'test';
const DATA_DIR = path.join(os.tmpdir(), 'dvop-state-persist-test');
fs.rmSync(DATA_DIR, { recursive: true, force: true });
fs.mkdirSync(DATA_DIR, { recursive: true });
process.env.DATA_DIR = DATA_DIR;

const FILE = path.join(DATA_DIR, 'annotations.json');
// Seed an existing file to verify load-on-boot.
fs.writeFileSync(FILE, JSON.stringify({ 'https://x/seed': { comment: 'seeded', rerunChecked: true } }));

const { getSharedAnnotation, setSharedAnnotation } = await import('../src/services/state.js');

describe('annotation persistence', () => {
  after(() => fs.rmSync(DATA_DIR, { recursive: true, force: true }));

  it('loads existing annotations from disk on startup', () => {
    assert.deepEqual(getSharedAnnotation('https://x/seed'), { comment: 'seeded', rerunChecked: true });
  });

  it('writes new annotations to disk', () => {
    setSharedAnnotation('https://x/new', { comment: 'hello', rerunChecked: true });
    const onDisk = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    assert.deepEqual(onDisk['https://x/new'], { comment: 'hello', rerunChecked: true });
  });

  it('removes cleared annotations from disk', () => {
    setSharedAnnotation('https://x/new', { comment: '', rerunChecked: false });
    const onDisk = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    assert.equal(onDisk['https://x/new'], undefined);
  });
});
