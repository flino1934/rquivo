import { describe, it, before, after, afterEach } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';

const { buildRowsFromCsv } = await import('../src/services/rows.js');
const nock = (await import('nock')).default;

const API = 'https://api.github.com';

describe('buildRowsFromCsv', () => {
  before(() => nock.disableNetConnect());
  after(() => nock.enableNetConnect());
  afterEach(() => nock.cleanAll());

  it('returns [] for empty content', async () => {
    assert.deepEqual(await buildRowsFromCsv(''), []);
  });

  it('builds rows and resolves run status from GitHub', async () => {
    nock(API)
      .get('/repos/owner/repo/actions/runs/1')
      .reply(200, { status: 'completed', conclusion: 'success', run_attempt: 1 });

    const csv = [
      'parent,planned_start_date,description',
      'CHG100,2026-06-19 14:30,https://github.com/owner/repo/actions/runs/1',
    ].join('\n');

    const rows = await buildRowsFromCsv(csv, null, 'ghp_token');
    assert.equal(rows.length, 1);
    assert.equal(rows[0].CHANGE, 'CHG100');
    assert.equal(rows[0].status, 'Success');
    assert.equal(rows[0].url, 'https://github.com/owner/repo/actions/runs/1');
  });

  it('finds the parent in the raw CSV when no parent column maps', async () => {
    nock(API).get('/repos/owner/repo/actions/runs/5').reply(200, { status: 'in_progress' });

    // No "parent" column -> CHANGE is resolved by scanning the raw rows.
    const csv = [
      'change,planned_start_date,description',
      'CHG500,2026-06-19 09:00,https://github.com/owner/repo/actions/runs/5',
    ].join('\n');

    const rows = await buildRowsFromCsv(csv, null, 't');
    assert.equal(rows.length, 1);
    assert.equal(rows[0].badge_class, 'progress');
  });

  it('serves repeated lookups from cache (no extra network)', async () => {
    nock(API)
      .get('/repos/owner/repo/actions/runs/2')
      .reply(200, { status: 'completed', conclusion: 'failure', run_attempt: 2 });

    const csv =
      'parent,planned_start_date,description\nCHG200,2026-06-19 15:00,https://github.com/owner/repo/actions/runs/2';

    const first = await buildRowsFromCsv(csv, null, 't');
    assert.equal(first[0].status, 'Failure');

    // No nock interceptor this time: the result must come from the cache.
    const second = await buildRowsFromCsv(csv, null, 't');
    assert.equal(second[0].status, 'Failure');
  });
});
