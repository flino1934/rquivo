import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';

const { sanitizeBasePath } = await import('../src/config/env.js');

describe('sanitizeBasePath', () => {
  it('keeps a valid base path', () => {
    assert.equal(sanitizeBasePath('/painel'), '/painel');
  });

  it('adds a leading slash and trims a trailing one', () => {
    assert.equal(sanitizeBasePath('app'), '/app');
    assert.equal(sanitizeBasePath('/app/'), '/app');
  });

  it('falls back to the default on empty or invalid input', () => {
    assert.equal(sanitizeBasePath(''), '/painel');
    assert.equal(sanitizeBasePath(null), '/painel');
    assert.equal(sanitizeBasePath('/bad$char'), '/painel');
  });

  it('blocks open-redirect and traversal attempts', () => {
    assert.equal(sanitizeBasePath('http://evil.com'), '/painel');
    assert.equal(sanitizeBasePath('//evil.com'), '/painel');
    assert.equal(sanitizeBasePath('/../etc'), '/painel');
  });
});
