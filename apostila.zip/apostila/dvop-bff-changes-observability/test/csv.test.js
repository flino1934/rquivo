import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  extractRunUrls,
  parsePlannedDate,
  processChangeTasksFromContent,
  toYmdHms,
} from '../src/services/csv.js';

describe('extractRunUrls', () => {
  it('extracts valid GitHub Actions run URLs', () => {
    const text =
      'see https://github.com/owner/repo/actions/runs/123 and https://github.com/owner/repo2/actions/runs/456';
    assert.deepEqual(extractRunUrls(text), [
      'https://github.com/owner/repo/actions/runs/123',
      'https://github.com/owner/repo2/actions/runs/456',
    ]);
  });

  it('deduplicates repeated URLs', () => {
    const url = 'https://github.com/owner/repo/actions/runs/123';
    assert.deepEqual(extractRunUrls(`${url} ${url}`), [url]);
  });

  it('excludes repositories matching blocked fragments', () => {
    const text = [
      'https://github.com/owner/app-pxy-svc/actions/runs/1',
      'https://github.com/owner/app-iac-svc/actions/runs/2',
      'https://github.com/owner/app-demise-svc/actions/runs/3',
      'https://github.com/Bradesco-Next/app/actions/runs/4',
      'https://github.com/owner/good-repo/actions/runs/5',
    ].join('\n');
    assert.deepEqual(extractRunUrls(text), ['https://github.com/owner/good-repo/actions/runs/5']);
  });

  it('returns an empty array for empty input', () => {
    assert.deepEqual(extractRunUrls(''), []);
    assert.deepEqual(extractRunUrls(null), []);
  });
});

describe('parsePlannedDate', () => {
  it('parses ISO-like dates', () => {
    const d = parsePlannedDate('2025-10-21 14:30:00');
    assert.equal(toYmdHms(d), '2025-10-21 14:30:00');
  });

  it('parses Brazilian DD/MM/YYYY dates', () => {
    const d = parsePlannedDate('21/10/2025 14:30');
    assert.equal(toYmdHms(d), '2025-10-21 14:30:00');
  });

  it('returns null for empty/invalid input', () => {
    assert.equal(parsePlannedDate(''), null);
    assert.equal(parsePlannedDate('not-a-date'), null);
  });
});

describe('processChangeTasksFromContent', () => {
  it('keeps only rows with run URLs and formats the HORÁRIO column', () => {
    const csv = [
      'parent,planned_start_date,description',
      'CHG001,2025-10-21 14:30:00,run https://github.com/owner/repo/actions/runs/123',
      'CHG002,2025-10-21 09:00:00,no urls here',
    ].join('\n');

    const rows = processChangeTasksFromContent(csv);
    assert.equal(rows.length, 1);
    assert.equal(rows[0].CHANGE, 'CHG001');
    assert.equal(rows[0]['HORÁRIO'], '2025-10-21 14:30:00');
    assert.match(rows[0].DESCRIPTION, /actions\/runs\/123/);
  });

  it('filters out New/Authorize parent.state rows', () => {
    const csv = [
      'parent,parent.state,description',
      'CHG001,New,https://github.com/owner/repo/actions/runs/1',
      'CHG002,Implement,https://github.com/owner/repo/actions/runs/2',
    ].join('\n');

    const rows = processChangeTasksFromContent(csv);
    assert.equal(rows.length, 1);
    assert.equal(rows[0].CHANGE, 'CHG002');
  });

  it('returns an empty array for empty content', () => {
    assert.deepEqual(processChangeTasksFromContent(''), []);
  });
});
