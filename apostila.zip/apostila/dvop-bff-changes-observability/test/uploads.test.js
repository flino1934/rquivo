import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';

const { allowedFile, buildStoredCsvFilename, listAvailableCsvs } = await import('../src/services/uploads.js');

describe('allowedFile', () => {
  it('accepts .csv (any case) and rejects others', () => {
    assert.equal(allowedFile('data.csv'), true);
    assert.equal(allowedFile('DATA.CSV'), true);
    assert.equal(allowedFile('data.txt'), false);
    assert.equal(allowedFile('noext'), false);
    assert.equal(allowedFile(''), false);
  });
});

describe('buildStoredCsvFilename', () => {
  it('prefixes a timestamp and sanitizes unsafe characters', () => {
    const name = buildStoredCsvFilename('My Report (final).csv');
    assert.match(name, /^\d{4}-\d{2}-\d{2}__\d{2}-\d{2}_/);
    assert.match(name, /\.csv$/);
    assert.ok(!/[ ()]/.test(name), 'no spaces or parentheses');
  });

  it('falls back to a default name', () => {
    const name = buildStoredCsvFilename();
    assert.match(name, /upload\.csv$/);
  });
});

describe('listAvailableCsvs', () => {
  it('returns an array of safe csv names', () => {
    const list = listAvailableCsvs();
    assert.ok(Array.isArray(list));
  });
});
