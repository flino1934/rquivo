import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

const { getSharedAnnotation, setSharedAnnotation } = await import('../src/services/state.js');

describe('shared annotations', () => {
  it('returns defaults for empty or unknown urls', () => {
    assert.deepEqual(getSharedAnnotation(''), { comment: '', rerunChecked: false });
    assert.deepEqual(getSharedAnnotation('https://x/1'), { comment: '', rerunChecked: false });
  });

  it('stores and updates an annotation', () => {
    const url = 'https://github.com/o/r/actions/runs/77';
    setSharedAnnotation(url, { comment: 'hi', rerunChecked: true });
    const a = getSharedAnnotation(url);
    assert.equal(a.comment, 'hi');
    assert.equal(a.rerunChecked, true);
  });

  it('deletes the annotation when fully cleared', () => {
    const url = 'https://github.com/o/r/actions/runs/88';
    setSharedAnnotation(url, { comment: 'x' });
    setSharedAnnotation(url, { comment: '', rerunChecked: false });
    assert.deepEqual(getSharedAnnotation(url), { comment: '', rerunChecked: false });
  });

  it('ignores a missing url on set', () => {
    assert.deepEqual(setSharedAnnotation(''), { comment: '', rerunChecked: false });
  });
});
