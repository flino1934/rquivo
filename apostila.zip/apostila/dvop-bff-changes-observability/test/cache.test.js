import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';
process.env.CACHE_TTL_MS = '40';

const { getCached, setCached, cacheStats } = await import('../src/services/cache.js');

describe('cache', () => {
  it('returns null for a missing key', () => {
    assert.equal(getCached('missing'), null);
  });

  it('stores and retrieves a value', () => {
    setCached('k', { a: 1 });
    assert.deepEqual(getCached('k'), { a: 1 });
  });

  it('expires entries after the TTL', async () => {
    setCached('k2', { b: 2 });
    await new Promise((r) => setTimeout(r, 60));
    assert.equal(getCached('k2'), null);
  });

  it('reports stats', () => {
    const s = cacheStats();
    assert.equal(typeof s.size, 'number');
    assert.equal(s.ttl_seconds, 0.04);
  });
});
