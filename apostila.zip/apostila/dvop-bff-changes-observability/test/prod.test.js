// Exercises the production code paths (security middleware, prod config) which
// are skipped under NODE_ENV=test. Runs in its own process, so the production
// environment here does not leak into the other test files.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'production';
process.env.BASE_PATH = '/painel';
process.env.SESSION_SECRET = 'a-strong-test-secret-value-0123456789';
process.env.TRUST_PROXY = 'true';
process.env.COOKIE_SECURE = 'false';

const { default: app } = await import('../src/app.js');
const request = (await import('supertest')).default;

describe('production middleware', () => {
  it('applies Helmet/CSP and serves health checks', async () => {
    const res = await request(app).get('/painel/healthz');
    assert.equal(res.status, 200);
    assert.ok(res.headers['content-security-policy'], 'CSP header present');
  });
});
