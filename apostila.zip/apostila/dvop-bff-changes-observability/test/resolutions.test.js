import { describe, it, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

process.env.NODE_ENV = 'test';
const DATA_DIR = path.join(os.tmpdir(), 'dvop-resolutions-test');
fs.rmSync(DATA_DIR, { recursive: true, force: true });
fs.mkdirSync(DATA_DIR, { recursive: true });
process.env.DATA_DIR = DATA_DIR;

const { addResolution, buildSignature, buildStepSignature, findResolutions, listResolutions, resetResolutions } = await import(
  '../src/services/resolutions.js'
);
const { config } = await import('../src/config/env.js');

const falha = {
  repository: 'Bradesco-Core/pdpj-bff-cartoes',
  workflow: 'Workflow Sandbox',
  failedSteps: [{ job: 'call-build / Scan-ACS-APP', name: 'roxctl image check', conclusion: 'failure' }],
};

describe('buildSignature', () => {
  it('é igual para a mesma falha em execuções diferentes', () => {
    // Outra execução do mesmo workflow, quebrando no mesmo step.
    assert.equal(buildSignature(falha), buildSignature(structuredClone(falha)));
  });

  it('não depende da ordem dos steps que falharam', () => {
    const doisSteps = { ...falha, failedSteps: [{ job: 'a', name: 'x' }, { job: 'b', name: 'y' }] };
    const invertido = { ...falha, failedSteps: [{ job: 'b', name: 'y' }, { job: 'a', name: 'x' }] };
    assert.equal(buildSignature(doisSteps), buildSignature(invertido));
  });

  it('distingue step, workflow e repositório diferentes', () => {
    const outroStep = { ...falha, failedSteps: [{ job: 'call-build / build', name: 'mvn package' }] };
    const outroWorkflow = { ...falha, workflow: 'Release' };
    const outroRepo = { ...falha, repository: 'Bradesco-Core/outro' };
    const base = buildSignature(falha);
    assert.notEqual(base, buildSignature(outroStep));
    assert.notEqual(base, buildSignature(outroWorkflow));
    assert.notEqual(base, buildSignature(outroRepo));
  });

  it('ignora id numérico e timestamp que apareçam no nome do step', () => {
    const comRuido = {
      ...falha,
      failedSteps: [{ job: 'call-build / Scan-ACS-APP', name: 'roxctl image check 32291972853' }],
    };
    assert.equal(buildSignature(falha), buildSignature(comRuido));
  });

  it('devolve vazio quando não há nada de que derivar a chave', () => {
    assert.equal(buildSignature({}), '');
    assert.equal(buildSignature(), '');
  });
});

describe('buildStepSignature', () => {
  it('casa o mesmo step entre repositórios diferentes', () => {
    // A esteira corporativa é compartilhada: o mesmo step falha em vários
    // projetos, e é justamente esse conhecimento que precisa cruzar repositório.
    const outroProjeto = { ...falha, repository: 'Bradesco-Core/outro-bff', workflow: 'Release' };
    assert.equal(buildStepSignature(falha), buildStepSignature(outroProjeto));
    assert.notEqual(buildSignature(falha), buildSignature(outroProjeto));
  });

  it('distingue steps diferentes', () => {
    const outroStep = { failedSteps: [{ job: 'call-build / build', name: 'mvn package' }] };
    assert.notEqual(buildStepSignature(falha), buildStepSignature(outroStep));
  });

  it('devolve vazio sem steps', () => {
    assert.equal(buildStepSignature({ failedSteps: [] }), '');
    assert.equal(buildStepSignature(), '');
  });
});

describe('addResolution', () => {
  beforeEach(() => resetResolutions());

  it('exige a solução — sem ela não há o que referenciar', () => {
    assert.equal(addResolution({ signature: 'abc', solution: '   ' }), null);
    assert.equal(listResolutions().length, 0);
  });

  it('registra e devolve a entrada com autoria e data', () => {
    const entry = addResolution({
      signature: 'abc',
      category: 'permission',
      problem: 'Key Vault negou',
      cause: 'faltava secrets get',
      solution: 'concedida a permissão ao SPN',
      runUrl: 'https://github.com/o/r/actions/runs/1',
      change: 'CHG1',
      author: 'octocat',
    });
    assert.equal(entry.solution, 'concedida a permissão ao SPN');
    assert.equal(entry.author, 'octocat');
    assert.ok(entry.id && entry.createdAt);
    assert.equal(listResolutions().length, 1);
  });
});

describe('findResolutions', () => {
  const REPO = 'org/repo';

  beforeEach(() => {
    resetResolutions();
    addResolution({ signature: 'sig-a', stepSignature: 'step-a', repository: REPO, solution: 'mesma falha, mesmo projeto' });
    addResolution({ signature: 'sig-x', stepSignature: 'step-a', repository: 'org/outro', solution: 'mesmo step, outro projeto' });
    addResolution({ signature: 'sig-b', stepSignature: 'step-b', repository: REPO, solution: 'outro step, mesmo projeto' });
    addResolution({ signature: 'sig-z', stepSignature: 'step-z', repository: 'org/terceiro', solution: 'nada a ver' });
  });

  it('ordena os três níveis: mesma falha, mesmo step, mesmo projeto', () => {
    const achados = findResolutions({ signature: 'sig-a', stepSignature: 'step-a', repository: REPO });
    assert.deepEqual(
      achados.map((r) => r.solution),
      ['mesma falha, mesmo projeto', 'mesmo step, outro projeto', 'outro step, mesmo projeto'],
    );
  });

  it('só o nível mais forte vai como exact; os demais como related', () => {
    const achados = findResolutions({ signature: 'sig-a', stepSignature: 'step-a', repository: REPO });
    assert.equal(achados[0].match, 'exact');
    assert.equal(achados[1].match, 'related');
    assert.equal(achados[2].match, 'related');
  });

  it('encontra o caso de outro repositório mesmo sem assinatura completa igual', () => {
    const achados = findResolutions({ signature: 'nenhuma', stepSignature: 'step-a', repository: 'org/novo' });
    assert.equal(achados.length, 2);
    assert.ok(achados.every((r) => r.match === 'related'));
    assert.ok(achados.some((r) => r.solution === 'mesmo step, outro projeto'));
  });

  it('não devolve o que não casa em nível nenhum', () => {
    const achados = findResolutions({ signature: 'sig-a', stepSignature: 'step-a', repository: REPO });
    assert.ok(!achados.some((r) => r.solution === 'nada a ver'));
  });

  it('devolve vazio quando nada casa', () => {
    assert.deepEqual(findResolutions({ signature: 'zzz', stepSignature: 'zzz', repository: 'org/quarto' }), []);
  });
});

describe('persistência em disco', () => {
  after(() => fs.rmSync(DATA_DIR, { recursive: true, force: true }));

  it('grava o catálogo no DATA_DIR configurado', () => {
    resetResolutions();
    const entry = addResolution({ signature: 'persistida', repository: 'org/repo', solution: 'sobrevive ao restart' });

    assert.equal(config.RESOLUTIONS_FILE, path.join(DATA_DIR, 'resolutions.json'));
    const emDisco = JSON.parse(fs.readFileSync(config.RESOLUTIONS_FILE, 'utf8'));
    assert.equal(emDisco[entry.id].solution, 'sobrevive ao restart');
    assert.equal(emDisco[entry.id].signature, 'persistida');
  });
});
