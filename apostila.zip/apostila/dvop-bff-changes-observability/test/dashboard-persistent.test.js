// Forces persistent (on-disk) uploads so the disk-backed CSV paths in the
// dashboard route are exercised (selection, read, upload-to-disk).
import { describe, it, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const UPLOAD_DIR = path.join(os.tmpdir(), 'dvop-test-uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

process.env.NODE_ENV = 'test';
process.env.BASE_PATH = '/painel';
process.env.UPLOAD_FOLDER = UPLOAD_DIR;

const { default: app } = await import('../src/app.js');
const { config } = await import('../src/config/env.js');
const request = (await import('supertest')).default;
const nock = (await import('nock')).default;

const API = 'https://api.github.com';

async function authedAgent() {
  const agent = request.agent(app);
  nock(API).get('/user').reply(200, { login: 'octocat' });
  const res = await agent.post('/painel/set-token').send({ token: 'ghp_validtoken1234567890' });
  assert.equal(res.status, 200);
  return agent;
}

describe('dashboard with persistent uploads', () => {
  afterEach(() => nock.cleanAll());

  it('persists an uploaded CSV to disk', async () => {
    const agent = await authedAgent();
    const csv = 'parent,planned_start_date,description\nCHG1,2026-06-19 10:00,nourl';
    const res = await agent.post('/painel/').attach('csv_file', Buffer.from(csv), 'upload.csv');
    assert.equal(res.status, 302);
  });

  it('selects a saved CSV from disk and renders it', async () => {
    const name = 'saved-list.csv';
    fs.writeFileSync(
      path.join(config.UPLOAD_FOLDER, name),
      'parent,planned_start_date,description\nCHGZ,2026-06-19 08:00,nourl',
    );
    const agent = await authedAgent();
    const res = await agent.get('/painel/?csv=' + name);
    assert.equal(res.status, 200);
    assert.match(res.text, /Acompanhamento de Changes/);
  });

  it('ignores an unsafe ?csv selection', async () => {
    const agent = await authedAgent();
    const res = await agent.get('/painel/?csv=' + encodeURIComponent('../evil.csv'));
    assert.equal(res.status, 200);
  });
});
