import { describe, it, before, after, afterEach } from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';

const { getRunInfoFromUrl } = await import('../src/services/github.js');
const nock = (await import('nock')).default;

const API = 'https://api.github.com';
const RUN_URL = 'https://github.com/owner/repo/actions/runs/123';
const RUN_PATH = '/repos/owner/repo/actions/runs/123';

describe('getRunInfoFromUrl', () => {
  before(() => nock.disableNetConnect());
  after(() => nock.enableNetConnect());
  afterEach(() => nock.cleanAll());

  it('maps a successful run', async () => {
    nock(API).get(RUN_PATH).reply(200, { status: 'completed', conclusion: 'success', run_attempt: 1 });
    const info = await getRunInfoFromUrl(RUN_URL);
    assert.equal(info.status, 'Success');
    assert.equal(info.badge_class, 'success');
    assert.equal(info.reruns, 1);
  });

  it('resolves the executor name and e-mail from triggering_actor', async () => {
    nock(API).get(RUN_PATH).reply(200, {
      status: 'completed',
      conclusion: 'success',
      run_attempt: 1,
      actor: { login: 'octocat' },
      triggering_actor: { login: 'rerunner' },
    });
    nock(API)
      .get('/users/rerunner')
      .reply(200, { login: 'rerunner', name: 'Re Runner', email: 're.runner@example.com' });
    const info = await getRunInfoFromUrl(RUN_URL);
    assert.equal(info.executor, 'Re Runner');
    assert.equal(info.executorEmail, 're.runner@example.com');
  });

  it('resolves logins containing underscores (Enterprise Managed Users)', async () => {
    nock(API).get(RUN_PATH).reply(200, {
      status: 'completed',
      conclusion: 'success',
      run_attempt: 1,
      triggering_actor: { login: 'ehabinoski_bradesco' },
    });
    nock(API)
      .get('/users/ehabinoski_bradesco')
      .reply(200, { login: 'ehabinoski_bradesco', name: 'EVALDO LUIZ HABINOSKI', email: 'evaldo.habinoski@bradesco.com.br' });
    const info = await getRunInfoFromUrl(RUN_URL);
    assert.equal(info.executor, 'EVALDO LUIZ HABINOSKI');
    assert.equal(info.executorEmail, 'evaldo.habinoski@bradesco.com.br');
  });

  it('uses actor when triggering_actor is absent', async () => {
    nock(API)
      .get(RUN_PATH)
      .reply(200, { status: 'completed', conclusion: 'success', run_attempt: 1, actor: { login: 'thedev' } });
    nock(API).get('/users/thedev').reply(200, { login: 'thedev', name: 'The Developer' });
    const info = await getRunInfoFromUrl(RUN_URL);
    assert.equal(info.executor, 'The Developer');
  });

  it('falls back to the login when the profile has no registered name', async () => {
    nock(API)
      .get(RUN_PATH)
      .reply(200, { status: 'completed', conclusion: 'success', run_attempt: 1, actor: { login: 'nonameuser' } });
    nock(API).get('/users/nonameuser').reply(200, { login: 'nonameuser', name: null, email: null });
    const info = await getRunInfoFromUrl(RUN_URL);
    assert.equal(info.executor, 'nonameuser');
    assert.equal(info.executorEmail, '');
  });

  it('falls back to the login when the user lookup fails', async () => {
    nock(API)
      .get(RUN_PATH)
      .reply(200, { status: 'completed', conclusion: 'success', run_attempt: 1, actor: { login: 'brokenlookup' } });
    nock(API).get('/users/brokenlookup').reply(404, { message: 'Not Found' });
    const info = await getRunInfoFromUrl(RUN_URL);
    assert.equal(info.executor, 'brokenlookup');
    assert.equal(info.executorEmail, '');
  });

  it('maps a failed run', async () => {
    nock(API).get(RUN_PATH).reply(200, { status: 'completed', conclusion: 'failure', run_attempt: 2 });
    const info = await getRunInfoFromUrl(RUN_URL);
    assert.equal(info.status, 'Failure');
    assert.equal(info.badge_class, 'fail');
    assert.equal(info.reruns, 2);
  });

  it('maps a cancelled run', async () => {
    nock(API).get(RUN_PATH).reply(200, { status: 'completed', conclusion: 'cancelled' });
    const info = await getRunInfoFromUrl(RUN_URL);
    assert.equal(info.status, 'Cancelled');
    assert.equal(info.badge_class, 'cancelled');
  });

  it('maps an in-progress run', async () => {
    nock(API).get(RUN_PATH).reply(200, { status: 'in_progress' });
    const info = await getRunInfoFromUrl(RUN_URL);
    assert.equal(info.status, 'In Progress');
    assert.equal(info.badge_class, 'progress');
  });

  it('maps a 404 to "Não Encontrado"', async () => {
    nock(API).get(RUN_PATH).reply(404, { message: 'Not Found' });
    const info = await getRunInfoFromUrl(RUN_URL);
    assert.equal(info.status, 'Não Encontrado');
    assert.equal(info.badge_class, 'unknown');
  });

  it('maps a 401 to "Token Inválido"', async () => {
    nock(API).get(RUN_PATH).reply(401, { message: 'Bad credentials' });
    const info = await getRunInfoFromUrl(RUN_URL);
    assert.equal(info.status, 'Token Inválido');
  });

  it('returns "Invalid URL" for non-run URLs without calling the API', async () => {
    const info = await getRunInfoFromUrl('https://example.com/not/a/run');
    assert.equal(info.status, 'Invalid URL');
  });
});
