// basePath lido de um atributo data no <body> (arquivo estático, sem EJS)
const basePath = document.body.dataset.basePath || '';

// Auto refresh selectable control
let refreshTimer = null;
let isRefreshing = false;

const dashboardStateByUrl = {};

function ensureUrlState(url) {
  if (!url) return { comment: '', rerunChecked: false };
  if (!dashboardStateByUrl[url]) dashboardStateByUrl[url] = { comment: '', rerunChecked: false };
  return dashboardStateByUrl[url];
}

function getRowUrl(row) {
  const link = row ? row.querySelector('td:nth-child(4) a') : null;
  return link ? link.getAttribute('href') || '' : '';
}

function applyStateToCommentButton(btn, url) {
  if (!btn || !url) return;
  const state = ensureUrlState(url);
  btn.title = state.comment || '';
  btn.setAttribute('data-comment', state.comment || '');
  if (state.comment) {
    btn.innerText = '📌';
    btn.setAttribute('data-has-comment', 'true');
  } else {
    btn.innerText = '🗨️';
    btn.setAttribute('data-has-comment', 'false');
  }
}

function syncRenderedStateFromTable() {
  document.querySelectorAll('#runs tbody tr').forEach((row) => {
    const url = getRowUrl(row);
    if (!url) return;

    const checkbox = row.querySelector('.rerun-checkbox');
    const commentBtn = row.querySelector('.comment-btn');
    const state = ensureUrlState(url);

    if (checkbox) {
      state.rerunChecked = checkbox.checked === true;
      checkbox.checked = state.rerunChecked;
    }

    if (commentBtn) {
      const commentFromAttr = commentBtn.getAttribute('data-comment') || '';
      if (commentFromAttr && !state.comment) state.comment = commentFromAttr;
      applyStateToCommentButton(commentBtn, url);
    }
  });
}

// Função para atualizar apenas os dados dos workflows sem recarregar a página
async function updateWorkflowData() {
  if (isRefreshing) return; // Evita múltiplas atualizações simultâneas

  isRefreshing = true;
  setRefreshing(true);

  try {
    console.log('🔄 Atualizando dados dos workflows...');
    const response = await fetch(`${basePath}/api/workflow-data`);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();

    if (data.success && data.rows) {
      // Atualizar a tabela com os novos dados
      updateTable(data.rows);

      // Atualizar informações do arquivo
      const csvFileNameEl = document.querySelector('.subtitle');
      if (csvFileNameEl && csvFileNameEl.innerText.includes('Arquivo atual:')) {
        csvFileNameEl.innerHTML = `Arquivo atual: ${data.csv_filename}`;
      }

      // Atualizar informação de última atualização
      const lastUpdateEl = document.getElementById('last-update-info');
      if (lastUpdateEl) {
        const now = new Date();
        lastUpdateEl.textContent = `Última atualização: ${now.toLocaleTimeString()}`;
      }

      console.log(`✅ Dados atualizados: ${data.rows.length} workflows`);
    } else {
      console.error('❌ Resposta inválida do servidor:', data);
    }
  } catch (error) {
    console.error('❌ Erro ao atualizar workflows:', error);
    // Em caso de erro, não fazer nada - manter os dados atuais
  } finally {
    isRefreshing = false;
    setRefreshing(false);
  }
}

// Função para atualizar a tabela com novos dados
function updateTable(rows) {
  const tbody = document.querySelector('#runs tbody');
  if (!tbody) return;

  // Limpar tabela atual
  tbody.innerHTML = '';

  // Adicionar novas linhas
  rows.forEach((row, idx) => {
    const state = ensureUrlState(row.url);
    if (typeof row.comment === 'string') state.comment = row.comment;
    if (typeof row.rerunChecked === 'boolean') state.rerunChecked = row.rerunChecked;

    const executorCell =
      row.executor && row.executorEmail
        ? `<a class="link" href="https://teams.microsoft.com/l/chat/0/0?users=${encodeURIComponent(row.executorEmail)}" target="_blank" title="Conversar com ${(row.executor || '').replace(/"/g, '&quot;')} no Teams">${row.executor}</a>`
        : row.executor || '';

    const aiBtn =
      row.badge_class === 'fail'
        ? `<button class="ai-insumo-btn" title="Analisar a falha com IA (AgentiX)" data-url="${row.url}" data-change="${(row.CHANGE || '').replace(/"/g, '&quot;')}" data-status="${row.status}">🤖</button>`
        : '';

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><div class="meta">${idx + 1}</div></td>
      <td><div class="meta">${row.CHANGE || ''}</div></td>
      <td><div class="meta">${row['HORÁRIO'] || ''}</div></td>
      <td><a class="link" href="${row.url}" target="_blank">${row.url}</a></td>
      <td><span class="badge ${row.badge_class}">${row.status}</span>${aiBtn}</td>
      <td><div class="meta">${executorCell}</div></td>
      <td>${row.reruns || ''}</td>
      <td><input type="checkbox" class="rerun-checkbox" data-url="${row.url}" ${state.rerunChecked ? 'checked' : ''}></td>
      <td><button class="comment-btn" title="${(state.comment || '').replace(/"/g, '&quot;')}" data-comment="${(state.comment || '').replace(/"/g, '&quot;')}" data-has-comment="${state.comment ? 'true' : 'false'}" data-url="${row.url}">${state.comment ? '📌' : '🗨️'}</button></td>
    `;
    tbody.appendChild(tr);
  });

  // Atualizar contadores
  document.getElementById('totalCount').textContent = rows.length;

  // Reaplica filtros e atualiza ícones de comentários e checkboxes
  filterTable();
  syncRenderedStateFromTable();
  updateUniqueChangesCount();
}

function applyRefreshInterval(minutes) {
  if (refreshTimer) {
    try {
      clearInterval(refreshTimer);
    } catch (e) {}
    refreshTimer = null;
  }
  const m = parseFloat(minutes);
  if (!Number.isNaN(m) && m > 0) {
    // Usar updateWorkflowData em vez de location.reload()
    const intervalMs = m * 60 * 1000;
    refreshTimer = setInterval(() => updateWorkflowData(), intervalMs);
    const timeText = m < 1 ? `${Math.round(m * 60)} segundos` : `${m} minutos`;
    console.log(`⏰ Auto-refresh configurado para ${timeText}`);
  }
}

function setRefreshInterval(val) {
  localStorage.setItem('dashboardRefreshMinutes', String(val));
  applyRefreshInterval(val);
}

function initRefreshControl() {
  const sel = document.getElementById('refresh-select');
  if (!sel) return;
  const saved = localStorage.getItem('dashboardRefreshMinutes') || '15';
  const allowed = ['0.5', '1', '2', '5', '10', '15'];
  const use = allowed.includes(saved) ? saved : '15';
  sel.value = use;
  applyRefreshInterval(use);
}

// Export to real Excel (.xlsx) via backend
async function exportTableToXLSX() {
  // Buscar todas as linhas da tabela (incluindo as ocultas por filtros)
  const allRows = document.querySelectorAll('#runs tbody tr');
  const exportData = [];

  allRows.forEach((row, index) => {
    const cells = row.querySelectorAll('td');
    if (cells.length < 9) return; // Garantir que a linha tem todas as colunas

    // Extrair dados de cada célula
    const changeText = cells[1].textContent.trim();
    const horarioText = cells[2].textContent.trim();
    const urlLink = cells[3].querySelector('a');
    const url = urlLink ? urlLink.getAttribute('href') : '';
    const statusBadge = cells[4].querySelector('.badge');
    const statusText = statusBadge ? statusBadge.textContent.trim() : '';
    // cells[6] = Attempts (ignorado na exportação)
    const state = url ? ensureUrlState(url) : { rerunChecked: false, comment: '' };
    const rerunCheckedForUrl = state.rerunChecked === true;
    const commentBtn = cells[8].querySelector('.comment-btn');
    const commentUrl = commentBtn ? commentBtn.getAttribute('data-url') : url;
    const comment = commentUrl ? ensureUrlState(commentUrl).comment : '';

    exportData.push({
      index: index + 1,
      CHANGE: changeText,
      HORARIO: horarioText,
      url: url,
      status: statusText,
      isFailure: !!(statusBadge && statusBadge.classList.contains('fail')),
      rerunChecked: rerunCheckedForUrl,
      comment: comment,
    });
  });

  if (exportData.length === 0) {
    alert('Nenhuma linha encontrada para exportar.');
    return;
  }

  try {
    const resp = await fetch(`${basePath}/export/xlsx`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows: exportData }),
    });
    if (!resp.ok) {
      alert('Falha ao gerar XLSX: ' + resp.status);
      return;
    }
    const blob = await resp.blob();
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'painel_export.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } catch (e) {
    alert('Erro ao exportar XLSX: ' + e);
  }
}

// Export only rows with Reruns checked
async function exportRerunsToXLSX() {
  // Buscar todas as linhas da tabela (incluindo as ocultas por filtros)
  const allRows = document.querySelectorAll('#runs tbody tr');
  const exportData = [];

  allRows.forEach((row) => {
    const cells = row.querySelectorAll('td');
    if (cells.length < 9) return;

    // Obter URL da linha
    const urlLink = cells[3].querySelector('a');
    const url = urlLink ? urlLink.getAttribute('href') : '';

    // Verificar se esta URL tem rerun marcado no localStorage
    if (!url || !ensureUrlState(url).rerunChecked) return;

    // Extrair dados de cada célula
    const changeText = cells[1].textContent.trim();
    const horarioText = cells[2].textContent.trim();
    const statusBadge = cells[4].querySelector('.badge');
    const statusText = statusBadge ? statusBadge.textContent.trim() : '';
    const commentBtn = cells[8].querySelector('.comment-btn');
    const commentUrl = commentBtn ? commentBtn.getAttribute('data-url') : url;
    const comment = commentUrl ? ensureUrlState(commentUrl).comment : '';

    exportData.push({
      index: exportData.length + 1, // Renumerar sequencialmente
      CHANGE: changeText,
      HORARIO: horarioText,
      url: url,
      status: statusText,
      isFailure: !!(statusBadge && statusBadge.classList.contains('fail')),
      rerunChecked: true,
      comment: comment,
    });
  });

  if (exportData.length === 0) {
    alert('Nenhuma linha com Reruns marcado encontrada. Marque os checkboxes de Reruns e tente novamente.');
    return;
  }

  try {
    const resp = await fetch(`${basePath}/export/xlsx`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows: exportData }),
    });
    if (!resp.ok) {
      alert('Falha ao gerar XLSX: ' + resp.status);
      return;
    }
    const blob = await resp.blob();
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'painel_export_reruns.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } catch (e) {
    alert('Erro ao exportar Reruns XLSX: ' + e);
  }
}

// Export rows where Status is Failure OR Reruns checkbox is checked
async function exportFailuresAndRerunsToXLSX() {
  const allRows = document.querySelectorAll('#runs tbody tr');
  const exportData = [];

  allRows.forEach((row) => {
    const cells = row.querySelectorAll('td');
    if (cells.length < 9) return;

    const urlLink = cells[3].querySelector('a');
    const url = urlLink ? urlLink.getAttribute('href') : '';

    const statusBadge = cells[4].querySelector('.badge');
    const statusText = statusBadge ? statusBadge.textContent.trim() : '';
    const isFailure = statusText === 'Failure';
    const isRerunChecked = url ? ensureUrlState(url).rerunChecked : false;

    if (!isFailure && !isRerunChecked) return;

    const changeText = cells[1].textContent.trim();
    const horarioText = cells[2].textContent.trim();
    const commentBtn = cells[8].querySelector('.comment-btn');
    const commentUrl = commentBtn ? commentBtn.getAttribute('data-url') : url;
    const comment = commentUrl ? ensureUrlState(commentUrl).comment : '';

    exportData.push({
      index: exportData.length + 1,
      CHANGE: changeText,
      HORARIO: horarioText,
      url: url,
      status: statusText,
      rerunChecked: isRerunChecked,
      comment: comment,
    });
  });

  if (exportData.length === 0) {
    alert('Nenhuma linha com Falha ou Reruns marcado encontrada.');
    return;
  }

  try {
    const resp = await fetch(`${basePath}/export/xlsx`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows: exportData }),
    });
    if (!resp.ok) {
      alert('Falha ao gerar XLSX: ' + resp.status);
      return;
    }
    const blob = await resp.blob();
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'painel_export_failures_reruns.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } catch (e) {
    alert('Erro ao exportar Falhas/Reruns XLSX: ' + e);
  }
}

// Roda a análise de falha na AgentiX: o backend baixa os logs brutos da
// execução no GitHub, envia como insumo para o agente configurado e devolve o
// texto da análise. Exibido em modal (sem alert, sem handler inline — CSP estrita).
async function analyzeWithAgentix(btn) {
  const url = btn.getAttribute('data-url');
  if (!url) return;
  const change = btn.getAttribute('data-change') || '';
  const status = btn.getAttribute('data-status') || '';

  const original = btn.textContent;
  btn.textContent = '⏳';
  btn.disabled = true;
  openAiModal(
    change || url,
    `Baixando os logs da execução e consultando a AgentiX...
Isso pode levar alguns instantes.`,
  );
  // Zera o que sobrou da análise anterior antes de qualquer coisa: sem isto,
  // uma análise que falha mantém os botões e o texto digitado da execução
  // anterior, e a resolução acabaria registrada contra a falha errada.
  resetResolveUI();
  try {
    const resp = await fetch(`${basePath}/api/agentix-analyze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, change, status }),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
    setAiModalBody(formatAnalysis(data.analysis) || data.raw || 'A AgentiX não retornou nenhuma análise.');
    currentAnalysis = { ...data, url, change, status };
    showRelatedResolutions(data.related);
    enableResolve(Boolean(data.analysis));
  } catch (e) {
    setAiModalBody(`Não foi possível concluir a análise.

${e.message}`);
  } finally {
    btn.textContent = original;
    btn.disabled = false;
  }
}

// Renderiza o JSON do agente (status, category, confidence, summary,
// root_cause, evidence[], suggested_actions[], affected_components[]) como
// texto legível. O modal usa textContent, então nada aqui vira HTML.
function formatAnalysis(analysis) {
  if (!analysis || typeof analysis !== 'object') return '';

  const parts = [];
  if (analysis.summary) parts.push(analysis.summary);

  const selo = [analysis.category, analysis.confidence && `confiança ${analysis.confidence}`, analysis.status]
    .filter(Boolean)
    .join(' · ');
  if (selo) parts.push(selo);

  if (analysis.root_cause) parts.push(`CAUSA PROVÁVEL\n${analysis.root_cause}`);

  if (Array.isArray(analysis.evidence) && analysis.evidence.length) {
    const linhas = analysis.evidence.map((e) => `• ${e.line || ''}${e.why ? `\n  → ${e.why}` : ''}`);
    parts.push(`EVIDÊNCIAS\n${linhas.join('\n')}`);
  }

  if (Array.isArray(analysis.suggested_actions) && analysis.suggested_actions.length) {
    parts.push(`PRÓXIMOS PASSOS\n${analysis.suggested_actions.map((a, i) => `${i + 1}. ${a}`).join('\n')}`);
  }

  if (Array.isArray(analysis.affected_components) && analysis.affected_components.length) {
    parts.push(`COMPONENTES AFETADOS\n${analysis.affected_components.join(', ')}`);
  }

  return parts.join('\n\n');
}

// Contexto da análise aberta no modal, usado ao registrar a resolução.
let currentAnalysis = null;

// Falhas se repetem. Quando o catálogo já tem uma resolução com a mesma
// assinatura, ela vale mais do que a análise — por isso aparece acima dela.
function showRelatedResolutions(related) {
  const box = document.getElementById('ai-related');
  const body = document.getElementById('ai-related-body');
  if (!box || !body) return;

  if (!Array.isArray(related) || !related.length) {
    box.hidden = true;
    body.textContent = '';
    return;
  }

  body.textContent = related
    .map((r) => {
      const quando = String(r.createdAt || '').slice(0, 10);
      const quem = r.author ? ` por ${r.author}` : '';
      const tipo = r.match === 'exact' ? 'mesma falha' : 'caso parecido';
      return `• [${tipo}] ${r.solution}
  registrado em ${quando}${quem}${r.change ? ` — ${r.change}` : ''}`;
    })
    .join(`

`);
  box.hidden = false;
}

function enableResolve(podeResolver) {
  const toggle = document.getElementById('resolve-toggle');
  if (toggle) toggle.hidden = !podeResolver;
  const save = document.getElementById('resolve-save');
  if (save) save.hidden = true;
  const form = document.getElementById('resolve-form');
  if (form) form.classList.remove('active');
}

// Volta o painel de resolução ao estado inicial: sem contexto, sem registros
// relacionados, sem botões e com os campos limpos.
function resetResolveUI() {
  currentAnalysis = null;
  showRelatedResolutions([]);
  enableResolve(false);
  const causa = document.getElementById('resolve-cause');
  if (causa) causa.value = '';
  const solucao = document.getElementById('resolve-solution');
  if (solucao) solucao.value = '';
}

function toggleResolveForm() {
  const form = document.getElementById('resolve-form');
  if (!form || !currentAnalysis) return;

  const abrindo = !form.classList.contains('active');
  form.classList.toggle('active', abrindo);
  document.getElementById('resolve-save').hidden = !abrindo;
  if (!abrindo) return;

  // Pré-preenche com a causa da IA — editável de propósito: o que se registra
  // é o que a pessoa endossa, não o palpite do agente.
  const causa = document.getElementById('resolve-cause');
  if (causa && !causa.value) causa.value = currentAnalysis.analysis?.root_cause || '';
  document.getElementById('resolve-solution').focus();
}

async function saveResolution(btn) {
  if (!currentAnalysis) return;
  const cause = document.getElementById('resolve-cause').value.trim();
  const solution = document.getElementById('resolve-solution').value.trim();
  if (!solution) {
    alert('Descreva o que resolveu a falha.');
    return;
  }

  const original = btn.textContent;
  btn.textContent = 'Salvando...';
  btn.disabled = true;
  try {
    const resp = await fetch(`${basePath}/api/resolutions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url: currentAnalysis.url,
        change: currentAnalysis.change,
        signature: currentAnalysis.signature,
        stepSignature: currentAnalysis.stepSignature,
        repository: currentAnalysis.repository,
        category: currentAnalysis.analysis?.category,
        problem: currentAnalysis.analysis?.summary,
        cause,
        agentCause: currentAnalysis.analysis?.root_cause || '',
        solution,
        sessionId: currentAnalysis.sessionId,
      }),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);

    resetResolveUI();
    setAiModalBody('Resolução registrada. Ela aparecerá nas próximas análises desta mesma falha.');
  } catch (e) {
    alert('Não foi possível registrar a resolução: ' + e.message);
  } finally {
    btn.textContent = original;
    btn.disabled = false;
  }
}

function openAiModal(title, body) {
  const modal = document.getElementById('ai-modal');
  if (!modal) return;
  const titleEl = document.getElementById('ai-modal-title');
  if (titleEl) titleEl.textContent = `Análise de falha — ${title}`;
  setAiModalBody(body);
  modal.classList.add('active');
}

function setAiModalBody(text) {
  const bodyEl = document.getElementById('ai-modal-body');
  if (bodyEl) bodyEl.textContent = text;
}

function closeAiModal() {
  const modal = document.getElementById('ai-modal');
  if (modal) modal.classList.remove('active');
  resetResolveUI();
}

function updateCommentIcons() {
  document.querySelectorAll('.comment-btn').forEach((btn) => {
    const url = btn.getAttribute('data-url') || '';
    applyStateToCommentButton(btn, url);
  });
}

async function toggleRerun(checkbox) {
  const url = checkbox.dataset.url;
  if (!url) return;
  const nextValue = checkbox.checked === true;
  const state = ensureUrlState(url);
  const previousValue = state.rerunChecked;
  state.rerunChecked = nextValue;
  try {
    const resp = await fetch(`${basePath}/api/dashboard-annotation`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, rerunChecked: nextValue }),
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  } catch (e) {
    state.rerunChecked = previousValue;
    checkbox.checked = previousValue === true;
    alert('Erro ao salvar rerun compartilhado. Tente novamente.');
  }
}

function loadRerunsFromStorage() {
  document.querySelectorAll('.rerun-checkbox').forEach((checkbox) => {
    const url = checkbox.dataset.url;
    if (url) checkbox.checked = ensureUrlState(url).rerunChecked === true;
  });
}

let currentCommentUrl = null;
function editComment(btn) {
  let url = '';
  if (btn && btn.nodeType === 1) {
    url = btn.getAttribute('data-url') || '';
    if (!url) {
      const row = btn.closest('tr');
      const link = row ? row.querySelector('td:nth-child(4) a') : null;
      url = link ? link.getAttribute('href') : '';
    }
  }
  currentCommentUrl = url || null;
  const current = currentCommentUrl ? ensureUrlState(currentCommentUrl).comment : '';
  document.getElementById('comment-textarea').value = current;
  document.getElementById('comment-modal').classList.add('active');
  document.getElementById('comment-textarea').focus();
}
function closeCommentModal() {
  document.getElementById('comment-modal').classList.remove('active');
  document.getElementById('comment-textarea').value = '';
  currentCommentUrl = null;
}
async function saveComment() {
  if (!currentCommentUrl) return;
  const comment = document.getElementById('comment-textarea').value.trim();
  const state = ensureUrlState(currentCommentUrl);
  const previousComment = state.comment;
  state.comment = comment;
  updateCommentIcons();
  try {
    const resp = await fetch(`${basePath}/api/dashboard-annotation`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: currentCommentUrl, comment }),
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    closeCommentModal();
  } catch (e) {
    state.comment = previousComment;
    updateCommentIcons();
    alert('Erro ao salvar comentário compartilhado. Tente novamente.');
  }
}
document.addEventListener('click', (e) => {
  const modal = document.getElementById('comment-modal');
  if (e.target === modal) closeCommentModal();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeCommentModal();
});
document.addEventListener('DOMContentLoaded', () => {
  const textarea = document.getElementById('comment-textarea');
  if (textarea) {
    textarea.addEventListener('keydown', (e) => {
      if (e.ctrlKey && e.key === 'Enter') saveComment();
    });
  }
});

function restoreFilters() {
  const savedSearch = localStorage.getItem('dashboardSearch') || '';
  const savedResults = JSON.parse(localStorage.getItem('dashboardResults') || '[]');
  const qEl = document.getElementById('q');
  if (qEl) qEl.value = savedSearch;
  if (savedResults.length > 0) {
    document.querySelectorAll('#result-options input[type="checkbox"]').forEach((checkbox) => {
      checkbox.checked = savedResults.includes(checkbox.value);
    });
  }
  filterTable();
}

function timeToMinutes(hm) {
  if (!hm) return null;
  const parts = hm.split(':');
  if (parts.length < 2) return null;
  const h = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10);
  if (Number.isNaN(h) || Number.isNaN(m)) return null;
  return h * 60 + m;
}
function filterTable() {
  const q = (document.getElementById('q').value || '').toLowerCase();
  const selectedResults = Array.from(
    document.querySelectorAll('#result-options input[type="checkbox"]:checked'),
  ).map((cb) => cb.value);
  const rows = document.querySelectorAll('#runs tbody tr');
  const selectedHours = Array.from(document.getElementsByClassName('hour-btn'))
    .map((btn, idx) => (btn.classList.contains('selected') ? idx : -1))
    .filter((i) => i !== -1);
  localStorage.setItem('dashboardSearch', q);
  localStorage.setItem('dashboardResults', JSON.stringify(selectedResults));
  let visibleCount = 0;
  rows.forEach((r) => {
    const text = r.innerText.toLowerCase();
    const badgeEl = r.querySelector('.badge');
    let category = 'Unknown';
    if (badgeEl) {
      // Primeiro tenta detectar por texto do status se badge class não está correto
      const statusText = badgeEl.innerText.trim();
      if (statusText === 'Cancelled') {
        category = 'Cancelled';
      } else if (badgeEl.classList.contains('success')) {
        category = 'Success';
      } else if (badgeEl.classList.contains('fail')) {
        category = 'Failure';
      } else if (badgeEl.classList.contains('progress')) {
        category = 'In Progress';
      } else if (badgeEl.classList.contains('cancelled')) {
        category = 'Cancelled';
      } else {
        category = 'Unknown';
      }
    }
    const timeEl = r.querySelector('td:nth-child(3) .meta');
    const timeStr = timeEl ? timeEl.innerText.trim() : '';
    let rowHM = '';
    try {
      const parts = timeStr.split(' ');
      if (parts.length >= 2) rowHM = parts[1].slice(0, 5);
      else if (/^\d{2}:\d{2}/.test(timeStr)) rowHM = timeStr.slice(0, 5);
    } catch (e) {
      rowHM = '';
    }
    const rowMin = timeToMinutes(rowHM); // reserved for future use
    const matchesSearch = text.includes(q);
    const matchesResult = selectedResults.length === 0 || selectedResults.includes(category);
    let matchesTime = true;
    if (selectedHours.length > 0) {
      try {
        const rowTime = timeStr.split(' ')[1] || timeStr;
        const rowHour = parseInt(rowTime.split(':')[0], 10);
        matchesTime = selectedHours.includes(rowHour);
      } catch (e) {
        matchesTime = false;
      }
    }
    const isVisible = matchesSearch && matchesResult && matchesTime;
    r.style.display = isVisible ? '' : 'none';
    if (isVisible) visibleCount++;
  });
  document.getElementById('visibleCount').textContent = visibleCount;
  updateUniqueChangesCount();
}

// Atualiza contador de Changes únicas (sem repetir) considerando todas as linhas da tabela
function updateUniqueChangesCount() {
  const allRows = document.querySelectorAll('#runs tbody tr');
  const changes = new Set();
  allRows.forEach((r) => {
    const changeEl = r.querySelector('td:nth-child(2) .meta');
    const val = changeEl ? (changeEl.innerText || '').trim() : '';
    if (val) changes.add(val);
  });
  const el = document.getElementById('uniqueChangesCount');
  if (el) el.textContent = String(changes.size);
  updateCompletedChangesCount();
}

// Conta changes "concluídas" e "faltantes". Uma change só é concluída quando
// TODOS os seus workflows (linhas com o mesmo valor de CHANGE) estão em Success;
// faltantes são as demais changes únicas (total únicas − concluídas).
function updateCompletedChangesCount() {
  const byChange = new Map(); // change -> { total, success }
  document.querySelectorAll('#runs tbody tr').forEach((r) => {
    const changeEl = r.querySelector('td:nth-child(2) .meta');
    const change = changeEl ? (changeEl.innerText || '').trim() : '';
    if (!change) return;
    const badge = r.querySelector('.badge');
    const isSuccess = badge ? badge.classList.contains('success') : false;
    const entry = byChange.get(change) || { total: 0, success: 0 };
    entry.total += 1;
    if (isSuccess) entry.success += 1;
    byChange.set(change, entry);
  });
  let completed = 0;
  byChange.forEach((e) => {
    if (e.total > 0 && e.success === e.total) completed += 1;
  });
  const completedEl = document.getElementById('completedChangesCount');
  if (completedEl) completedEl.textContent = String(completed);
  const pendingEl = document.getElementById('pendingChangesCount');
  if (pendingEl) pendingEl.textContent = String(byChange.size - completed);
}

function toggleTimeFilter() {
  const options = document.getElementById('time-options');
  const isVisible = options.style.display !== 'none';
  options.style.display = isVisible ? 'none' : 'block';
  if (!isVisible) {
    const closeMenu = (e) => {
      if (!e.target.closest('.result-filter') && !e.target.closest('.hour-list')) {
        options.style.display = 'none';
        document.removeEventListener('click', closeMenu);
      }
    };
    setTimeout(() => document.addEventListener('click', closeMenu), 0);
  }
}
function clearTimeFilter() {
  const container = document.getElementById('hour-buttons');
  if (container) {
    Array.from(container.getElementsByClassName('hour-btn')).forEach((btn) =>
      btn.classList.remove('selected'),
    );
  }
  localStorage.removeItem('dashboardSelectedHours');
  filterTable();
}
function toggleResultFilter() {
  const options = document.getElementById('result-options');
  const isVisible = options.style.display !== 'none';
  options.style.display = isVisible ? 'none' : 'block';
  if (!isVisible) {
    const closeMenu = (e) => {
      if (!e.target.closest('.result-filter')) {
        options.style.display = 'none';
        document.removeEventListener('click', closeMenu);
      }
    };
    setTimeout(() => document.addEventListener('click', closeMenu), 0);
  }
}
window.addEventListener('keydown', (e) => {
  if (e.key === '/' && document.activeElement.tagName !== 'INPUT') {
    e.preventDefault();
    document.getElementById('q').focus();
  }
});

function setRefreshing(flag) {
  const btn = document.getElementById('refresh-btn');
  if (!btn) return;
  if (flag) btn.classList.add('refreshing');
  else btn.classList.remove('refreshing');
}
function triggerRefresh() {
  updateWorkflowData();
}
function initHourButtons() {
  const container = document.getElementById('hour-buttons');
  if (!container) return;
  for (let i = 0; i < 24; i++) {
    const btn = document.createElement('button');
    btn.className = 'hour-btn';
    btn.textContent = `${String(i).padStart(2, '0')}:00`;
    btn.onclick = () => toggleHourFilter(i);
    container.appendChild(btn);
  }
  try {
    const savedHours = JSON.parse(localStorage.getItem('dashboardSelectedHours') || '[]');
    savedHours.forEach((hour) => {
      if (hour >= 0 && hour < 24) {
        const btn = container.children[hour];
        if (btn) btn.classList.add('selected');
      }
    });
  } catch (e) {
    console.warn('Failed to restore hour selection', e);
  }
}
function toggleHourFilter(hour) {
  const container = document.getElementById('hour-buttons');
  if (!container) return;
  const buttons = container.getElementsByClassName('hour-btn');
  const clickedBtn = buttons[hour];
  clickedBtn.classList.toggle('selected');
  const selectedHours = Array.from(buttons)
    .map((btn, idx) => (btn.classList.contains('selected') ? idx : -1))
    .filter((idx) => idx !== -1);
  if (selectedHours.length > 0) {
    localStorage.setItem('dashboardSelectedHours', JSON.stringify(selectedHours));
  } else {
    localStorage.removeItem('dashboardSelectedHours');
  }
  filterTable();
}
function initLastUpdateInfo() {
  const lastUpdateEl = document.getElementById('last-update-info');
  if (lastUpdateEl) {
    const now = new Date();
    lastUpdateEl.textContent = `Carregado em: ${now.toLocaleTimeString()}`;
  }
}

window.addEventListener('load', () => {
  initHourButtons();
  restoreFilters();
  syncRenderedStateFromTable();
  updateCommentIcons();
  loadRerunsFromStorage();
  initRefreshControl();
  initLastUpdateInfo();
});

const tokenSettingsBtn = document.getElementById('tokenSettings');
if (tokenSettingsBtn) {
  tokenSettingsBtn.addEventListener('click', () => {
    document.getElementById('tokenModal').style.display = 'flex';
  });
}

function closeTokenModal() {
  document.getElementById('tokenModal').style.display = 'none';
}

async function removeToken() {
  try {
    const response = await fetch(`${basePath}/remove-token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });

    if (response.ok) {
      window.location.reload();
    }
  } catch (error) {
    alert('Erro ao remover token');
  }
}

// Fechar modal ao clicar fora
const tokenModalEl = document.getElementById('tokenModal');
if (tokenModalEl) {
  tokenModalEl.addEventListener('click', (e) => {
    if (e.target.id === 'tokenModal') {
      closeTokenModal();
    }
  });
}

// Fechar modal com ESC
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeTokenModal();
  }
});

// shared-data refresh removed

// remover função de limpar cache (não utilizada)

// ==================== NOVAS FUNCIONALIDADES ====================

// 1. Dark/Light Mode Toggle
function toggleTheme() {
  const html = document.documentElement;
  const currentTheme = html.getAttribute('data-theme') || 'light';
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', newTheme);
  const icon = newTheme === 'dark' ? '🌙' : '☀️';

  // Atualizar ícone no modal
  const modalIcon = document.getElementById('theme-icon-modal');
  if (modalIcon) modalIcon.textContent = icon;

  localStorage.setItem('theme', newTheme);
}

// Carregar tema salvo
(function loadSavedTheme() {
  // Claro por padrão, alinhado à identidade visual da plataforma corporativa.
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
  const icon = savedTheme === 'dark' ? '🌙' : '☀️';

  // Atualizar ícone no modal quando carregar
  const modalIcon = document.getElementById('theme-icon-modal');
  if (modalIcon) modalIcon.textContent = icon;
})();

// 2. Browser Notifications
function requestNotificationPermission() {
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }
}

function notifyFailure(workflowUrl) {
  if ('Notification' in window && Notification.permission === 'granted') {
    const notificationsEnabled = localStorage.getItem('notificationsEnabled') !== 'false';
    if (notificationsEnabled) {
      new Notification('Workflow Failure Detected', {
        body: `Um workflow falhou: ${workflowUrl}`,
        icon: '❌',
        tag: workflowUrl,
      });
    }
  }
}

// Verificar falhas ao atualizar tabela
const originalUpdateTable = updateTable;
updateTable = function (rows) {
  const previousFailures = new Set();
  document.querySelectorAll('#runs tbody tr .badge.fail').forEach((badge) => {
    const url = badge.closest('tr').querySelector('.link')?.href;
    if (url) previousFailures.add(url);
  });

  originalUpdateTable(rows);

  document.querySelectorAll('#runs tbody tr .badge.fail').forEach((badge) => {
    const url = badge.closest('tr').querySelector('.link')?.href;
    if (url && !previousFailures.has(url)) {
      notifyFailure(url);
    }
  });
};

// 7. Initialize on load
window.addEventListener('DOMContentLoaded', function () {
  requestNotificationPermission();
});

// ==================== EVENT WIRING (CSP estrita: sem handlers inline) ====================

// Mapa de ações disparadas por clique via delegação (elementos com data-action)
const clickActions = {
  closeAiModal,
  toggleResolveForm,
  saveResolution,
  closeCommentModal,
  saveComment,
  triggerRefresh,
  toggleTimeFilter,
  clearTimeFilter,
  toggleResultFilter,
  exportTableToXLSX,
  exportRerunsToXLSX,
  exportFailuresAndRerunsToXLSX,
  toggleTheme,
  closeTokenModal,
  removeToken,
  openCsvUpload,
  goToTokenSetup,
  stopPropagation,
};

function goToTokenSetup() {
  // A página de setup é renderizada na raiz quando não há token configurado.
  window.location.href = basePath + '/';
}

function openCsvUpload() {
  const input = document.getElementById('csv-upload');
  if (input) input.click();
}

function stopPropagation(el, e) {
  if (e) e.stopPropagation();
}

// Fechar o modal de análise ao clicar fora ou com ESC (mesmo padrão dos demais)
const aiModalEl = document.getElementById('ai-modal');
if (aiModalEl) {
  aiModalEl.addEventListener('click', (e) => {
    if (e.target === aiModalEl) closeAiModal();
  });
}
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeAiModal();
});

// Delegação de clique para elementos com data-action
document.addEventListener('click', (e) => {
  const target = e.target.closest('[data-action]');
  if (!target) return;
  const fn = clickActions[target.dataset.action];
  if (typeof fn === 'function') fn(target, e);
});

// Delegação na tabela: rerun (change) e comentário (click)
const runsTable = document.getElementById('runs');
if (runsTable) {
  runsTable.addEventListener('change', (e) => {
    const checkbox = e.target.closest('.rerun-checkbox');
    if (checkbox) toggleRerun(checkbox);
  });
  runsTable.addEventListener('click', (e) => {
    const aiBtn = e.target.closest('.ai-insumo-btn');
    if (aiBtn) return analyzeWithAgentix(aiBtn);
    const btn = e.target.closest('.comment-btn');
    if (btn) editComment(btn);
  });
}

// Refresh select (change)
const refreshSelect = document.getElementById('refresh-select');
if (refreshSelect) {
  refreshSelect.addEventListener('change', (e) => setRefreshInterval(e.target.value));
}

// Refresh button
const refreshBtn = document.getElementById('refresh-btn');
if (refreshBtn) refreshBtn.addEventListener('click', triggerRefresh);

// Upload de CSV: submeter form ao escolher arquivo
const csvUpload = document.getElementById('csv-upload');
if (csvUpload) {
  csvUpload.addEventListener('change', function () {
    this.form.submit();
  });
}

// Select de CSV salvo: submeter form ao mudar
const savedCsvSelect = document.querySelector('select[name="csv"]');
if (savedCsvSelect) {
  savedCsvSelect.addEventListener('change', function () {
    this.form.submit();
  });
}

// Busca: filtrar ao digitar
const searchInput = document.getElementById('q');
if (searchInput) searchInput.addEventListener('input', filterTable);

// Checkboxes de filtro de resultados
document.querySelectorAll('#result-options input[type="checkbox"]').forEach((cb) => {
  cb.addEventListener('change', filterTable);
});
