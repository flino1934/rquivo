const basePath = document.body.dataset.basePath || '';

document.getElementById('tokenForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const token = document.getElementById('token').value.trim();
  const alertContainer = document.getElementById('alert-container');

  if (!token) {
    showAlert('Token é obrigatório', 'error');
    return;
  }

  try {
    const response = await fetch(`${basePath}/set-token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ token }),
    });

    const data = await response.json();

    if (data.success) {
      showAlert('Token configurado com sucesso! Redirecionando...', 'success');
      setTimeout(() => {
        window.location.href = `${basePath}/`;
      }, 1500);
    } else {
      showAlert(data.error || 'Erro ao configurar token', 'error');
    }
  } catch (error) {
    showAlert('Erro de conexão. Tente novamente.', 'error');
  }
});

function showAlert(message, type) {
  const alertContainer = document.getElementById('alert-container');
  const alertClass = type === 'error' ? 'alert-error' : 'alert-success';

  alertContainer.innerHTML = `<div class="alert ${alertClass}">${message}</div>`;

  // Remove alert after 5 seconds if it's an error
  if (type === 'error') {
    setTimeout(() => {
      alertContainer.innerHTML = '';
    }, 5000);
  }
}
