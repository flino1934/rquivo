import app from './src/app.js';
import { config } from './src/config/env.js';
import { logger } from './src/lib/logger.js';
import { scheduleCleanup } from './src/services/cleanup.js';

// Encapsulates the server lifecycle. The application is received as an argument
// so the bootstrap is generic and the startup logic lives in a single place.
function startServer(application, port) {
  return application.listen(port, () => {
    logger.info(`Server listening on port ${port}${config.BASE_PATH}`);
  });
}

const server = startServer(app, config.PORT);
scheduleCleanup();

function shutdown(signal) {
  logger.info(`Received ${signal}. Shutting down gracefully...`);
  server.close((err) => {
    if (err) {
      logger.error(`Error during server close: ${err.message}`);
      process.exit(1);
    }
    logger.info('Closed out remaining connections. Bye!');
    process.exit(0);
  });

  // Force shutdown if connections do not drain in time.
  setTimeout(() => {
    logger.error('Forcing shutdown after timeout');
    process.exit(1);
  }, 10_000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
