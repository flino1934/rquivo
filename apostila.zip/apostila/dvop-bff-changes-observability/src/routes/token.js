import express from 'express';
import { verifyToken } from '../services/github.js';
import { logger } from '../lib/logger.js';

export const tokenRouter = express.Router();

// Configure a GitHub personal access token for the current session.
tokenRouter.post('/set-token', async (req, res) => {
  const { token } = req.body || {};
  if (!token || !token.trim()) {
    return res.status(400).json({ error: 'Token é obrigatório' });
  }

  const value = token.trim();
  const hasWhitespace = /\s/.test(value);
  const isClassicPat = value.startsWith('ghp_');
  const isFineGrainedPat = value.startsWith('github_pat_');
  if (hasWhitespace || (!isClassicPat && !isFineGrainedPat)) {
    return res.status(400).json({
      error: 'Formato de token inválido. Use PAT classic (ghp_) ou PAT fine-grained (github_pat_).',
    });
  }

  try {
    const login = await verifyToken(value);
    req.session.githubToken = value;
    // Kept so actions a person takes in the dashboard can be attributed to them
    // (e.g. who recorded a resolution) without a second lookup.
    req.session.githubLogin = login;
    logger.info(`Token configured for GitHub user: ${login}`);
    return res.json({ success: true, message: `Token configurado com sucesso para ${login}` });
  } catch (error) {
    const status = error.response?.status;
    logger.warn(`Token validation failed: ${error.message}`);
    if (status === 401) return res.status(400).json({ error: 'Token inválido - acesso negado pelo GitHub' });
    if (status === 403) {
      return res.status(400).json({ error: 'Token com permissões insuficientes ou limite de taxa excedido' });
    }
    return res.status(500).json({ error: 'Erro de conectividade com GitHub. Tente novamente.' });
  }
});

// Remove the token stored in the current session.
tokenRouter.post('/remove-token', (req, res) => {
  delete req.session.githubToken;
  delete req.session.githubLogin;
  res.json({ success: true, message: 'Token removido' });
});
