import fs from 'fs';
import path from 'path';
import express from 'express';
import { config } from '../config/env.js';
import { logger } from '../lib/logger.js';
import { safeRedirect } from '../lib/redirect.js';
import { requireToken } from '../middleware/auth.js';
import { sharedDashboardState, setSharedAnnotation } from '../services/state.js';
import { buildRowsFromCsv } from '../services/rows.js';
import { buildExportWorkbook, exportFilename } from '../services/export.js';
import { upload, allowedFile, buildStoredCsvFilename, listAvailableCsvs } from '../services/uploads.js';
import { isSafeCsvName } from '../lib/safe-path.js';
import { parseRunUrl, getFailureContext } from '../services/github.js';
import { buildFailureAnalysisPayload, parseAnalysis } from '../services/agentixPayload.js';
import {
  analyzeFailure,
  isConfigured as agentixConfigured,
  missingConfig,
  sendSessionFeedback,
} from '../services/agentixClient.js';
import { addResolution, buildSignature, buildStepSignature, findResolutions } from '../services/resolutions.js';

export const dashboardRouter = express.Router();

// Resolve the active CSV's content. In-memory uploads are returned directly; for
// saved selections the stored filename is re-validated and resolved within the
// upload folder before the single, guarded filesystem read.
// Map a CSV name to a real path WITHOUT building the path from user input: list
// the upload directory and return the path of the entry that matches. The
// returned path is taken from the filesystem listing (not from the request), so
// the user-supplied name never reaches a filesystem call — this is the level of
// indirection that defeats path manipulation.
function csvPathFromListing(name) {
  if (!name || !config.UPLOAD_FOLDER) return null;
  let entries;
  try {
    entries = fs.readdirSync(config.UPLOAD_FOLDER);
  } catch {
    return null;
  }
  const match = entries.find((entry) => isSafeCsvName(entry) && entry === name);
  return match ? path.join(config.UPLOAD_FOLDER, match) : null;
}

function resolveActiveCsv() {
  if (sharedDashboardState.activeCsvContent) {
    return {
      csvContent: sharedDashboardState.activeCsvContent,
      csvName: sharedDashboardState.activeCsvName || 'upload.csv',
    };
  }

  const name = sharedDashboardState.activeCsvName;
  const safePath = name && config.HAS_PERSISTENT_UPLOADS ? csvPathFromListing(name) : null;
  const filePath = safePath || config.INPUT_FILE;
  const csvName = safePath ? name : 'change_task.csv (padrão)';

  let csvContent = null;
  try {
    if (fs.existsSync(filePath)) csvContent = fs.readFileSync(filePath);
  } catch (e) {
    logger.error(`Failed to read CSV file: ${e.message}`);
  }
  return { csvContent, csvName };
}

// Switch the active CSV from a saved selection. The selection must correspond to
// a real entry in the upload directory (resolved via the listing) or it is
// rejected; only the name is stored.
function selectCsv(selected) {
  if (!config.HAS_PERSISTENT_UPLOADS) {
    if (sharedDashboardState.memoryCsvStore.has(selected)) {
      sharedDashboardState.activeCsvContent = sharedDashboardState.memoryCsvStore.get(selected);
      sharedDashboardState.activeCsvName = selected;
    }
    return;
  }

  if (csvPathFromListing(selected)) {
    sharedDashboardState.activeCsvName = selected;
    sharedDashboardState.activeCsvContent = null;
  } else {
    logger.warn(`Rejected unsafe CSV selection: ${selected}`);
  }
}

dashboardRouter.get('/', requireToken, async (req, res) => {
  const availableCsvs = listAvailableCsvs();
  const selectedParam = (req.query.csv || '').toString();
  if (selectedParam && isSafeCsvName(selectedParam) && availableCsvs.includes(selectedParam)) {
    selectCsv(selectedParam);
  }

  if (req.needsToken) {
    return res.render('token-setup', { basePath: config.BASE_PATH, hasSessionToken: false });
  }

  const { csvContent, csvName } = resolveActiveCsv();
  let rows = [];
  let csvFilename = csvName;
  try {
    rows = await buildRowsFromCsv(csvContent, null, req.session.githubToken);
  } catch (e) {
    logger.error(`Failed to load dashboard data: ${e.message}`);
    rows = [];
    csvFilename = 'Erro ao carregar dados';
  }

  res.render('dashboard', {
    rows,
    csv_filename: csvFilename,
    available_csvs: availableCsvs,
    selected_csv: sharedDashboardState.activeCsvName || '',
    basePath: config.BASE_PATH,
    hasSessionToken: !!req.session.githubToken,
  });
});

dashboardRouter.post('/', upload.single('csv_file'), async (req, res) => {
  const file = req.file;
  if (!file || !allowedFile(file.originalname)) return safeRedirect(res);

  if (!config.HAS_PERSISTENT_UPLOADS && file.buffer) {
    const csvName = buildStoredCsvFilename(file.originalname || 'upload.csv');
    const csvContent = file.buffer.toString('utf8');
    sharedDashboardState.memoryCsvStore.set(csvName, csvContent);
    sharedDashboardState.activeCsvContent = csvContent;
    sharedDashboardState.activeCsvName = csvName;
  } else {
    const storedName = path.basename(file.path);
    if (isSafeCsvName(storedName)) {
      sharedDashboardState.activeCsvName = storedName;
      sharedDashboardState.activeCsvContent = null;
    } else {
      logger.warn(`Rejected unsafe uploaded filename: ${storedName}`);
    }
  }

  safeRedirect(res);
});

// JSON data feed used by the dashboard's auto-refresh.
dashboardRouter.get('/api/workflow-data', requireToken, async (req, res) => {
  if (req.needsToken) return res.status(401).json({ error: 'Token GitHub necessário' });

  try {
    const { csvContent, csvName } = resolveActiveCsv();
    const rows = await buildRowsFromCsv(csvContent, null, req.session.githubToken);
    res.json({
      success: true,
      rows,
      csv_filename: csvName,
      lastUpdate: new Date().toISOString(),
    });
  } catch (e) {
    logger.error(`Failed to fetch workflow data: ${e.message}`);
    res.status(500).json({ error: 'Erro ao processar dados: ' + e.message });
  }
});

// Persist a shared annotation (comment and/or rerun flag) for a run URL.
dashboardRouter.post('/api/dashboard-annotation', express.json({ limit: '64kb' }), (req, res) => {
  const { url, comment, rerunChecked } = req.body || {};
  if (!url || typeof url !== 'string') return res.status(400).json({ error: 'url é obrigatório' });

  const patch = {};
  if (Object.prototype.hasOwnProperty.call(req.body, 'comment')) patch.comment = comment;
  if (Object.prototype.hasOwnProperty.call(req.body, 'rerunChecked'))
    patch.rerunChecked = rerunChecked === true;

  const annotation = setSharedAnnotation(url, patch);
  res.json({ success: true, url, annotation });
});

// Gather everything an AgentiX Agent needs to reason about a failed run: the
// failed steps (cheap JSON) plus the raw logs of the failed jobs (the actual
// error text). Both come from the caller's own GitHub token, so the analysis
// never sees a repository the user cannot already read.
async function buildInsumo(parsed, token, { status }) {
  const { workflow, failedSteps, failedLogs } = await getFailureContext(
    parsed.owner,
    parsed.repo,
    parsed.runId,
    token,
  );

  // A assinatura vem de onde a pipeline quebrou, não da resposta do agente:
  // as resoluções conhecidas precisam viajar JUNTO com o pedido, e uma chave
  // derivada da resposta chegaria tarde demais.
  const repository = `${parsed.owner}/${parsed.repo}`;
  const signature = buildSignature({ repository, workflow, failedSteps });
  const stepSignature = buildStepSignature({ failedSteps });
  const related = findResolutions({ signature, stepSignature, repository });

  const payload = buildFailureAnalysisPayload({
    repository,
    workflow,
    runId: parsed.runId,
    status,
    failedSteps,
    failedLogs,
    knownResolutions: related,
  });
  return { payload, signature, stepSignature, related, repository };
}

// Run the failure analysis on AgentiX: download the run's raw logs, send them
// as the insumo, wait for the session to finish and return the agent's answer.
// Answers 503 when the integration is not configured, so the dashboard degrades
// cleanly instead of surfacing an opaque error.
dashboardRouter.post(
  '/api/agentix-analyze',
  requireToken,
  express.json({ limit: '16kb' }),
  async (req, res) => {
    if (req.needsToken) return res.status(401).json({ error: 'Token GitHub necessário' });
    if (!agentixConfigured()) {
      logger.warn(`AgentiX analysis requested but not configured (faltando: ${missingConfig().join(', ')})`);
      return res.status(503).json({ error: 'Integração com a AgentiX não configurada neste ambiente' });
    }

    const { url, status } = req.body || {};
    const parsed = typeof url === 'string' ? parseRunUrl(url) : null;
    if (!parsed) return res.status(400).json({ error: 'url de execução inválida' });

    try {
      const { payload, signature, stepSignature, related, repository } = await buildInsumo(
        parsed,
        req.session.githubToken,
        { status },
      );
      const { analysis, sessionId } = await analyzeFailure(payload);
      // The agent answers with a JSON object; when it drifts from its own
      // contract the raw text is still returned so the user sees something.
      res.json({
        analysis: parseAnalysis(analysis),
        raw: analysis,
        sessionId,
        runId: parsed.runId,
        signature,
        stepSignature,
        repository,
        related,
      });
    } catch (e) {
      logger.error(`AgentiX analysis failed: ${e.message}`);
      res.status(502).json({ error: `Falha ao analisar na AgentiX: ${e.message}` });
    }
  },
);

// Build the same insumo the analysis route sends, but as a download. No AI
// call happens here — useful to inspect exactly what would be posted to the
// agent (already trimmed and with secrets masked) without running a session.
dashboardRouter.post(
  '/api/agentix-payload',
  requireToken,
  express.json({ limit: '16kb' }),
  async (req, res) => {
    if (req.needsToken) return res.status(401).json({ error: 'Token GitHub necessário' });

    const { url, status } = req.body || {};
    const parsed = typeof url === 'string' ? parseRunUrl(url) : null;
    if (!parsed) return res.status(400).json({ error: 'url de execução inválida' });

    try {
      const { payload } = await buildInsumo(parsed, req.session.githubToken, { status });

      res.setHeader('Content-Disposition', `attachment; filename="agentix-insumo-${parsed.runId}.json"`);
      res.json(payload);
    } catch (e) {
      logger.error(`Failed to build AgentiX payload: ${e.message}`);
      res.status(500).json({ error: 'Erro ao gerar insumo para IA' });
    }
  },
);

// Record what actually fixed a failure the agent analysed. The client sends the
// agent's proposal already edited by the person, so what lands in the catalogue
// is endorsed text, never an unreviewed hypothesis. The platform is told whether
// the analysis held up, which is the signal the agent's maintainers can act on.
dashboardRouter.post(
  '/api/resolutions',
  requireToken,
  express.json({ limit: '64kb' }),
  async (req, res) => {
    if (req.needsToken) return res.status(401).json({ error: 'Token GitHub necessário' });

    const { url, change, signature, stepSignature, category, problem, cause, solution, sessionId, agentCause, repository } =
      req.body || {};
    if (!String(solution || '').trim()) {
      return res.status(400).json({ error: 'Descreva o que resolveu a falha' });
    }

    const entry = addResolution({
      signature,
      stepSignature,
      category,
      problem,
      cause,
      solution,
      repository,
      runUrl: url,
      change,
      sessionId,
      author: req.session.githubLogin || '',
    });
    if (!entry) return res.status(400).json({ error: 'Não foi possível registrar a resolução' });

    // Uncorrected cause = the analysis held up; corrected = it did not.
    const held = String(cause || '').trim() === String(agentCause || '').trim();
    await sendSessionFeedback(
      sessionId,
      held ? 'positive' : 'negative',
      held ? entry.solution : `Causa corrigida para: ${entry.cause}

Resolvido com: ${entry.solution}`,
    );

    logger.info(`Resolution recorded for ${entry.change || entry.runUrl} (assinatura ${entry.signature || 'n/d'})`);
    res.json({ success: true, resolution: entry });
  },
);

// Generate an XLSX export from the rows posted by the client.
dashboardRouter.post('/export/xlsx', async (req, res) => {
  try {
    const rows = req.body?.rows || [];
    if (rows.length === 0) return res.status(400).json({ error: 'Nenhum dado para exportar' });

    const wb = buildExportWorkbook(rows);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${exportFilename()}"`);
    await wb.xlsx.write(res);
    res.end();
  } catch (error) {
    logger.error(`Failed to generate XLSX export: ${error.message}`);
    res.status(500).json({ error: 'Erro ao gerar planilha' });
  }
});
