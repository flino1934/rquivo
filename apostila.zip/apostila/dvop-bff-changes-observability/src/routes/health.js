import { config } from '../config/env.js';
import { cacheStats } from '../services/cache.js';

function healthPayload() {
  const mem = process.memoryUsage();
  return {
    status: 'ok',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    cache: cacheStats(),
    memory: {
      used: Math.round(mem.heapUsed / 1024 / 1024),
      total: Math.round(mem.heapTotal / 1024 / 1024),
      unit: 'MB',
    },
  };
}

function normalizeRoutePath(routePath) {
  if (!routePath || routePath === '/') return '/';
  return routePath.replace(/\/+/g, '/').replace(/\/$/, '') || '/';
}

const NAMES = [
  '/health',
  '/healthz',
  '/readyz',
  '/livez',
  '/health/liveness',
  '/health/readiness',
  '/health/startup',
];

// Register liveness/readiness endpoints at the root and under BASE_PATH.
export function registerHealthRoutes(app) {
  const routes = new Set();
  for (const name of NAMES) {
    routes.add(name);
    routes.add(normalizeRoutePath(`${config.BASE_PATH}${name}`));
  }
  for (const route of routes) {
    app.get(route, (req, res) => res.status(200).json(healthPayload()));
  }
}
