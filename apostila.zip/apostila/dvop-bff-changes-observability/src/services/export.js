import ExcelJS from 'exceljs';

const HEADERS = ['#', 'CHANGE', 'HORÁRIO', 'URL', 'Status', 'Reruns', 'Comentário'];
const COLUMN_WIDTHS = [8, 30, 20, 60, 16, 10, 50];

// Map an internal status to the visual symbol used in the exported sheet.
function displayStatusFor(status) {
  switch ((status || '').toLowerCase().trim()) {
    case 'success':
      return '✔️';
    case 'failure':
      return '❌';
    case 'waiting':
      return 'Não Executada';
    case 'cancelled':
      return 'Cancelada';
    default:
      return status || '';
  }
}

// Build an XLSX workbook from client-provided rows.
// Each row: { index, CHANGE, HORARIO, url, status, rerunChecked, comment }.
export function buildExportWorkbook(rows) {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Runs');

  ws.addRow(HEADERS);
  COLUMN_WIDTHS.forEach((width, i) => {
    ws.getColumn(i + 1).width = width;
  });

  const headerRow = ws.getRow(1);
  headerRow.font = { bold: true };
  headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE6E6FA' } };

  for (const r of rows) {
    const row = ws.addRow([
      r.index || '',
      r.CHANGE || '',
      r.HORARIO || '',
      r.url || '',
      displayStatusFor(r.status),
      r.rerunChecked ? '✔️' : '',
      r.comment || '',
    ]);

    if (r.url) {
      const urlCell = row.getCell(4);
      urlCell.value = { text: 'Link', hyperlink: r.url };
      urlCell.font = { color: { argb: 'FF0000FF' }, underline: true };
    }
  }

  return wb;
}

export function exportFilename() {
  return `painel_export_${new Date()
    .toISOString()
    .replace(/[-:T.Z]/g, '')
    .slice(0, 15)}.xlsx`;
}
