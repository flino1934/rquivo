import axios from 'axios';
import { config } from '../config/env.js';
import { logger } from '../lib/logger.js';

const USER_AGENT = 'github-actions-dashboard-node';
const REQUEST_TIMEOUT_MS = 10_000;

// Dedicated client pinned to the GitHub API over HTTPS. The secure base URL is a
// constant (never derived from user input) and redirects are disabled so the
// transport can never be downgraded to plaintext HTTP.
const githubApi = axios.create({
  baseURL: 'https://api.github.com',
  timeout: REQUEST_TIMEOUT_MS,
  maxRedirects: 0,
});

export function gitHubAuthHeader(token) {
  return `Bearer ${token}`;
}

function buildHeaders(token) {
  const headers = { Accept: 'application/vnd.github+json', 'User-Agent': USER_AGENT };
  const effective = token || config.GITHUB_TOKEN;
  if (effective) headers.Authorization = gitHubAuthHeader(effective);
  return headers;
}

function mapRunStatus(statusRaw, conclusion) {
  if (statusRaw === 'completed') {
    if (conclusion === 'success') return { status: 'Success', badge_class: 'success' };
    if (conclusion === 'cancelled') return { status: 'Cancelled', badge_class: 'cancelled' };
    const status = conclusion ? conclusion.charAt(0).toUpperCase() + conclusion.slice(1) : 'Completed';
    return { status, badge_class: conclusion && conclusion !== 'success' ? 'fail' : 'unknown' };
  }
  if (statusRaw === 'in_progress' || statusRaw === 'queued') {
    return {
      status: statusRaw.replace('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
      badge_class: 'progress',
    };
  }
  return { status: statusRaw || 'Unknown', badge_class: 'unknown' };
}

const INVALID_RUN = {
  status: 'Invalid URL',
  conclusion: '',
  badge_class: 'unknown',
  reruns: 1,
  executor: '',
  executorEmail: '',
};

// Allow-lists for the GitHub URL path segments. The request always targets the
// fixed host api.github.com and the segments are validated against these
// patterns, so the request URL can never be forged from user-controlled data.
const OWNER_REPO = /^[A-Za-z0-9_.-]+$/;
const RUN_ID = /^[0-9]+$/;
const LOGIN = /^[A-Za-z0-9_-]+$/;

// Resolve a GitHub login to the person's registered profile (name + e-mail).
// Results are cached per login so each distinct user is looked up at most once,
// regardless of how many runs they triggered. Falls back to the login (and an
// empty e-mail) when the profile is unavailable or the lookup fails.
const profileCache = new Map();

async function resolveExecutorProfile(login, token) {
  if (!login || !LOGIN.test(login)) return { name: login || '', email: '' };
  if (profileCache.has(login)) return profileCache.get(login);

  let profile = { name: login, email: '' };
  try {
    const resp = await githubApi.get(`/users/${encodeURIComponent(login)}`, {
      headers: buildHeaders(token),
    });
    profile = { name: resp.data?.name || login, email: resp.data?.email || '' };
  } catch (e) {
    logger.debug(`GitHub user lookup failed for ${login}: ${e.response?.status || e.code || 'error'}`);
  }
  profileCache.set(login, profile);
  return profile;
}

// Extract and validate {owner, repo, runId} from a GitHub Actions run URL.
// Shared by getRunInfoFromUrl and callers that need the same trusted path
// segments for a different API call (e.g. fetching job/step details).
export function parseRunUrl(url) {
  const m = String(url).match(
    /^https:\/\/github\.com\/([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)\/actions\/runs\/(\d+)/,
  );
  if (!m) return null;
  const [, owner, repo, runId] = m;
  if (!OWNER_REPO.test(owner) || !OWNER_REPO.test(repo) || !RUN_ID.test(runId)) return null;
  return { owner, repo, runId };
}

// Fetch a run's jobs (lightweight JSON: names, conclusions and steps). Shared
// by every caller that needs failure detail, so a single analysis reads this
// endpoint once instead of once per derived view.
async function getRunJobs(owner, repo, runId, token) {
  const apiPath = `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/actions/runs/${encodeURIComponent(runId)}/jobs`;
  try {
    const resp = await githubApi.get(apiPath, { headers: buildHeaders(token) });
    return resp.data?.jobs || [];
  } catch (e) {
    logger.debug(`GitHub jobs lookup failed (${e.response?.status || e.code || 'error'}): ${owner}/${repo}/${runId}`);
    return [];
  }
}

function collectFailedSteps(jobs) {
  const failedSteps = [];
  for (const job of jobs) {
    for (const step of job.steps || []) {
      if (step.conclusion === 'failure') {
        failedSteps.push({ job: job.name, name: step.name, conclusion: step.conclusion });
      }
    }
  }
  return failedSteps;
}

// List the failed steps for a run's jobs — enough detail to hand off to an
// external analysis tool without pulling the raw logs.
export async function getFailedJobSteps(owner, repo, runId, token) {
  return collectFailedSteps(await getRunJobs(owner, repo, runId, token));
}

export async function getRunInfoFromUrl(url, userToken = null) {
  const parsed = parseRunUrl(url);
  if (!parsed) return { url, ...INVALID_RUN };

  const { owner, repo, runId } = parsed;
  const apiPath = `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/actions/runs/${encodeURIComponent(runId)}`;

  try {
    const resp = await githubApi.get(apiPath, { headers: buildHeaders(userToken) });
    const data = resp.data || {};
    const conclusion = data.conclusion || '';
    const { status, badge_class } = mapRunStatus(data.status || '', conclusion);
    const executorLogin = data.triggering_actor?.login || data.actor?.login || '';
    const { name: executor, email: executorEmail } = await resolveExecutorProfile(executorLogin, userToken);
    return {
      url,
      status,
      conclusion,
      badge_class,
      reruns: data.run_attempt || 1,
      executor,
      executorEmail,
    };
  } catch (e) {
    const httpStatus = e.response?.status;
    logger.debug(`GitHub run lookup failed (${httpStatus || e.code || 'error'}): ${owner}/${repo}/${runId}`);
    let errorStatus = 'Unknown';
    if (httpStatus === 401) errorStatus = 'Token Inválido';
    else if (httpStatus === 403) errorStatus = 'Sem Permissão';
    else if (httpStatus === 404) errorStatus = 'Não Encontrado';
    else if (e.code === 'ECONNABORTED') errorStatus = 'Timeout';
    return {
      url,
      status: errorStatus,
      conclusion: String(e.message || e),
      badge_class: 'unknown',
      reruns: 1,
      executor: '',
      executorEmail: '',
    };
  }
}

// Validate a personal access token by calling the authenticated user endpoint.
// Returns the GitHub login on success; throws an error with a `status` property otherwise.
export async function verifyToken(token) {
  const resp = await githubApi.get('/user', {
    headers: {
      Authorization: gitHubAuthHeader(token),
      Accept: 'application/vnd.github+json',
      'User-Agent': USER_AGENT,
    },
  });
  return resp.data?.login || '';
}

// ---------------------------------------------------------------------------
// Raw job logs
// ---------------------------------------------------------------------------

// GitHub answers the job-logs endpoint with a 302 to a short-lived, signed blob
// URL. Redirects are disabled on the shared client (transport hardening), so the
// hop is followed manually: the Location is validated to be HTTPS on a known
// GitHub/Azure storage host, and the Authorization header is deliberately NOT
// forwarded (the URL is already signed and GitHub rejects the extra credential).
const LOG_HOST_SUFFIXES = ['.githubusercontent.com', '.blob.core.windows.net', '.github.com'];
const LOG_DOWNLOAD_TIMEOUT_MS = 20_000;

// Budget per failed job. Measured against real corporate pipeline logs: a scan
// job runs ~40 KB and fits whole, while a build job can reach ~660 KB — beyond
// any usable prompt — so a cap is required, just a generous one.
const MAX_FAILED_JOBS = 3;
const MAX_LOG_CHARS_PER_JOB = 60_000;

// Lines that mark a real failure. The analysis agent is instructed to find the
// *first* failure chronologically (later errors are usually its consequence),
// so when a log has to be cut, the region around the first match of these is
// what must survive — cutting to the tail alone would hide exactly that.
const ERROR_MARKERS =
  /##\[error\]|\bERROR\b|\bERR!|\bFAILED?\b|\bFAILURE\b|Exception|Traceback|exit code|\bfatal\b/i;

// Lines of context kept before the first error, so the failing command itself
// is visible and not just its message.
const CONTEXT_LINES_BEFORE_ERROR = 40;

function isAllowedLogHost(location) {
  let parsed;
  try {
    parsed = new URL(location);
  } catch {
    return false;
  }
  if (parsed.protocol !== 'https:') return false;
  return LOG_HOST_SUFFIXES.some((s) => parsed.hostname.endsWith(s));
}

const TRUNCATION_MARK = '[... trecho do log omitido ...]';

// Reduce a job log to something that fits a prompt without losing the failure.
// Lines are stripped of the leading ISO timestamp GitHub prefixes to each one
// (pure token cost) and blank lines are dropped; a log that then fits the budget
// is returned whole. Only when it does not fit is anything discarded, and the
// cut is anchored on the first error rather than on the end of the file.
export function trimLogTail(text, maxChars = MAX_LOG_CHARS_PER_JOB) {
  const lines = String(text || '')
    .split(/\r?\n/)
    .map((l) => l.replace(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z\s?/, ''))
    .filter((l) => l.trim() !== '');

  const whole = lines.join('\n');
  if (whole.length <= maxChars) return whole;

  const firstError = lines.findIndex((l) => ERROR_MARKERS.test(l));
  // No recognizable error: the tail is the best guess left.
  const start = firstError < 0 ? 0 : Math.max(0, firstError - CONTEXT_LINES_BEFORE_ERROR);

  const fromError = lines.slice(start).join('\n');
  if (fromError.length <= maxChars) {
    return start === 0 ? fromError.slice(-maxChars) : `${TRUNCATION_MARK}\n${fromError}`;
  }

  // Still too long: keep the beginning of the failure and the end of the run
  // (where the runner prints its summary), dropping the middle.
  const half = Math.floor(maxChars / 2);
  const head = fromError.slice(0, half);
  const tail = fromError.slice(-half);
  const prefix = start === 0 ? '' : `${TRUNCATION_MARK}\n`;
  return `${prefix}${head}\n${TRUNCATION_MARK}\n${tail}`;
}

async function downloadJobLog(owner, repo, jobId, token) {
  const apiPath = `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/actions/jobs/${encodeURIComponent(jobId)}/logs`;
  const resp = await githubApi.get(apiPath, {
    headers: buildHeaders(token),
    // 302 is the documented success path here, not an error.
    validateStatus: (s) => s === 302 || s === 200,
  });

  // Some proxies/enterprise setups answer 200 with the body inline.
  if (resp.status === 200) return String(resp.data || '');

  const location = resp.headers?.location || '';
  if (!isAllowedLogHost(location)) {
    logger.warn(`Refused GitHub log redirect to an untrusted location for job ${jobId}`);
    return '';
  }
  // Fresh request without the shared client's baseURL/credentials.
  const blob = await axios.get(location, {
    timeout: LOG_DOWNLOAD_TIMEOUT_MS,
    maxRedirects: 0,
    responseType: 'text',
    transformResponse: [(d) => d],
    headers: { 'User-Agent': USER_AGENT },
  });
  return String(blob.data || '');
}

// Download the raw logs of the jobs that failed in a run. Returns
// [{ job, jobId, log }] with each log trimmed to its tail. A job whose log
// cannot be fetched is returned with an empty log rather than failing the whole
// call — a partial insumo still beats no analysis at all.
export async function getFailedJobLogs(owner, repo, runId, token) {
  return downloadFailedJobLogs(await getRunJobs(owner, repo, runId, token), owner, repo, token);
}

async function downloadFailedJobLogs(jobs, owner, repo, token) {
  const failed = jobs.filter((j) => j.conclusion === 'failure').slice(0, MAX_FAILED_JOBS);
  const logs = [];
  for (const job of failed) {
    let log = '';
    try {
      log = trimLogTail(await downloadJobLog(owner, repo, job.id, token));
    } catch (e) {
      logger.debug(`GitHub job log download failed (${e.response?.status || e.code || 'error'}): job ${job.id}`);
    }
    logs.push({ job: job.name, jobId: job.id, log });
  }
  return logs;
}

// Everything needed to reason about a failed run, from a single jobs lookup:
// the failed steps (cheap JSON) and the raw logs of the failed jobs (the actual
// error text). Preferred over calling getFailedJobSteps + getFailedJobLogs
// separately, which would read the jobs endpoint twice.
export async function getFailureContext(owner, repo, runId, token) {
  const jobs = await getRunJobs(owner, repo, runId, token);
  return {
    // Every job of a run carries the workflow name, so it comes for free here
    // instead of costing a separate call to the run endpoint.
    workflow: jobs[0]?.workflow_name || '',
    failedSteps: collectFailedSteps(jobs),
    failedLogs: await downloadFailedJobLogs(jobs, owner, repo, token),
  };
}
