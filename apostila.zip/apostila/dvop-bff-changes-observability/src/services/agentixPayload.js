// Builds the insumo (input) for the AgentiX agent `changes-observability-agent`
// (bundle dvop-agx-ssol-changes-observability), whose AGENTS.md documents this
// exact request contract:
//
//   { repository, workflow, run_id, status, logs, known_resolutions }
//
// Only `logs` is mandatory; missing fields must be omitted rather than invented.
// `known_resolutions` carries failures a person already fixed, for the agent to
// check against this run's log. The agent answers with a JSON object (see
// parseAnalysis below).
//
// This module never calls any AI provider — it only shapes and sanitizes data.
//
// The agent's contract puts two responsibilities on the caller, both handled
// here: the payload is persisted in the platform session and recoverable by
// anyone with access to it, so secrets must be masked before sending; and raw
// pipeline logs blow past the model context, so they must be trimmed.

// Global budget across all failed jobs. Sized above the per-job cap in
// github.js (60k) so a single failed job — the common case — always arrives
// whole, while a run that fails in several jobs still cannot blow the prompt.
// Roughly 30k tokens at the worst case, well inside the model's context.
const MAX_TOTAL_LOG_CHARS = 120_000;

// Patterns for values that must never leave this service inside a log. GitHub
// masks its own secrets as *** in Actions logs, but anything a build prints by
// accident (a token echoed by a tool, a signed artifact URL, a connection
// string) arrives here in the clear.
const SECRET_PATTERNS = [
  // GitHub tokens (classic, fine-grained, OAuth, app, refresh).
  /\bgh[pousr]_[A-Za-z0-9]{16,}\b/g,
  /\bgithub_pat_[A-Za-z0-9_]{20,}\b/g,
  // JWTs (three base64url segments) — covers AgentiX/Keycloak bearer tokens.
  /\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b/g,
  // AWS access key ids and generic long hex/base64 secrets after a label.
  /\bAKIA[0-9A-Z]{16}\b/g,
  /\b(?:authorization|bearer|token|api[-_]?key|secret|password|passwd|pwd)["'\s:=]+[^\s"'&]{8,}/gi,
  // Signed URLs: query strings carrying a signature or an inline credential.
  /[?&](?:sig|signature|x-amz-signature|access_token|token|key)=[^&\s"']+/gi,
  // Connection strings with inline credentials (scheme://user:pass@host).
  /\b[a-z][a-z0-9+.-]*:\/\/[^\s:/@]+:[^\s@]+@/gi,
];

// Personal data the agent's contract also puts on the caller. E-mail addresses
// show up routinely in corporate pipeline output (policy tools printing whom to
// contact) and carry no diagnostic value, so they are masked wholesale.
const EMAIL_PATTERN = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g;

// Replace anything matching a secret pattern with [REDACTED], keeping the label
// around it so the agent still sees *that* a credential was involved.
export function maskSecrets(text) {
  let out = String(text || '');
  for (const pattern of SECRET_PATTERNS) {
    out = out.replace(pattern, (match) => {
      // Keep the leading label/separator when the pattern captured one, so a
      // line stays readable: `Authorization: [REDACTED]` beats `[REDACTED]`.
      const label = /^[?&]?[A-Za-z][\w-]*["'\s:=]+/.exec(match);
      return label ? `${label[0]}[REDACTED]` : '[REDACTED]';
    });
  }
  return out.replace(EMAIL_PATTERN, '[EMAIL]');
}

// Concatenate the per-job raw logs into one block, delimited by job name so the
// agent can attribute an error to the job it came from. Jobs are added while
// there is budget left; whatever does not fit is reported explicitly rather than
// silently dropped, so the agent knows its view is partial.
export function formatFailedLogs(failedLogs) {
  if (!failedLogs?.length) return '';

  const blocks = [];
  let used = 0;
  let omitted = 0;
  for (const entry of failedLogs) {
    const log = maskSecrets(entry.log).trim();
    if (!log) {
      omitted += 1;
      continue;
    }
    const remaining = MAX_TOTAL_LOG_CHARS - used;
    if (remaining <= 0) {
      omitted += 1;
      continue;
    }
    const body = log.length > remaining ? `[... truncado ...]\n${log.slice(-remaining)}` : log;
    used += body.length;
    blocks.push(`===== JOB: ${entry.job} =====\n${body}`);
  }

  if (!blocks.length) return '';
  if (omitted > 0) {
    blocks.push(`===== ${omitted} job(s) com falha omitido(s) por limite de tamanho =====`);
  }
  return blocks.join('\n\n');
}

// When no raw log could be downloaded, fall back to the failed step names: less
// useful than a log, but enough for the agent to answer `inconclusive` with a
// concrete reason instead of receiving an empty request.
function formatFailedSteps(failedSteps) {
  if (!failedSteps?.length) return '';
  return ['Nenhum log bruto disponível. Steps que falharam, segundo a API do GitHub:']
    .concat(failedSteps.map((s) => `- ${s.job}: ${s.name} (${s.conclusion})`))
    .join('\n');
}

// Build the request body for the analysis agent. Fields with no known value are
// omitted (the agent treats absent fields as unknown and is told never to invent
// them); `logs` always carries something so the request is never empty.
export function buildFailureAnalysisPayload({
  repository,
  workflow,
  runId,
  status,
  failedSteps,
  failedLogs,
  knownResolutions,
}) {
  const logs = formatFailedLogs(failedLogs) || formatFailedSteps(failedSteps) || 'Nenhum log disponível para esta execução.';

  const request = { logs };
  if (repository) request.repository = repository;
  if (workflow) request.workflow = workflow;
  if (runId) request.run_id = String(runId);
  if (status) request.status = status;

  // Falhas já resolvidas por uma pessoa, para o agente conferir contra o log
  // desta execução. Só os campos que ele usa — o resto do registro (id, autor,
  // sessão) é ruído no prompt.
  const known = (Array.isArray(knownResolutions) ? knownResolutions : [])
    .filter((r) => r?.solution)
    .map((r) => ({
      match: r.match === 'exact' ? 'exact' : 'related',
      problem: r.problem || '',
      cause: r.cause || '',
      solution: r.solution,
      recorded_at: String(r.createdAt || '').slice(0, 10),
      change: r.change || '',
    }));
  if (known.length) request.known_resolutions = known;

  // The v2 invoke contract carries the prompt as a string; the agent's own
  // contract says the request arrives as a JSON object, so it is serialized.
  return { input: JSON.stringify(request), constants: {} };
}

// The agent is instructed to answer with a bare JSON object and nothing else,
// but models drift — a code fence or a stray sentence around it is the common
// failure. Recover the object when possible; otherwise hand the raw text back
// so the user sees the answer instead of an error.
export function parseAnalysis(answer) {
  // /sessions/{id}/artifacts already hands back a parsed object; /messages
  // hands back the same answer as a string. Accept both.
  if (answer && typeof answer === 'object' && !Array.isArray(answer)) return answer;

  const raw = String(answer || '').trim();
  if (!raw) return null;

  const candidates = [raw];
  const fenced = /```(?:json)?\s*([\s\S]*?)```/i.exec(raw);
  if (fenced) candidates.push(fenced[1].trim());
  const braced = raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1);
  if (braced.length > 1) candidates.push(braced);

  for (const candidate of candidates) {
    try {
      const parsed = JSON.parse(candidate);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
    } catch {
      // Try the next candidate.
    }
  }
  return null;
}
