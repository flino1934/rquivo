import path from 'path';
import fs from 'fs';
import { config } from '../config/env.js';
import { logger } from '../lib/logger.js';

// Shared dashboard state, visible to every user of this app instance.
// Annotations (comment + rerun flag) are keyed by run URL.
export const sharedDashboardState = {
  activeCsvContent: null,
  activeCsvName: null,
  annotations: new Map(), // url -> { comment: string, rerunChecked: boolean }
  memoryCsvStore: new Map(), // name -> csv content
};

// When ANNOTATIONS_FILE is configured (DATA_DIR pointing at a persistent volume),
// annotations are mirrored to disk so they survive restarts. The in-memory Map
// stays the source of truth, so reads remain synchronous; only mutations write.
// When unset, this is a no-op and the app behaves as a pure in-memory store.
const ANNOTATIONS_FILE = config.ANNOTATIONS_FILE;

function loadAnnotations() {
  if (!ANNOTATIONS_FILE || !fs.existsSync(ANNOTATIONS_FILE)) return;
  try {
    const obj = JSON.parse(fs.readFileSync(ANNOTATIONS_FILE, 'utf8'));
    for (const [url, value] of Object.entries(obj || {})) {
      if (value && typeof value === 'object') {
        sharedDashboardState.annotations.set(url, {
          comment: typeof value.comment === 'string' ? value.comment : '',
          rerunChecked: value.rerunChecked === true,
        });
      }
    }
    logger.info(`Loaded ${sharedDashboardState.annotations.size} annotation(s) from ${ANNOTATIONS_FILE}`);
  } catch (e) {
    logger.warn(`Could not load annotations from ${ANNOTATIONS_FILE}: ${e.message || e}`);
  }
}

function persistAnnotations() {
  if (!ANNOTATIONS_FILE) return;
  try {
    fs.mkdirSync(path.dirname(ANNOTATIONS_FILE), { recursive: true });
    const tmp = `${ANNOTATIONS_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(Object.fromEntries(sharedDashboardState.annotations)), 'utf8');
    fs.renameSync(tmp, ANNOTATIONS_FILE); // atomic replace
  } catch (e) {
    logger.warn(`Could not persist annotations to ${ANNOTATIONS_FILE}: ${e.message || e}`);
  }
}

loadAnnotations();

export function getSharedAnnotation(url) {
  if (!url) return { comment: '', rerunChecked: false };
  const existing = sharedDashboardState.annotations.get(url);
  if (!existing) return { comment: '', rerunChecked: false };
  return {
    comment: typeof existing.comment === 'string' ? existing.comment : '',
    rerunChecked: existing.rerunChecked === true,
  };
}

export function setSharedAnnotation(url, patch = {}) {
  if (!url) return getSharedAnnotation(url);
  const current = getSharedAnnotation(url);
  const next = {
    comment: Object.prototype.hasOwnProperty.call(patch, 'comment')
      ? String(patch.comment || '')
      : current.comment,
    rerunChecked: Object.prototype.hasOwnProperty.call(patch, 'rerunChecked')
      ? patch.rerunChecked === true
      : current.rerunChecked,
  };

  if (!next.comment && next.rerunChecked !== true) {
    sharedDashboardState.annotations.delete(url);
    persistAnnotations();
    return { comment: '', rerunChecked: false };
  }

  sharedDashboardState.annotations.set(url, next);
  persistAnnotations();
  return next;
}
