import { config } from '../config/env.js';

// Simple in-memory cache with TTL, keyed by run URL.
const store = new Map();

export function getCached(key) {
  const entry = store.get(key);
  if (!entry) return null;
  if (Date.now() - entry.ts >= config.CACHE_TTL_MS) {
    store.delete(key);
    return null;
  }
  return entry.data;
}

export function setCached(key, data) {
  store.set(key, { ts: Date.now(), data });
}

export function cacheStats() {
  return { size: store.size, ttl_seconds: config.CACHE_TTL_MS / 1000 };
}
