import fs from 'fs';
import path from 'path';
import { config } from '../config/env.js';
import { logger } from '../lib/logger.js';
import { sharedDashboardState } from './state.js';

// Interval between cleanup passes. A daily check is sufficient — files are only
// removed once they exceed UPLOAD_RETENTION_DAYS, so a daily granularity is fine.
const CHECK_INTERVAL_MS = 24 * 60 * 60 * 1000;

// Files in the upload folder that are never subject to retention.
const PROTECTED_NAMES = new Set(['.gitkeep', 'annotations.json']);

// True only for a regular file directly inside dir — never a directory, and
// never something reached by escaping dir through the name.
function isPlainFile(dir, name) {
  if (name !== path.basename(name) || name.includes('..')) return false;
  try {
    return fs.statSync(path.join(dir, name)).isFile();
  } catch {
    return false;
  }
}

/**
 * Scan the upload folder and delete every CSV file whose mtime is older than
 * UPLOAD_RETENTION_DAYS days, unless it is the currently active CSV.
 *
 * Returns a summary { removed, errors } for testing / logging purposes.
 * Safe to call at any time; no-op when persistent uploads are not configured.
 */
export function pruneOldUploads() {
  if (!config.HAS_PERSISTENT_UPLOADS || !config.UPLOAD_FOLDER) {
    return { removed: 0, errors: 0 };
  }

  const retentionMs = config.UPLOAD_RETENTION_DAYS * 24 * 60 * 60 * 1000;
  const cutoff = Date.now() - retentionMs;
  const active = sharedDashboardState.activeCsvName;

  let entries;
  try {
    entries = fs.readdirSync(config.UPLOAD_FOLDER);
  } catch (e) {
    logger.warn(`Cleanup: could not read upload folder: ${e.message}`);
    return { removed: 0, errors: 1 };
  }

  let removed = 0;
  let errors = 0;

  for (const name of entries) {
    // Never delete the file that is currently loaded in the dashboard.
    if (name === active) continue;
    // Bookkeeping files that must survive regardless of age.
    if (PROTECTED_NAMES.has(name)) continue;
    // Retention applies to every file in the folder, not only to well-formed
    // CSVs: rejected uploads and leftovers from older versions also age out.
    // Anything that is not a plain file (a directory, a link) is left alone.
    if (!isPlainFile(config.UPLOAD_FOLDER, name)) continue;

    const filePath = path.join(config.UPLOAD_FOLDER, name);
    let stat;
    try {
      stat = fs.statSync(filePath);
    } catch {
      continue;
    }

    if (stat.mtimeMs < cutoff) {
      try {
        fs.unlinkSync(filePath);
        logger.info(`Cleanup: removed upload older than ${config.UPLOAD_RETENTION_DAYS}d — ${name}`);
        removed++;
      } catch (e) {
        logger.warn(`Cleanup: failed to remove ${name}: ${e.message}`);
        errors++;
      }
    }
  }

  logger.info(`Cleanup: pass complete — ${removed} file(s) removed, ${errors} error(s).`);
  return { removed, errors };
}

/**
 * Run an initial prune on startup, then schedule a daily pass.
 * The interval timer is unref'd so it does not prevent graceful shutdown.
 * No-op when persistent uploads are disabled (DATA_DIR not set).
 */
export function scheduleCleanup() {
  if (!config.HAS_PERSISTENT_UPLOADS) return;

  logger.info(
    `Cleanup scheduler started — retention: ${config.UPLOAD_RETENTION_DAYS} day(s), ` +
      `folder: ${config.UPLOAD_FOLDER}`,
  );

  // Run immediately to clean up any backlog from previous deployments.
  pruneOldUploads();

  // Then repeat daily.
  const timer = setInterval(pruneOldUploads, CHECK_INTERVAL_MS);
  timer.unref();
}
