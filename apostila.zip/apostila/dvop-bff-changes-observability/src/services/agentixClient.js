// Client for AgentiX 2.0 (plataforma interna de agentes) — v2 REST API.
//
// Flow: obtain a bearer token (static secret, or Keycloak ROPC), POST the
// insumo to {base}/sessions/invoke, then poll {base}/sessions/{id} until the
// session leaves the running states. v2 also exposes an SSE stream
// (/sessions/{id}/stream), but a BFF answering a single HTTP request gains
// nothing from it and polling survives proxies that buffer event streams.
//
// Everything is driven by AGENTIX_* env vars; when they are absent the module
// reports itself as not configured and the caller answers 503, so the dashboard
// keeps working without the integration.
import axios from 'axios';
import { config } from '../config/env.js';
import { logger } from '../lib/logger.js';

const REQUEST_TIMEOUT_MS = 30_000;
const POLL_INTERVAL_MS = 2_000;
// Keycloak tokens are refreshed this many seconds before they actually expire,
// so a request never races the expiry (same buffer the official plugin uses).
const TOKEN_EXPIRY_BUFFER_SECONDS = 60;

// v2 session states: CREATED → RUNNING → (DONE | FAILED | AWAITING).
// AWAITING means the agent paused for human input (HITL) — a failure-analysis
// agent should never do that, so it is surfaced as an error rather than waited on.
const RUNNING_STATES = new Set(['CREATED', 'RUNNING', 'PENDING', 'QUEUED']);

// A real session detail (captured 2026-08-19) reports its state under `state`,
// while POST /sessions/invoke answers with `status`. Read both — polling on the
// wrong one silently treats every session as already finished.
export function sessionState(session) {
  return String(session?.state || session?.status || '').toUpperCase();
}

// Base URLs come from configuration, never from user input, and must be HTTPS
// so the transport can never be downgraded to plaintext.
function assertHttps(url, label) {
  if (!/^https:\/\//i.test(url)) throw new Error(`${label} deve usar HTTPS`);
  return url;
}

export function isConfigured() {
  const hasCredential = Boolean(
    config.AGENTIX_TOKEN || (config.AGENTIX_KEYCLOAK_URL && config.AGENTIX_USERNAME && config.AGENTIX_PASSWORD),
  );
  return Boolean(config.AGENTIX_BASE_URL && config.AGENTIX_TENANT_ID && config.AGENTIX_ENTITY_NAME && hasCredential);
}

// Reasons the integration is unusable, for a message an operator can act on.
export function missingConfig() {
  const missing = [];
  if (!config.AGENTIX_BASE_URL) missing.push('AGENTIX_BASE_URL');
  if (!config.AGENTIX_TENANT_ID) missing.push('AGENTIX_TENANT_ID');
  if (!config.AGENTIX_ENTITY_NAME) missing.push('AGENTIX_ENTITY_NAME');
  if (!config.AGENTIX_TOKEN && !(config.AGENTIX_KEYCLOAK_URL && config.AGENTIX_USERNAME && config.AGENTIX_PASSWORD)) {
    missing.push('AGENTIX_TOKEN (ou AGENTIX_KEYCLOAK_URL + AGENTIX_USERNAME + AGENTIX_PASSWORD)');
  }
  return missing;
}

// --- Auth -------------------------------------------------------------------

let cachedToken = { value: '', expiresAt: 0 };

export function resetTokenCache() {
  cachedToken = { value: '', expiresAt: 0 };
}

// Resource Owner Password Credentials against Keycloak (realm Omega-AGX,
// client agx-front). This is the only automatable v2 grant confirmed to work;
// it still consumes a user credential, so a dedicated service account should
// replace AGENTIX_USERNAME/PASSWORD before this reaches production.
async function fetchKeycloakToken() {
  const url = assertHttps(`${config.AGENTIX_KEYCLOAK_URL}/protocol/openid-connect/token`, 'AGENTIX_KEYCLOAK_URL');
  const body = new URLSearchParams({
    grant_type: 'password',
    client_id: config.AGENTIX_CLIENT_ID,
    username: config.AGENTIX_USERNAME,
    password: config.AGENTIX_PASSWORD,
    scope: 'openid profile email',
  });

  const resp = await axios.post(url, body.toString(), {
    timeout: REQUEST_TIMEOUT_MS,
    maxRedirects: 0,
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
  const token = resp.data?.access_token;
  if (!token) throw new Error('Keycloak não retornou access_token');
  const ttl = Number(resp.data?.expires_in) || 300;
  return { value: token, expiresAt: Date.now() + Math.max(0, ttl - TOKEN_EXPIRY_BUFFER_SECONDS) * 1000 };
}

export async function getAccessToken() {
  if (config.AGENTIX_TOKEN) return config.AGENTIX_TOKEN;
  if (cachedToken.value && Date.now() < cachedToken.expiresAt) return cachedToken.value;
  cachedToken = await fetchKeycloakToken();
  return cachedToken.value;
}

// --- API --------------------------------------------------------------------

function authHeaders(token) {
  return {
    Authorization: `Bearer ${token}`,
    'x-tenant-id': config.AGENTIX_TENANT_ID,
    'Content-Type': 'application/json',
  };
}

// Axios reports only "Request failed with status code NNN"; the AgentiX API
// puts the actionable part in the body (`detail`, sometimes a FastAPI
// validation array). Surface it, so an operator sees "Bundle 'x' not found"
// instead of a bare status code.
export function apiErrorMessage(e) {
  const detail = e.response?.data?.detail ?? e.response?.data?.message;
  if (typeof detail === 'string') return detail;

  // FastAPI validation errors.
  if (Array.isArray(detail)) {
    return detail.map((d) => `${(d.loc || []).join('.')}: ${d.msg}`).join('; ');
  }

  // Registry blocks answer with { message, blockers: [{type, name, version,
  // reason}] }. The message alone reads fine; dumping the whole object does not.
  if (detail?.message) {
    const blockers = Array.isArray(detail.blockers)
      ? detail.blockers.map((b) => `${b.name}@${b.version} (${b.reason})`).join(', ')
      : '';
    return blockers ? `${detail.message} [${blockers}]` : detail.message;
  }

  if (detail) return JSON.stringify(detail);
  return e.message;
}

function wrapApiError(e, acao) {
  const err = new Error(`${acao}: ${apiErrorMessage(e)}`);
  err.status = e.response?.status;
  return err;
}

// Invoke the configured executable entity with an insumo built by
// agentixPayload.js. Workflows take the prompt under `prompt`, agents and teams
// under `input` — the only shape difference between entity types.
export async function invokeSession({ input, constants }) {
  const base = assertHttps(config.AGENTIX_BASE_URL, 'AGENTIX_BASE_URL');
  const entityType = config.AGENTIX_ENTITY_TYPE || 'agent';
  const payload = entityType === 'workflow' ? { prompt: input } : { input };

  const body = {
    entity_type: entityType,
    entity_name: config.AGENTIX_ENTITY_NAME,
    payload,
    constants,
  };
  // `bundle` is mandatory (the API answers 422 "Field required" without it).
  if (config.AGENTIX_BUNDLE) body.bundle = config.AGENTIX_BUNDLE;

  // `entity_version` is the agent's own version and is safe to send. The
  // top-level `version` is the *bundle* version and is deliberately NOT sent:
  // passing the agent's version there answers 422 "Bundle not found", and
  // passing the real bundle version answers 409 when that exact build is not
  // fully approved in the registry. Omitting it lets the platform resolve the
  // current approved build — which also survives the CI rebuilding the bundle
  // under a new version suffix (0.1.0.devN+g<sha>) on every merge.
  if (config.AGENTIX_ENTITY_VERSION) body.entity_version = config.AGENTIX_ENTITY_VERSION;

  const token = await getAccessToken();
  let resp;
  try {
    resp = await axios.post(`${base}/sessions/invoke`, body, {
      timeout: REQUEST_TIMEOUT_MS,
      maxRedirects: 0,
      headers: authHeaders(token),
    });
  } catch (e) {
    throw wrapApiError(e, 'A AgentiX recusou a execução');
  }
  const sessionId = resp.data?.session_id;
  if (!sessionId) throw new Error('AgentiX não retornou session_id');
  return { sessionId, state: sessionState(resp.data) || 'CREATED' };
}

export async function getSession(sessionId) {
  const base = assertHttps(config.AGENTIX_BASE_URL, 'AGENTIX_BASE_URL');
  const token = await getAccessToken();
  const resp = await axios.get(`${base}/sessions/${encodeURIComponent(sessionId)}`, {
    timeout: REQUEST_TIMEOUT_MS,
    maxRedirects: 0,
    headers: authHeaders(token),
  });
  return resp.data || {};
}

// GET /sessions/{id} does NOT carry the answer — a real DONE session returned
// `partial_output: null`, `stages: []` and no result field at all (confirmed
// 2026-08-19). Two other endpoints do, both plain REST, no SSE needed:
//
//   /artifacts → { partial_output, files, event_outputs } — partial_output is
//                the already-parsed answer object. Small (~6 KB). Preferred.
//   /messages  → [{role, content}, ...] — the assistant turn holds the same
//                answer as a JSON string, but the payload echoes the whole
//                prompt back (~40 KB), so it is only the fallback.
export async function getSessionArtifacts(sessionId) {
  const base = assertHttps(config.AGENTIX_BASE_URL, 'AGENTIX_BASE_URL');
  const token = await getAccessToken();
  const resp = await axios.get(`${base}/sessions/${encodeURIComponent(sessionId)}/artifacts`, {
    timeout: REQUEST_TIMEOUT_MS,
    maxRedirects: 0,
    headers: authHeaders(token),
  });
  return resp.data || {};
}

export async function getSessionMessages(sessionId) {
  const base = assertHttps(config.AGENTIX_BASE_URL, 'AGENTIX_BASE_URL');
  const token = await getAccessToken();
  const resp = await axios.get(`${base}/sessions/${encodeURIComponent(sessionId)}/messages`, {
    timeout: REQUEST_TIMEOUT_MS,
    maxRedirects: 0,
    headers: authHeaders(token),
  });
  return Array.isArray(resp.data) ? resp.data : resp.data?.items || [];
}

// The answer, as an object when the platform already parsed it or as the raw
// string otherwise. Null when neither endpoint has anything.
export async function fetchAnalysis(sessionId) {
  try {
    const { partial_output: output } = await getSessionArtifacts(sessionId);
    if (output && (typeof output === 'object' || String(output).trim())) return output;
  } catch (e) {
    logger.debug(`AgentiX artifacts unavailable for ${sessionId}: ${e.response?.status || e.message}`);
  }

  const messages = await getSessionMessages(sessionId);
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    const { role, content } = messages[i] || {};
    if (role === 'assistant' && typeof content === 'string' && content.trim()) return content.trim();
  }
  return null;
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Poll until the session leaves the running states or the budget runs out.
export async function waitForSession(sessionId, { timeoutMs = config.AGENTIX_TIMEOUT_MS, intervalMs = POLL_INTERVAL_MS } = {}) {
  const deadline = Date.now() + timeoutMs;
  let last = {};
  while (Date.now() < deadline) {
    last = await getSession(sessionId);
    if (!RUNNING_STATES.has(sessionState(last))) return last;
    await sleep(intervalMs);
  }
  const err = new Error('Tempo esgotado aguardando a análise da AgentiX');
  err.session = last;
  throw err;
}

// Full round trip: invoke, wait for the session to settle, then fetch the
// answer from the endpoint that actually holds it. Returns the analysis plus
// the session id, so the UI can deep-link the execution on the AgentiX console.
export async function analyzeFailure(payload) {
  const { sessionId } = await invokeSession(payload);
  logger.info(`AgentiX session started: ${sessionId}`);

  const session = await waitForSession(sessionId);
  const state = sessionState(session);

  if (state === 'AWAITING') {
    throw new Error('A sessão AgentiX ficou aguardando intervenção humana (HITL) e não retornou análise');
  }
  if (state === 'FAILED') {
    throw new Error(`A execução na AgentiX falhou: ${session.error_message || session.error || 'sem detalhe'}`);
  }

  const analysis = await fetchAnalysis(sessionId);
  if (!analysis) throw new Error('A AgentiX concluiu a sessão mas nenhum texto de análise foi encontrado');
  return { sessionId, state, analysis };
}

// Rate the session on the platform: `positive` when a person endorsed the
// analysis, `negative` when they corrected it. The note carries what they
// actually wrote, which is the useful signal for whoever maintains the agent
// (aggregated per bundle at GET /bundles/{bundle}/feedback). Best-effort by
// design — a failure here must never lose the resolution the user just saved.
export async function sendSessionFeedback(sessionId, feedback, note) {
  if (!sessionId || !isConfigured()) return false;
  try {
    const base = assertHttps(config.AGENTIX_BASE_URL, 'AGENTIX_BASE_URL');
    const token = await getAccessToken();
    await axios.post(
      `${base}/sessions/${encodeURIComponent(sessionId)}/feedback`,
      { feedback, feedback_note: note ? String(note).slice(0, 2_000) : null },
      { timeout: REQUEST_TIMEOUT_MS, maxRedirects: 0, headers: authHeaders(token) },
    );
    return true;
  } catch (e) {
    logger.debug(`AgentiX feedback not recorded for ${sessionId}: ${apiErrorMessage(e)}`);
    return false;
  }
}
