import { processChangeTasksFromContent, extractRunUrls, findParentInRawCsvContent } from './csv.js';
import { getRunInfoFromUrl } from './github.js';
import { getCached, setCached } from './cache.js';
import { getSharedAnnotation } from './state.js';

// Build the dashboard rows from in-memory CSV content, resolving each run's live
// status from GitHub (with TTL caching). File reads happen at the route layer,
// behind path validation, so this layer never touches the filesystem.
export async function buildRowsFromCsv(csvContent, userToken = null, sessionToken = null) {
  const df = processChangeTasksFromContent(csvContent);

  const metadataMap = {};
  const uniqueUrls = [];
  for (const row of df) {
    const parent = typeof row.CHANGE === 'string' ? row.CHANGE : '';
    const horario = row['HORÁRIO'] || '';
    for (const url of extractRunUrls(row.DESCRIPTION || '')) {
      if (!metadataMap[url]) metadataMap[url] = { CHANGE: parent, HORÁRIO: horario };
      if (!uniqueUrls.includes(url)) uniqueUrls.push(url);
    }
  }

  const rows = [];
  const pending = [];
  for (const url of uniqueUrls) {
    const cached = getCached(url);
    if (cached) rows.push({ ...cached, ...metadataMap[url] });
    else pending.push(url);
  }

  await Promise.all(
    pending.map(async (url) => {
      let data;
      try {
        data = await getRunInfoFromUrl(url, userToken || sessionToken);
      } catch (e) {
        data = {
          url,
          status: 'Error',
          conclusion: String(e),
          badge_class: 'unknown',
          reruns: 1,
          executor: '',
          executorEmail: '',
        };
      }
      const meta = metadataMap[url] || {};
      if (!meta.CHANGE) {
        meta.CHANGE = findParentInRawCsvContent(url, csvContent);
      }
      const merged = { ...data, ...meta };
      rows.push(merged);
      setCached(url, { ...merged });
    }),
  );

  // Sort by HORÁRIO ascending; empty last.
  rows.sort((a, b) => {
    const ad = a['HORÁRIO'] ? new Date(a['HORÁRIO']) : null;
    const bd = b['HORÁRIO'] ? new Date(b['HORÁRIO']) : null;
    if (!ad && !bd) return 0;
    if (!ad) return 1;
    if (!bd) return -1;
    return ad - bd;
  });

  for (const row of rows) {
    const annotation = getSharedAnnotation(row.url);
    row.comment = annotation.comment;
    row.rerunChecked = annotation.rerunChecked;
  }

  return rows;
}
