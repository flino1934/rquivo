import { parse } from 'csv-parse/sync';

// Repositories matching these fragments are intentionally excluded from the panel.
const EXCLUDED_FRAGMENTS = ['-pxy-', '-iac-', '-demise-', 'bradesco-next'];

export function extractRunUrls(text) {
  const re = /https:\/\/github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/actions\/runs\/(\d+)/g;
  const found = new Set();
  const s = String(text || '');
  let m;
  while ((m = re.exec(s)) !== null) {
    const url = m[0];
    const lower = url.toLowerCase();
    if (EXCLUDED_FRAGMENTS.some((frag) => lower.includes(frag))) continue;
    found.add(url);
  }
  return Array.from(found);
}

function pad2(value) {
  return String(value).padStart(2, '0');
}

export function toYmdHms(dateObj) {
  const yyyy = dateObj.getFullYear();
  return `${yyyy}-${pad2(dateObj.getMonth() + 1)}-${pad2(dateObj.getDate())} ${pad2(
    dateObj.getHours(),
  )}:${pad2(dateObj.getMinutes())}:${pad2(dateObj.getSeconds())}`;
}

export function parsePlannedDate(str) {
  if (!str) return null;
  const s = String(str).trim();
  // ISO-like: 2025-10-21 14:30[:45] or 2025-10-21T14:30:45Z
  const isoMatch = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
  if (isoMatch) {
    const [, y, m, d, H, M, S] = isoMatch;
    const dt = new Date(Number(y), Number(m) - 1, Number(d), Number(H), Number(M), Number(S || '0'));
    if (!Number.isNaN(dt.getTime())) return dt;
  }
  // BR: DD/MM/YYYY HH:MM[:SS]
  const brMatch = s.match(/^(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})(?::(\d{2}))?/);
  if (brMatch) {
    const [, d, m, y, H, M, S] = brMatch;
    const dt = new Date(Number(y), Number(m) - 1, Number(d), Number(H), Number(M), Number(S || '0'));
    if (!Number.isNaN(dt.getTime())) return dt;
  }
  const dt = new Date(s);
  if (!Number.isNaN(dt.getTime())) return dt;
  return null;
}

export function processChangeTasksFromContent(content) {
  if (!content) return [];
  const rows = parse(content, {
    columns: (header) => header.map((h) => String(h).toLowerCase().trim()),
    skip_empty_lines: true,
    trim: true,
  });

  let df = rows;
  if (rows.length && Object.prototype.hasOwnProperty.call(rows[0], 'parent.state')) {
    df = df.filter((r) => !['New', 'Authorize'].includes(String(r['parent.state'] || '').trim()));
  }

  // Keep only relevant columns, tolerating alternate headers.
  df = df.map((r) => {
    const out = {};
    if ('parent' in r) out.CHANGE = r.parent;
    if ('planned_start_date' in r) out.PLANNED_START_DATE = r.planned_start_date;
    if (!out.PLANNED_START_DATE) {
      if ('planned start date' in r) out.PLANNED_START_DATE = r['planned start date'];
      else if ('start_date' in r) out.PLANNED_START_DATE = r.start_date;
      else if ('start' in r) out.PLANNED_START_DATE = r.start;
    }
    if ('description' in r) out.DESCRIPTION = r.description;
    return out;
  });

  // Normalize DESCRIPTION to comma-joined GitHub run URLs, dropping rows without any.
  df = df
    .map((r) => ({ ...r, DESCRIPTION: extractRunUrls(String(r.DESCRIPTION || '')).join(', ') }))
    .filter((r) => (r.DESCRIPTION || '').trim() !== '');

  // Sort by planned start date if present (empty last).
  df.sort((a, b) => {
    const ap = parsePlannedDate(a.PLANNED_START_DATE);
    const bp = parsePlannedDate(b.PLANNED_START_DATE);
    if (!ap && !bp) return 0;
    if (!ap) return 1;
    if (!bp) return -1;
    return ap - bp;
  });

  // Rename PLANNED_START_DATE -> HORÁRIO formatted as 'YYYY-MM-DD HH:MM:SS'.
  return df.map((r) => {
    const d = r.PLANNED_START_DATE ? parsePlannedDate(r.PLANNED_START_DATE) : null;
    const horario = d && !Number.isNaN(d.getTime()) ? toYmdHms(d) : '';
    const { PLANNED_START_DATE, ...rest } = r;
    return { ...rest, HORÁRIO: horario };
  });
}

function findParentInRows(targetUrl, rows) {
  for (const row of rows) {
    for (const cell of row) {
      if (String(cell).includes(targetUrl)) {
        if (row.length > 1 && String(row[1]).trim()) return String(row[1]).trim();
        if (row.length > 0 && String(row[0]).trim()) return String(row[0]).trim();
      }
    }
  }
  return '';
}

export function findParentInRawCsvContent(targetUrl, content) {
  try {
    if (!content) return '';
    return findParentInRows(targetUrl, parse(content, { skip_empty_lines: true }));
  } catch {
    return '';
  }
}
