import fs from 'fs';
import path from 'path';
import multer from 'multer';
import { config } from '../config/env.js';
import { sharedDashboardState } from './state.js';
import { isSafeCsvName } from '../lib/safe-path.js';

const ALLOWED_EXT = new Set(['csv']);

export function allowedFile(name) {
  const parts = (name || '').split('.');
  const ext = parts.length > 1 ? parts.pop().toLowerCase() : '';
  return ALLOWED_EXT.has(ext);
}

// Build a human-readable, filesystem-safe filename with a 'YYYY-MM-DD__HH-mm' prefix.
export function buildStoredCsvFilename(originalname = 'upload.csv') {
  let safeName = path.basename(originalname);
  safeName = safeName.replace(/[^a-zA-Z0-9_.-]/g, '_');
  safeName = safeName.replace(/\.{2,}/g, '_');

  const now = new Date();
  const p = (n) => String(n).padStart(2, '0');
  const prefix = `${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())}__${p(
    now.getHours(),
  )}-${p(now.getMinutes())}`;
  return `${prefix}_${safeName}`;
}

const storage = config.HAS_PERSISTENT_UPLOADS
  ? multer.diskStorage({
      destination: (req, file, cb) => cb(null, config.UPLOAD_FOLDER),
      filename: (req, file, cb) => cb(null, buildStoredCsvFilename(file.originalname)),
    })
  : multer.memoryStorage();

// Reject unsupported extensions *before* multer writes anything. Without this,
// diskStorage saves the file first and the route's own check only redirects —
// leaving an orphan on the volume that the CSV-only cleanup never reclaims.
function fileFilter(req, file, cb) {
  cb(null, allowedFile(file.originalname));
}

export const upload = multer({ storage, fileFilter, limits: { fileSize: config.MAX_UPLOAD_BYTES } });

export function listAvailableCsvs() {
  if (!config.HAS_PERSISTENT_UPLOADS) {
    return Array.from(sharedDashboardState.memoryCsvStore.keys())
      .filter(isSafeCsvName)
      .sort((a, b) => b.localeCompare(a));
  }
  if (!fs.existsSync(config.UPLOAD_FOLDER)) return [];
  return fs
    .readdirSync(config.UPLOAD_FOLDER)
    .filter(isSafeCsvName)
    .sort((a, b) => b.localeCompare(a));
}
