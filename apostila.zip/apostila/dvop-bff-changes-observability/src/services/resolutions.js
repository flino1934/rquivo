// Catalogue of resolved pipeline failures: for a failure the AgentiX agent
// analysed, what a human confirmed was the actual cause and the actual fix.
//
// This is deliberately NOT a copy of the agent's answer. The agent produces a
// hypothesis (often `confidence: medium`); persisting that unreviewed would
// build a reference base out of guesses, and feeding it back into later
// analyses would let one wrong guess become tomorrow's premise. What is stored
// here is what a person endorsed or corrected — which is also why the diff
// between the agent's proposal and the saved text is worth keeping.
//
// Same persistence contract as the annotations store: the in-memory Map is the
// source of truth (reads stay synchronous), disk is a mirror written on every
// mutation, and with no DATA_DIR configured the whole thing is memory-only.
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { config } from '../config/env.js';
import { logger } from '../lib/logger.js';

const RESOLUTIONS_FILE = config.RESOLUTIONS_FILE;

// id -> resolution
const resolutions = new Map();

// Fragmentos voláteis que fazem duas ocorrências da mesma falha parecerem
// diferentes. Removê-los é o que permite a assinatura casar entre execuções.
const VOLATILE = [
  /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi, // uuid
  /\b[0-9a-f]{7,64}\b/gi, // sha / ids hexadecimais
  // `i` é obrigatório: a normalização faz toLowerCase() antes de aplicar estes
  // padrões, então um `T` maiúsculo aqui nunca casaria.
  /\d{4}-\d{2}-\d{2}[t ]\d{2}:\d{2}:\d{2}\S*/gi, // timestamps
  /\bduration_ms=\d+/gi,
  /\b\d{4,}\b/g, // ids de execução, portas, números longos
  /https?:\/\/\S+/gi,
];

function normalize(parts) {
  let out = parts.join('|').toLowerCase();
  for (const pattern of VOLATILE) out = out.replace(pattern, ' ');
  return out.replace(/[^a-z0-9|/ ]+/g, ' ').replace(/\s+/g, ' ').trim();
}

const hash = (texto) => crypto.createHash('sha256').update(texto).digest('hex').slice(0, 16);

function stepNames(failedSteps) {
  return (Array.isArray(failedSteps) ? failedSteps : [])
    .map((s) => `${s?.job || ''}/${s?.name || ''}`)
    .sort();
}

// Chave estável para "esta mesma falha já aconteceu neste projeto": repositório,
// workflow e os steps que falharam.
//
// Derivada de ONDE a pipeline quebrou, não do texto do log, por duas razões.
// Primeira: precisa existir ANTES da análise, porque as resoluções conhecidas
// viajam junto com o pedido ao agente; uma chave tirada da resposta dele
// chegaria tarde demais. Segunda: a primeira linha de erro seria péssima chave —
// o ruído do Tag Runner aparece em quase toda execução e todas cairiam no mesmo
// balde.
//
// O preço é que duas falhas distintas no mesmo step compartilham assinatura. Por
// isso o registro é apresentado como indício a verificar, nunca como veredito:
// quem decide se a causa é a mesma é o log da execução atual.
export function buildSignature({ repository, workflow, failedSteps } = {}) {
  const normalized = normalize([repository || '', workflow || '', ...stepNames(failedSteps)]);
  return normalized.replace(/[| ]/g, '') ? hash(normalized) : '';
}

// Chave só dos steps, sem repositório nem workflow. Existe porque as falhas mais
// comuns aqui não são do código da aplicação e sim da esteira corporativa
// compartilhada — o gate do ACS, o Key Vault, o Nexus — que chega a todos os
// projetos pelos mesmos reusable workflows, com os mesmos nomes de step. O
// conhecimento mais útil é justamente o que cruza repositórios; sem esta chave,
// ele ficaria invisível.
export function buildStepSignature({ failedSteps } = {}) {
  const normalized = normalize(stepNames(failedSteps));
  return normalized.replace(/[| ]/g, '') ? hash(normalized) : '';
}

function load() {
  if (!RESOLUTIONS_FILE || !fs.existsSync(RESOLUTIONS_FILE)) return;
  try {
    const obj = JSON.parse(fs.readFileSync(RESOLUTIONS_FILE, 'utf8'));
    for (const [id, value] of Object.entries(obj || {})) {
      if (value && typeof value === 'object') resolutions.set(id, value);
    }
    logger.info(`Loaded ${resolutions.size} resolution(s) from ${RESOLUTIONS_FILE}`);
  } catch (e) {
    logger.warn(`Could not load resolutions from ${RESOLUTIONS_FILE}: ${e.message || e}`);
  }
}

function persist() {
  if (!RESOLUTIONS_FILE) return;
  try {
    fs.mkdirSync(path.dirname(RESOLUTIONS_FILE), { recursive: true });
    const tmp = `${RESOLUTIONS_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(Object.fromEntries(resolutions)), 'utf8');
    fs.renameSync(tmp, RESOLUTIONS_FILE); // atomic replace
  } catch (e) {
    logger.warn(`Could not persist resolutions to ${RESOLUTIONS_FILE}: ${e.message || e}`);
  }
}

load();

const text = (value, max) => String(value ?? '').trim().slice(0, max);

// Record a resolution. `solution` is what the person says actually fixed it and
// is the only mandatory field — without it there is nothing worth referencing.
export function addResolution({
  signature,
  stepSignature,
  category,
  problem,
  cause,
  solution,
  repository,
  runUrl,
  change,
  sessionId,
  author,
}) {
  const cleanSolution = text(solution, 2_000);
  if (!cleanSolution) return null;

  const entry = {
    id: crypto.randomUUID(),
    signature: text(signature, 64),
    stepSignature: text(stepSignature, 64),
    category: text(category, 40) || 'unknown',
    problem: text(problem, 1_000),
    cause: text(cause, 2_000),
    solution: cleanSolution,
    repository: text(repository, 140),
    runUrl: text(runUrl, 500),
    change: text(change, 100),
    sessionId: text(sessionId, 64),
    author: text(author, 120),
    createdAt: new Date().toISOString(),
  };

  resolutions.set(entry.id, entry);
  persist();
  return entry;
}

// Resoluções relevantes para uma análise, mais recentes primeiro, em três
// níveis de proximidade:
//
//   3. mesma falha, mesmo projeto        (repositório + workflow + steps)
//   2. mesmo step, QUALQUER repositório  (falha da esteira compartilhada)
//   1. mesmo projeto, outro step
//
// Só o nível 3 vai como `exact`; os demais como `related`, que o agente trata
// explicitamente como indício a verificar, nunca como evidência. A busca erra
// de propósito para o lado de trazer material demais — quem filtra com o log em
// mãos é o agente.
export function findResolutions({ signature, stepSignature, repository }, limit = 5) {
  const nivel = (r) => {
    if (signature && r.signature === signature) return 3;
    if (stepSignature && r.stepSignature === stepSignature) return 2;
    if (repository && r.repository === repository) return 1;
    return 0;
  };

  return Array.from(resolutions.values())
    .map((r) => ({ r, score: nivel(r) }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score || String(b.r.createdAt).localeCompare(String(a.r.createdAt)))
    .slice(0, limit)
    .map((x) => ({ ...x.r, match: x.score === 3 ? 'exact' : 'related' }));
}

export function listResolutions() {
  return Array.from(resolutions.values()).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
}

// Test seam: the module loads from disk once at import time.
export function resetResolutions() {
  resolutions.clear();
}
