import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { logger } from '../lib/logger.js';
import { sanitizeDirPath } from '../lib/safe-path.js';

// O .env é do desenvolvedor, não da suíte: carregá-lo em teste faria o
// resultado depender da máquina (um .env com AGENTIX_* configurado, por
// exemplo, muda o comportamento esperado das rotas).
if (process.env.NODE_ENV !== 'test') dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const ROOT_DIR = path.resolve(path.dirname(__filename), '..', '..');

// Sanitize BASE_PATH to prevent path manipulation and open-redirect attacks.
export function sanitizeBasePath(basePath) {
  if (!basePath || typeof basePath !== 'string') return '/painel';

  let sanitized = basePath.trim();
  if (!sanitized.startsWith('/')) sanitized = '/' + sanitized;
  if (sanitized.length > 1 && sanitized.endsWith('/')) sanitized = sanitized.slice(0, -1);

  if (sanitized.includes('://') || sanitized.startsWith('//')) {
    logger.warn(`Malicious BASE_PATH detected: ${basePath}`);
    return '/painel';
  }
  if (sanitized.includes('..') || sanitized.includes('\\')) {
    logger.warn(`Path traversal attempt in BASE_PATH: ${basePath}`);
    return '/painel';
  }
  if (!/^\/[a-zA-Z0-9/_-]*$/.test(sanitized)) {
    logger.warn(`Invalid characters in BASE_PATH: ${basePath}`);
    return '/painel';
  }
  return sanitized;
}

const NODE_ENV = process.env.NODE_ENV || 'development';

// Optional shared data directory — typically a mounted persistent volume. When
// set (e.g. DATA_DIR=/data in the deployment), CSV uploads and the dashboard
// annotations are stored here so they survive pod restarts/redeploys. Sanitized
// (normalized + allowlisted) before any filesystem use.
const DATA_DIR = sanitizeDirPath(process.env.DATA_DIR);

function resolveWritableUploadFolder() {
  // Candidate dirs are sanitized (normalized + allowlisted) before any fs use,
  // so an environment-provided path can never drive a filesystem operation raw.
  const candidates = [
    process.env.UPLOAD_FOLDER,
    DATA_DIR ? path.join(DATA_DIR, 'uploads') : null,
    path.join(ROOT_DIR, 'uploads'),
    '/tmp/uploads',
  ]
    .map(sanitizeDirPath)
    .filter(Boolean);
  for (const candidate of candidates) {
    try {
      fs.mkdirSync(candidate, { recursive: true });
      const probe = path.join(candidate, '.write-probe');
      fs.writeFileSync(probe, 'ok');
      fs.unlinkSync(probe);
      return candidate;
    } catch {
      logger.warn(`Upload folder not writable: ${candidate}. Trying next option...`);
    }
  }
  logger.warn('No writable upload folder available. Falling back to in-memory CSV uploads.');
  return null;
}

const INSECURE_SECRETS = new Set(['', 'change-me-in-production', 'change_me_in_prod']);

// Resolve the session secret. If none is provided (or only an insecure default),
// generate a strong ephemeral one so the app can boot without depending on a
// secret store. Note: an ephemeral secret invalidates sessions on restart and is
// not shared across replicas — set SESSION_SECRET explicitly for multi-replica.
function resolveSessionSecret() {
  const provided = (process.env.SESSION_SECRET || process.env.FLASK_SECRET_KEY || '').trim();
  if (provided && !INSECURE_SECRETS.has(provided)) return provided;
  const generated = crypto.randomBytes(48).toString('base64');
  if (NODE_ENV === 'production') {
    logger.warn(
      'SESSION_SECRET not set; using a generated ephemeral secret. Sessions will not survive ' +
        'restarts and are not shared across replicas. Set SESSION_SECRET (or use sticky sessions) ' +
        'when running more than one replica.',
    );
  }
  return generated;
}

export const config = {
  NODE_ENV,
  isProduction: NODE_ENV === 'production',
  isTest: NODE_ENV === 'test',
  PORT: Number(process.env.PORT) || 8080,
  BASE_PATH: sanitizeBasePath(process.env.BASE_PATH || '/painel'),
  TRUST_PROXY: process.env.TRUST_PROXY === 'true' || process.env.TRUST_PROXY === '1',

  ROOT_DIR,
  INPUT_FILE: path.join(ROOT_DIR, 'input', 'change_task.csv'),
  UPLOAD_FOLDER: resolveWritableUploadFolder(),
  DATA_DIR: DATA_DIR || '',
  // File backing the shared annotations. Empty disables persistence (in-memory only).
  ANNOTATIONS_FILE: DATA_DIR ? path.join(DATA_DIR, 'annotations.json') : '',
  // Catálogo de falhas resolvidas. Vazio desabilita a persistência (só memória).
  RESOLUTIONS_FILE: DATA_DIR ? path.join(DATA_DIR, 'resolutions.json') : '',

  GITHUB_TOKEN: (process.env.GITHUB_TOKEN || '').trim(),

  // --- AgentiX 2.0 (plataforma interna de agentes) -------------------------
  // Integração opcional: sem AGENTIX_BASE_URL + credencial + entidade, a rota
  // de análise responde 503 e o resto do painel segue funcionando normalmente.
  AGENTIX_BASE_URL: (process.env.AGENTIX_BASE_URL || '').trim().replace(/\/+$/, ''),
  AGENTIX_TENANT_ID: (process.env.AGENTIX_TENANT_ID || '').trim(),
  // Token estático (ex.: injetado por um secret) tem precedência sobre o login
  // ROPC no Keycloak, que é o único fluxo automatizável confirmado até aqui.
  AGENTIX_TOKEN: (process.env.AGENTIX_TOKEN || '').trim(),
  AGENTIX_KEYCLOAK_URL: (process.env.AGENTIX_KEYCLOAK_URL || '').trim().replace(/\/+$/, ''),
  AGENTIX_CLIENT_ID: (process.env.AGENTIX_CLIENT_ID || 'agx-front').trim(),
  AGENTIX_USERNAME: (process.env.AGENTIX_USERNAME || '').trim(),
  AGENTIX_PASSWORD: process.env.AGENTIX_PASSWORD || '',
  // Entidade executável publicada no tenant (ver POST /sessions/invoke).
  AGENTIX_ENTITY_TYPE: (process.env.AGENTIX_ENTITY_TYPE || 'agent').trim(),
  AGENTIX_ENTITY_NAME: (process.env.AGENTIX_ENTITY_NAME || '').trim(),
  AGENTIX_ENTITY_VERSION: (process.env.AGENTIX_ENTITY_VERSION || '').trim(),
  AGENTIX_BUNDLE: (process.env.AGENTIX_BUNDLE || '').trim(),
  AGENTIX_TIMEOUT_MS: Number(process.env.AGENTIX_TIMEOUT_MS) || 120_000,

  SESSION_SECRET: resolveSessionSecret(),
  SESSION_TTL_MS: Number(process.env.SESSION_TTL_MS) || 1000 * 60 * 60 * 8, // 8h
  COOKIE_SECURE: process.env.COOKIE_SECURE === 'true',
  COOKIE_SAMESITE: process.env.COOKIE_SAMESITE || 'lax',
  REDIS_URL: process.env.REDIS_URL || '',

  RATE_LIMIT_WINDOW_MS: Number(process.env.RATE_LIMIT_WINDOW_MS) || 60_000,
  RATE_LIMIT_MAX: Number(process.env.RATE_LIMIT_MAX) || 300,

  CACHE_TTL_MS: Number(process.env.CACHE_TTL_MS) || 10 * 1000,
  MAX_UPLOAD_BYTES: 16 * 1024 * 1024, // 16MB
  UPLOAD_RETENTION_DAYS: Math.max(1, Number(process.env.UPLOAD_RETENTION_DAYS) || 30),
};

config.HAS_PERSISTENT_UPLOADS = Boolean(config.UPLOAD_FOLDER);

// Validate production configuration. The session secret is no longer required
// (a strong ephemeral one is generated when absent — see resolveSessionSecret).
export function validateProductionConfig() {
  if (!config.isProduction) return;
  if (config.COOKIE_SECURE && !config.TRUST_PROXY) {
    logger.warn(
      'COOKIE_SECURE is enabled but TRUST_PROXY is false; secure cookies require HTTPS/TLS termination.',
    );
  }
}
