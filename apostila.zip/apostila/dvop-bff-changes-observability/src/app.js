import path from 'path';
import express from 'express';
import session from 'express-session';
import { config, validateProductionConfig } from './config/env.js';
import { logger } from './lib/logger.js';
import { safeRedirect } from './lib/redirect.js';
import { applySecurityMiddleware, applyRateLimit } from './middleware/security.js';
import { registerHealthRoutes } from './routes/health.js';
import { dashboardRouter } from './routes/dashboard.js';
import { tokenRouter } from './routes/token.js';

validateProductionConfig();

const app = express();

if (config.TRUST_PROXY) app.set('trust proxy', 1);

app.set('view engine', 'ejs');
app.set('views', path.join(config.ROOT_DIR, 'views'));

applySecurityMiddleware(app);

// Static assets are served under the base path to avoid route collisions.
app.use(`${config.BASE_PATH}/static`, express.static(path.join(config.ROOT_DIR, 'static')));
app.use(express.json({ limit: '2mb' }));

// Health endpoints are registered before rate limiting and sessions.
registerHealthRoutes(app);
applyRateLimit(app);

// Optional Redis-backed session store (falls back to in-memory MemoryStore).
let sessionStore;
if (config.REDIS_URL) {
  try {
    const { createClient } = await import('redis');
    const connectRedis = await import('connect-redis');
    const RedisStore = connectRedis.RedisStore || connectRedis.default;
    const redisClient = createClient({ url: config.REDIS_URL });
    await redisClient.connect();
    sessionStore = new RedisStore({ client: redisClient, prefix: 'sess:' });
    logger.info('Using Redis session store');
  } catch (e) {
    logger.warn(`REDIS_URL set but Redis init failed; falling back to MemoryStore: ${e.message || e}`);
  }
}

app.use(
  session({
    secret: config.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: {
      httpOnly: true,
      secure: config.COOKIE_SECURE || (config.isProduction && config.TRUST_PROXY),
      sameSite: config.COOKIE_SAMESITE,
      maxAge: config.SESSION_TTL_MS,
      path: '/',
    },
  }),
);

app.use(config.BASE_PATH, dashboardRouter);
app.use(config.BASE_PATH, tokenRouter);

// Convenience redirect from the root to the base path.
app.get('/', (req, res) => safeRedirect(res));

export default app;
