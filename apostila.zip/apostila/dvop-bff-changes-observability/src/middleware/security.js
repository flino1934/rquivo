import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { config } from '../config/env.js';

// Content-Security-Policy: scripts are served from our own origin only (no inline
// scripts/handlers). Inline styles are allowed; the Inter font comes from Google Fonts.
const cspDirectives = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'"],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
  fontSrc: ["'self'", 'https://fonts.gstatic.com'],
  imgSrc: ["'self'", 'data:'],
  connectSrc: ["'self'"],
  objectSrc: ["'none'"],
  baseUri: ["'self'"],
  formAction: ["'self'"],
  frameAncestors: ["'self'"],
};

export function applySecurityMiddleware(app) {
  // Logging is useful in every environment; keep it lightweight under tests.
  if (!config.isTest) {
    app.use(morgan(config.isProduction ? 'combined' : 'dev'));
  }

  // Skip heavier middleware during tests to keep them fast and deterministic.
  if (config.isTest) return;

  app.use(
    helmet({
      contentSecurityPolicy: { useDefaults: true, directives: cspDirectives },
      crossOriginEmbedderPolicy: false,
      hsts: { maxAge: 31_536_000, includeSubDomains: true, preload: true },
    }),
  );
  app.use(compression());
}

// Applied after health routes so liveness/readiness checks are never throttled.
export function applyRateLimit(app) {
  if (config.isTest) return;
  app.use(
    rateLimit({
      windowMs: config.RATE_LIMIT_WINDOW_MS,
      limit: config.RATE_LIMIT_MAX,
      standardHeaders: true,
      legacyHeaders: false,
    }),
  );
}
