import { config } from '../config/env.js';

// Resolve a usable GitHub token from the session or the global fallback.
// When none is available, flag the request so routes can prompt for one.
export function requireToken(req, res, next) {
  if (req.session?.githubToken || config.GITHUB_TOKEN) return next();
  req.needsToken = true;
  return next();
}
