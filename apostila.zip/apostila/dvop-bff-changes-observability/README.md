# DVOP BFF — Changes Observability

Painel web em **Node.js/Express** que lê CSVs de _change tasks_, extrai URLs de execuções
do **GitHub Actions** e exibe, em tempo (quase) real, o status de cada workflow. Permite
filtrar, comentar, marcar reruns e exportar para XLSX.

## Funcionalidades

- **Upload de CSV** pela interface (ou seleção de um CSV enviado anteriormente).
- **Status ao vivo** das execuções via API do GitHub, com cache em memória (TTL configurável).
- **Filtros no cliente**: busca por texto, por resultado (sucesso/falha/etc.) e por horário.
- **Anotações compartilhadas**: comentário e marcação de _rerun_ por execução (estado da instância).
- **Exportação XLSX**: completo, apenas reruns, ou falhas + reruns.
- **Tema claro/escuro** e auto-refresh configurável.

## Requisitos

- Node.js **20+** (recomendado 22.x).
- Um **Personal Access Token (PAT)** do GitHub com permissão `Actions: Read` nos repositórios
  monitorados. O token pode ser fornecido por usuário (na própria interface) ou globalmente
  via `GITHUB_TOKEN`.

## Início rápido

```powershell
npm install
Copy-Item .env.example .env   # edite o .env conforme necessário
npm run dev                   # ou: npm start
```

Acesse: `http://127.0.0.1:8080/painel`

Na primeira vez (sem `GITHUB_TOKEN` global) a aplicação pede um PAT, armazenado **apenas na
sessão** do navegador. O CSV padrão opcional é `input/change_task.csv`; uploads ficam em `uploads/`.

## Scripts

| Script                            | Descrição                                     |
| --------------------------------- | --------------------------------------------- |
| `npm start`                       | Inicia o servidor (`server.js`).              |
| `npm run dev`                     | Servidor com reload (`node --watch`).         |
| `npm test`                        | Testes (Node test runner + Supertest + nock). |
| `npm run lint` / `lint:fix`       | ESLint.                                       |
| `npm run format` / `format:check` | Prettier.                                     |

## Configuração (variáveis de ambiente)

Veja `.env.example`. Principais:

| Variável                                  | Padrão          | Descrição                                             |
| ----------------------------------------- | --------------- | ----------------------------------------------------- |
| `PORT`                                    | `8080`          | Porta HTTP.                                           |
| `BASE_PATH`                               | `/painel`       | Prefixo de rota (sanitizado).                         |
| `NODE_ENV`                                | `development`   | `production` endurece cookies/validações.             |
| `SESSION_SECRET`                          | gerado          | Opcional; se ausente, gera um secret efêmero no boot. |
| `SESSION_TTL_MS`                          | `28800000`      | Validade do cookie de sessão (8h).                    |
| `COOKIE_SECURE` / `COOKIE_SAMESITE`       | `false` / `lax` | Cookies de sessão.                                    |
| `TRUST_PROXY`                             | `false`         | `true` atrás de proxy/Ingress (cookies `secure`).     |
| `REDIS_URL`                               | —               | Store de sessão Redis (recomendado em produção).      |
| `RATE_LIMIT_WINDOW_MS` / `RATE_LIMIT_MAX` | `60000` / `300` | Rate limiting.                                        |
| `GITHUB_TOKEN`                            | —               | PAT de fallback (opcional).                           |
| `CACHE_TTL_MS`                            | `10000`         | TTL do cache de status.                               |
| `UPLOAD_FOLDER`                           | `./uploads`     | Diretório de uploads.                                 |
| `LOG_LEVEL`                               | `info` (prod)   | `error`/`warn`/`info`/`debug`.                        |

## Formato do CSV

A aplicação procura URLs do GitHub Actions em qualquer célula:

```
https://github.com/<owner>/<repo>/actions/runs/<id>
```

Colunas reconhecidas (opcionais): `parent` (CHANGE), `planned_start_date` (HORÁRIO),
`description` (onde as URLs costumam estar). Linhas com `parent.state` em `New`/`Authorize`
são descartadas, assim como repositórios contendo `-pxy-`, `-iac-`, `-demise-` ou `bradesco-next`.

## Arquitetura

```
server.js                 # bootstrap + shutdown gracioso
src/
  app.js                  # montagem do Express (segurança, sessão, rotas)
  config/env.js           # leitura/validação de ambiente
  lib/                    # logger, redirect seguro
  middleware/             # auth (token), security (helmet/CSP/compression/rate-limit)
  routes/                 # dashboard, token, health
  services/               # github, csv, rows, export, cache, state, uploads
views/                    # templates EJS (dashboard, token-setup)
static/                   # assets (JS do cliente, flatpickr)
docker/Dockerfile         # imagem de produção
```

## Segurança

- **Helmet** com **CSP estrita** (`script-src 'self'`; sem scripts/handlers inline).
- **Rate limiting**, **compression** e **HSTS** habilitados (exceto em testes).
- `SESSION_SECRET` é **opcional**: se ausente, um secret efêmero forte é gerado no boot (ver nota de réplicas em **Produção**).
- Tokens são validados na API do GitHub e guardados apenas na sessão; use `REDIS_URL` em produção.
- Proteções contra path traversal em `BASE_PATH`, seleção de CSV e open redirect.

## Testes

```powershell
npm test
```

Os testes usam o runner nativo do Node, **Supertest** (in-memory, sem abrir porta) e **nock**
para simular a API do GitHub. Cobrem parsing de CSV, mapeamento de status, health, anotações,
validação de token e exportação XLSX.

## Docker

```powershell
docker build -f docker/Dockerfile -t dvop-bff:local .

docker run --rm -it `
  -p 8080:8080 `
  -e NODE_ENV=production `
  -e SESSION_SECRET=$(openssl rand -hex 32) `
  -e BASE_PATH=/painel `
  -v ${PWD}/uploads:/app/uploads `
  dvop-bff:local
```

Healthcheck: `GET /health`. A imagem roda como usuário não-root.

## Produção

- Rode atrás de proxy TLS com `TRUST_PROXY=true` e `COOKIE_SECURE=true`.
- **Sessões:** se `SESSION_SECRET` não for definido, o app gera um secret efêmero no boot.
  Com **1 réplica** (cenário atual) isso é suficiente — a única consequência é que as sessões
  são invalidadas a cada restart/redeploy (basta logar de novo). Ao escalar para **múltiplas
  réplicas**, defina um `SESSION_SECRET` fixo (compartilhado entre os pods) ou habilite
  sticky sessions no Ingress, pois o cookie é assinado com esse secret. O `REDIS_URL` guarda os
  dados da sessão, mas não substitui o secret compartilhado.
- Centralize os logs (stdout) no seu stack de observabilidade.
- O `server.js` trata `SIGTERM`/`SIGINT` para encerramento gracioso em orquestradores.

---

Aplicação interna. Em caso de dúvidas, contate a equipe responsável.
