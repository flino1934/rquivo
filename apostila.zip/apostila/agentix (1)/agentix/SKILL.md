---
name: agentix
description: This skill should be used when the user mentions "AgentiX", "AgentiX 2.0", asks to integrate AI/LLM features via the Bradesco internal agent platform, references `agentix.corpti.bradesco.com.br`, `AGENTS.md`/OAF format, bundles/groups/squads/workflows for agents, `sessions/invoke`, or asks about calling/authenticating against the AgentiX API (v1 GraphQL or v2 REST) from a backend service such as dvop-bff.
version: 0.1.0
---

# AgentiX 2.0 (Bradesco internal agent platform)

AgentiX is the Bradesco/BIA Tech internal platform for building and running AI agents (Agno runtime). When a user wants to add AI capability to an internal app, the target is AgentiX — **not** a direct call to a provider SDK (Anthropic/OpenAI/etc.). A prior attempt to call `@anthropic-ai/sdk` directly was explicitly rejected and reverted; always route through AgentiX unless told otherwise.

## Core model (OAF)

Hierarchy: **Agent** (single task) → **Team** (multiple agents collaborating: `coordinate`/`route`/`broadcast`/`tasks`) → **Workflow** (ordered steps, each referencing a component). Context: **Tenant** → **Projeto** (published bundle) → **Sessão** (one execution) → **Artefato** (input/output file).

Bundle layout (OAF v3, `manifest_version: "3.0"`): only `bundle/` is deployable — manifest at `bundle/PACKAGE.yaml` (**not** `manifest.yaml`), one directory per executable at `bundle/<componente>/AGENTS.md` (YAML frontmatter: `name`, `kind`, `version`, `model`, `skills`, `tools`; Markdown body: objetivo/regras/critérios), skills local to the component at `bundle/<componente>/skills/<skill>/SKILL.md`. Never create `bundle/AGENTS.md`. Full structure, frontmatter fields and the DEV→HOM→PRD pipeline are in `references/bundle-oaf-v3.md`. Variables use `{{nome_variavel}}` in instructions, resolved via `constants` at invocation time. Secrets never go in Agent/Team — only in Workflow `constants` via `$(vault:...)` references.

Relevant Skills catalog: `http-client` (call external APIs), `github` (native GitHub App access), `file-io`, `csv-analysis`.

## Two APIs exist — use v1, not v2

This is the single most important, non-obvious fact: the platform has a newer v2 REST API and an older v1 GraphQL API, and **which one actually works depends on which tenant the calling account is provisioned in**.

- **v2 REST** (`https://agentix.corpti.bradesco.com.br/v2/api`, endpoint `POST /sessions/invoke`) — is live, but requires either personal username/password login (`POST /auth/login`) or interactive OIDC browser login (Keycloak, realm `Omega-AGX`, client `agx-front`). Neither suits unattended backend calls. It also depends on the account having a `tenant_id` associated in v2, which is not guaranteed (onboarding-dependent).
- **v1 GraphQL (legacy)** (`POST https://agentix.corpti.bradesco.com.br/orchestrator` for auxiliary calls, `POST https://agentix.corpti.bradesco.com.br/graphql/` for the GraphQL endpoint itself) — uses legacy terms (`Group`≈Workflow, `Squad`≈Team). **This is the path proven to work end-to-end** in testing (2026-08-07): login → tenant-mapping → `invoke` → poll `session` → `conversationLogs` → extract final JSON. See `references/api-v1-guide.md` for the full confirmed contract, including the critical gotcha that `session.result` is always `null` and the real output must be pulled from `conversationLogs`.

Before proposing any integration code, check `references/api-v1-guide.md` for the exact request/response shapes rather than assuming a generic REST/JSON contract.

## dvop-bff integration status

There is an ongoing integration in the `dvop-bff-changes-observability` repo (branch `feature/changes-observ-v3-30days`). Part 1 (payload generator, no AI call yet) is implemented but uncommitted. Part 2 (real AgentiX call via v1) is proven only in a standalone scratch script, not yet ported into the repo. Full state, file list, and remaining checklist are in `references/dvop-bff-integration.md` — read it before resuming or reporting status on this specific integration.

## Additional Resources

- **`references/api-v1-guide.md`** — confirmed v1 GraphQL contract: auth flow, tenant-mapping, `invoke` mutation shape, session polling, `conversationLogs` result-extraction algorithm, and the v2 REST contract/blockers for comparison.
- **`references/bundle-oaf-v3.md`** — authoring and shipping a bundle: `bundle/` layout and per-component contract, real `PACKAGE.yaml`/`AGENTS.md`/`SKILL.md` frontmatter from the official template, local validation commands, the reusable-workflow CI callers, `release-candidate` promotion flow and its failure modes, three-level SemVer rule.
- **`references/dvop-bff-integration.md`** — current state of the dvop-bff integration specifically (files touched, what's committed, what's pending, decisions still open).
