# dvop-bff AgentiX integration — current state

Repo: `dvop-bff-changes-observability`. Branch: `feature/changes-observ-v3-30days`. As of last check (2026-08-07, HEAD `47c4441`), working tree has uncommitted changes — verify current `git status` before assuming this is still accurate, since this is a point-in-time snapshot.

Goal: let the dashboard send failed-run data to an AgentiX agent for automatic failure analysis. Explicit user correction drove the approach: an earlier attempt used `@anthropic-ai/sdk` directly — this was rejected and reverted. The only acceptable path is through AgentiX.

## Part 1 — payload generator (done, not yet the AI call itself)

Uncommitted changes as of last check:
```
 M src/routes/dashboard.js
 M src/services/github.js
 M static/js/dashboard.js
 M views/dashboard.ejs
?? src/services/agentixPayload.js
```

- `src/services/github.js`: added `parseRunUrl()` (extract/validate owner/repo/runId from a GitHub Actions run URL) and `getFailedJobSteps()` (fetch failed steps via `.../actions/runs/{id}/jobs`, without downloading the full log).
- `src/services/agentixPayload.js` (new, zero dependencies): `buildFailureAnalysisPayload()` — builds the payload in AgentiX contract shape (`{ input, constants }`), with constants named to match `{{run_url}}`, `{{failed_steps}}` etc. in a future `AGENTS.md`.
- `src/routes/dashboard.js`: new route `POST /api/agentix-payload` — takes `{url, change, status, conclusion}`, fetches failed steps from GitHub, builds the payload, returns it as a download (`Content-Disposition: attachment`, `agentix-insumo-{runId}.json`). Protected by `requireToken`.
- `views/dashboard.ejs` + `static/js/dashboard.js`: 🤖 button next to the status badge, shown only when `badge_class === 'fail'`. Click hits the route above and downloads the JSON. Follows the app's strict-CSP pattern (event delegation, no inline handlers).
- Tests (88/88) and lint were passing with these changes as of last check.

This part only **generates the input file** — it does not call AgentiX yet.

## Part 2 — real AgentiX call (proven in a throwaway script, not yet ported)

Confirmed feasible end-to-end via `agentix-v1-test.mjs`, a standalone script that lived in a session scratchpad (**scratchpad does not survive between sessions — the script no longer exists and must be rewritten if resuming this work**). It proved: login → tenant-mapping → `invoke` on `dvop-agx-ssol-triagem` → poll `session` → `conversationLogs` → extract final JSON. Full technical contract is in `references/api-v1-guide.md` in this skill — do not re-derive it from scratch.

Not yet done: no `src/services/agentixClient.js` exists in the repo. The proven logic needs to be ported into the actual codebase.

### Update (2026-08-13) — v2 tenant blocker confirmed resolved (verified via real log)

A first log paste (2026-08-12T20:49) still showed the old error (`selectedTenantId: null`, `"AgentiX v2 não retornou tenant_id"`) — that was correctly flagged as unconfirmed. A second log paste, from a fresh login the next day (2026-08-13T19:55:31), shows the real confirmation: `[INFO] [TENANT] Single tenant found, auto-selecting — { "tenantId": "DVOP" }`, echoed in `syncState.selectedTenantId: "DVOP"`. The blocker resolved itself between 08-12 and 08-13, likely onboarding propagation. v2 REST is now viable, tenant `DVOP` (looks like a short slug, not a UUID like v1's format — confirm exact shape before hardcoding).

Same log also revealed the v2 tools/skills available to tenant `DVOP` (`GET /v2/api/tools`): `http_request`, `json_extract`, `list_files`, `read_file`, `regex_extract`, `template_render`, `text_summarize`, `write_file`.

### Update (2026-08-13, later same day) — ROPC login works for v2; allowed-models confirmed empty; no bundles exist yet

Extracting a live token from the extension turned out not to be practical (API calls happen in the Extension Host process, invisible to webview DevTools; the OIDC callback URL and Keycloak session cookies are both unusable — single-use code without the PKCE verifier, and session cookies aren't API tokens). Instead, a direct ROPC (`grant_type=password`) login against Keycloak with `client_id=agx-front` worked — undocumented but confirmed live. Full contract in `references/api-v1-guide.md`'s v2 section.

With that token, confirmed: `allowed_models: []` is real, not a logging artifact — **no LLM model is currently allowed for tenant `DVOP`, which blocks any v2 execution regardless of what bundle exists.** Also confirmed `GET /bundles` returns empty (`total: 0`) — nothing published in this tenant to reuse. And `GET /tenants/DVOP/agents` returns 404 — that endpoint from the plugin's code doesn't match the live API.

**Revised priority order:** 1) ask the AgentiX team to allow at least one LLM model for tenant `DVOP` (currently the single hard blocker); 2) ask whether a dedicated service account exists using the same `agx-front` client + ROPC grant, instead of relying on a personal password; 3) only after (1), author/publish a bundle in `DVOP`; 4) real endpoint for listing agents is still unconfirmed.

### Update (2026-08-13, later) — bundle built via UI; real schema captured; new Runner-permission blocker found

A real bundle was successfully built via the extension's visual wizard (Workflow → Agents → Review) and exported as `changes-observability_v1.0.0.zip`, containing the **real, confirmed** `manifest.yaml` + `AGENTS.md` + `SKILL.md` (full schema captured in `references/api-v1-guide.md`'s v2 bundle section — significantly different from what the conceptual PDFs described: two frontmatter blocks in one `AGENTS.md`, `tools:` not `skills:`, `harnessConfig.agentix-agx.execution.mode: worker`, etc.). The zip was initially exported into the git repo working directory (`output_bundle_v2/`, showed up untracked) and was moved to `Downloads\output_bundle_v2\` — it should never be committed.

Attempting to send/run this bundle via the extension's **Runner** tab failed: `Bundle status: Rejected — "You do not have permission to run Runner for this tenant. Verify that the tenant has one of the allowed roles: platform_admin, platform_viewer, tenant_admin, tenant_developer, or tenant_executor."` This contradicts the confirmed `/auth/me` response from the same day, which showed `role: tenant_admin` with all those roles present in `effective_permissions`. Two hypotheses, unresolved: (1) stale webview session/token — try logout+login first; (2) if that doesn't fix it, likely a third tenant-level configuration gap (Runner feature not enabled for tenant `DVOP`), same category as the empty `allowed_models` — would need the AgentiX team, not fixable by the user alone. **Not yet tested which one it is — check this first in the next session.**

### Open decisions / blockers before Part 2 can ship

From the AgentiX side (depends on others):
1. **Service credential** — testing has only used a personal username/password (Resource Owner Password grant against Keycloak `legacyx` client) or interactive OIDC browser login for v2. Need to ask the AgentiX team whether a `client_credentials` flow or dedicated service account exists — a personal credential should not be hardcoded into a backend service.
2. Confirm which `tenant_id` to use in production (v1: `9106a80c-dc62-535a-a3d8-c71dddc6eb22`; v2: `DVOP`, unconfirmed format — see above).
3. **Which bundle/group to actually use** — candidates seen: `dvop-agx-ssol-triagem` (tested, generic triage — not failure-analysis-specific) vs. `dvop-agx-agentix-fastsearch` (reportedly about GitHub Actions troubleshooting specifically, not yet inspected) vs. authoring a brand-new bundle purpose-built for failure summaries (using the `run_url`/`failed_steps`/`change`/`status`/`conclusion` constants already produced by Part 1). This is the most blocking open item — nothing else in Part 2 matters until a real agent exists to call.
4. Confirm network reachability of `agentix.corpti.bradesco.com.br` from the dvop-bff production environment.
5. Validate in a dev/hml AgentiX environment before hitting prod.

Implementation decisions (ours, not yet finalized):
6. Where to store the credential — same pattern as `GITHUB_TOKEN` (env var); suggested names `AGENTIX_API_KEY` / `AGENTIX_TENANT_ID`.
7. Sync vs async UX: `invoke` returns a `sessionId` immediately, the real result comes later via polling/`conversationLogs`. Decide whether the 🤖 button does a short poll-and-wait or becomes a fully async flow (e.g. poll from the frontend, or a "check back later" pattern).
8. Handle the `AWAITING` (HITL) state with a timeout/fallback, even though the intent is for the failure-analysis agent to never require human input.

## Also pending

Whether/when to commit the Part 1 changes — the user had not requested a commit as of last check. Do not commit without explicit confirmation (see the repo's general git-workflow rules).

## Update (2026-08-19) — Part 2 implemented against v2, end to end (raw logs → AgentiX → modal)

The user chose **v2** and specified the flow: clicking 🤖 makes the app enter the repo, download the run's **raw logs**, send them as the payload, and show the returned analysis. Implemented, **115/115 tests + lint green, still uncommitted**.

- `src/services/github.js` — `getFailedJobLogs()` + exported `trimLogTail()`. `GET /repos/{o}/{r}/actions/jobs/{jobId}/logs` answers **302 to a signed blob URL**; since the shared axios client sets `maxRedirects: 0`, the hop is followed manually with `validateStatus` accepting 302/200, an HTTPS + host-suffix allowlist on `Location`, and the `Authorization` header deliberately not forwarded. Caps: 3 failed jobs, 200 lines / 20k chars each, ISO timestamps stripped.
- `src/services/agentixPayload.js` — adds a `failed_logs` constant (45k-char global budget, omitted jobs reported rather than silently dropped).
- `src/services/agentixClient.js` (**new**) — static `AGENTIX_TOKEN` or Keycloak ROPC (cached, 60s buffer) → `POST {base}/sessions/invoke` with `x-tenant-id` → poll `GET {base}/sessions/{id}` until it leaves CREATED/RUNNING/PENDING/QUEUED. `AWAITING` (HITL) and `FAILED` raise explicit errors. Polling was chosen over SSE: a BFF answering one HTTP request gains nothing from a stream, and proxies buffer event streams.
- `src/routes/dashboard.js` — `POST /api/agentix-analyze` (503 unconfigured, 400 bad url, 502 on AgentiX failure). The older `/api/agentix-payload` download route is kept for debugging the insumo.
- Frontend — 🤖 now runs the analysis and renders it in a new `#ai-modal`, following the existing `.modal-overlay`/`.active` + `data-action` strict-CSP pattern.
- Env vars documented in `.env.example`: `AGENTIX_BASE_URL`, `AGENTIX_TENANT_ID`, `AGENTIX_TOKEN` | (`AGENTIX_KEYCLOAK_URL` + `AGENTIX_CLIENT_ID` + `AGENTIX_USERNAME` + `AGENTIX_PASSWORD`), `AGENTIX_ENTITY_TYPE`/`_NAME`/`_VERSION`, `AGENTIX_BUNDLE`, `AGENTIX_TIMEOUT_MS`.

**Known unconfirmed contract:** where the finished answer lives in a v2 session detail. No session has ever run in this tenant, so `extractAnalysis()` tries several plausible shapes in order and throws a clear error if none matches — revalidate against a real session before trusting it.

The three platform blockers (empty `allowed_models`, no published bundle, `platform_admin` required to upload) remain open and have not been revalidated since 2026-08-13. The whole integration is gated behind the env vars, so the dashboard works unchanged without them.

Nota de implementação: `github.js` expõe `getFailureContext(owner, repo, runId, token)` → `{ failedSteps, failedLogs }`, que lê o endpoint de jobs **uma única vez**. É o que a rota de análise usa; `getFailedJobSteps`/`getFailedJobLogs` continuam exportados (a rota antiga de download usa o primeiro), mas chamá-los juntos leria o endpoint duas vezes.

## ✅ 2026-08-19 (mais tarde) — agente publicado em DEV; contrato real capturado e código adaptado

Repo do agente: **`Bradesco-Core/dvop-agx-ssol-changes-observability`** (privado, layout OAF v3: `bundle/PACKAGE.yaml` + `bundle/changes-observability-agent/AGENTS.md`). Lido via `gh api` — não precisa de token da AgentiX.

Publicação confirmada pelo CI (run `32304743282`, sucesso em 2026-08-19T21:36): **bundle `dvop-agx-ssol-changes-observability`, versão `0.1.0`, tenant `dvop` (minúsculo no CI, enquanto `/auth/me` devolvia `DVOP` — testar as duas caixas no header `x-tenant-id`), ambiente DEV**. Não há tag nem release; a promoção para HOM depende da label `release-candidate` no PR e a de PRD foi `skipped`. Ou seja: **existe em DEV, não em HOM/PRD**.

**Contrato real do agente (`changes-observability-agent`, `model: gpt-4o-mini`, `version: 0.1.0`, `temperature: 0.1`, `max_rounds: 2`, `markdown: false`)** — bem diferente do que eu tinha assumido, que usava constants `{{run_url}}`/`{{failed_steps}}`:
- **Entrada**: um objeto JSON com `{ repository, workflow, run_id, status, logs }`. Só `logs` é obrigatório; campos ausentes devem ser **omitidos**, nunca inventados. Não usa `constants` nenhuma.
- **Saída**: **apenas** um objeto JSON `{ status, category, confidence, summary, root_cause, evidence[{line,why}], suggested_actions[], affected_components[] }`. `category` é uma de 10 (`build|test|lint|dependency|permission|configuration|infrastructure|timeout|flaky|unknown`). Sem cercas de código, sem Markdown.
- **O AGENTS.md joga duas responsabilidades no chamador, explicitamente**: (1) **mascarar segredos, tokens, senhas, connection strings, URLs assinadas e dados pessoais antes de enviar** — porque o payload fica persistido na sessão da plataforma e é recuperável por quem tiver acesso; (2) recortar o log ao relevante, porque raw log estoura o contexto.

Código adaptado a isso (125/125 testes, lint limpo, **ainda não commitado**):
- `agentixPayload.js` reescrito: monta o JSON documentado (campos ausentes omitidos), com `maskSecrets()` novo (tokens `gh[pousr]_`/`github_pat_`, JWT, `AKIA`, valores rotulados como `token=`/`api_key=`/`password=`, assinaturas em querystring, credenciais em connection string → `[REDACTED]` preservando o rótulo) e `parseAnalysis()` (recupera o objeto mesmo se o modelo envolver em cerca de código ou texto).
- `github.js`: `getFailureContext()` também devolve `workflow` (vem de `jobs[].workflow_name`, sem chamada extra).
- Rota devolve `{ analysis: <objeto>, raw, sessionId, runId }`; o front renderiza summary / categoria / causa / evidências / próximos passos no modal.
- `.env.example` com os valores reais: `AGENTIX_ENTITY_NAME=changes-observability-agent`, `AGENTIX_BUNDLE=dvop-agx-ssol-changes-observability`, `AGENTIX_ENTITY_VERSION=0.1.0`.

**`allowed_models` continua NÃO verificado** — exige token, e o único caminho automatizável é ROPC com senha pessoal (que não deve passar pelo chat). Script pronto para o usuário rodar localmente: `agentix-check.mjs` (pede usuário/senha no terminal, checa `/auth/me`, `allowed-models` nas três caixas do tenant, `/bundles` e `/bundles/dvop-agx-ssol-changes-observability`). O agente declara `model: gpt-4o-mini` — é esse o modelo que precisa estar em `allowed_models`. **Nota: o scratchpad não sobrevive entre sessões; se precisar de novo, reescrever.**

Rede: `https://agentix.corpti.bradesco.com.br` (DEV) **responde desta máquina** — `GET /v2/api/auth/oidc-config` retornou 200 com `{"enabled":true,"issuer":".../realms/Omega-AGX","client_id":"agx-front","local_login_enabled":false}`. Isso resolve parcialmente o antigo item "confirmar alcance de rede" (falta confirmar a partir do ambiente de produção do dvop-bff, que é outra rede). `local_login_enabled: false` confirma que `POST /auth/login` não é caminho válido — só Keycloak.

### ⚠️ TLS: CA corporativa não está no bundle do Node (2026-08-19)

Descoberto ao rodar o `agentix-check.mjs`: `fetch` do Node falha com **`UNABLE_TO_VERIFY_LEAF_SIGNATURE`** contra `agentix.corpti.bradesco.com.br`. O `curl` funciona porque no Windows usa schannel (keystore do sistema); o Node usa um bundle de CAs próprio, que não tem a CA interna do Bradesco.

Solução local: `node --use-system-ca script.mjs`.

**Consequência para o dvop-bff em produção, não só para o script:** o container Node vai bater no mesmo erro ao chamar a AgentiX. O deployment precisa de `NODE_OPTIONS=--use-system-ca` (Node >= 22.15, e a imagem precisa ter a CA no trust store do SO) **ou** `NODE_EXTRA_CA_CERTS=/caminho/ca-bradesco.pem`. **Nunca** `NODE_TLS_REJECT_UNAUTHORIZED=0` — desliga verificação TLS do processo inteiro. Registrado como aviso no bloco AgentiX do `.env.example`.

### ✅ Verificação ROPC executada pelo usuário (2026-08-19) — bundle publicado, mas `allowed_models` AINDA VAZIO

Saída real do `agentix-check.mjs` (usuário `m538425`, ambiente DEV):

1. **`GET /auth/me` → 200**: `tenant_id: DVOP`, `role: tenant_admin`, `effective_permissions` completo, **`is_platform_admin: false`**. Confirma de novo que upload direto de bundle (que exige `platform_admin`) não é caminho — mas isso deixou de importar, porque o **pipeline do repo do agente publica**.
2. **`GET /tenants/DVOP/allowed-models` → 200, `allowed_models: []`** — **BLOQUEIO CONFIRMADO, AINDA DE PÉ**, seis dias depois da primeira medição (13/08). Não se resolveu sozinho. Nenhum modelo LLM liberado ⇒ nenhuma sessão executa. **É o último bloqueio real; tudo o mais está resolvido.**
3. **Caixa do tenant importa**: `GET /tenants/dvop/allowed-models` → **403 `{"error":"tenant_membership_required","available_tenants":["DVOP"]}`**. Usar sempre **`DVOP` maiúsculo** no header `x-tenant-id`, mesmo o CI do bundle usando `tenant: dvop` como variável.
4. **`GET /bundles` → 200, `total: 4`** (não mais vazio como em 13/08): `dvop-agx-dsot-changevelocity01`, **`dvop-agx-ssol-changes-observability`**, `print-apache`, `sup-encerramento-de-chamados` — todos `source: "upload"`, tenant `DVOP`.
5. **`GET /bundles/dvop-agx-ssol-changes-observability` → 200**. Versão registrada é **`0.1.0.dev2+gdf82879`** (PEP 440 com sufixo de build do git, **não** o `0.1.0` que aparece no output do CI nem no `AGENTS.md`). `runtime.isolated: true`, `execution.mode: worker`, `timeout_seconds: 600`. **Não hardcodar `0.1.0`** — ou usar a string completa, ou deixar `AGENTIX_ENTITY_VERSION` vazio e deixar a plataforma resolver.

**Situação consolidada:** rede OK, TLS resolvido (via `--use-system-ca`/`NODE_EXTRA_CA_CERTS`), auth OK, tenant OK, bundle publicado e visível no registry, código pronto e testado. **Falta só liberar um modelo LLM em `allowed_models` para o tenant `DVOP`** — o agente declara `model: gpt-4o-mini`. Esse é o único pedido que resta fazer ao time da AgentiX (os outros dois pedidos antigos — caminho de publicação e credencial de serviço — foram respectivamente resolvidos pelo pipeline e continuam pendentes só para produção).

### Payload real gerado contra uma execução de verdade (2026-08-19) — e mascaramento de e-mail acrescentado

Gerado com o próprio código do app contra `Bradesco-Core/pdpj-bff-cartoes` run `32291972853` (job `call-build / Scan-ACS-APP`, falha do ACS policy check: 1 vulnerabilidade HIGH → `exit code 1`). Resultado: 1 job com falha, input de ~20k chars, nenhum segredo detectado.

**Lacuna encontrada por esse log real:** ele contém **endereços de e-mail corporativos** (times de CAAS e Cyber que o próprio tooling de policy imprime como contato). O `AGENTS.md` do agente exige mascarar dados pessoais, e o `maskSecrets()` não cobria isso. Acrescentado `EMAIL_PATTERN` → substitui por `[EMAIL]` (8 ocorrências nesse log). 126/126 testes.

**Observação sobre formato de log de esteira corporativa:** o output do ACS é uma tabela ASCII gigante — dos ~20k chars, só ~76 linhas têm conteúdo real; o resto é padding de `|` e espaços. Considerar (não implementado, é decisão em aberto) colapsar runs de espaços nas tabelas antes de enviar, para reduzir custo de token. Risco: mangelaria indentação de stack trace, então não fazer isso de forma cega no log inteiro.

### ⚠️ CORREÇÃO IMPORTANTE (2026-08-19): `allowed_models` vazio NÃO impede execução

O usuário rodou o agente pela ferramenta e **a execução usou `gpt-4o-mini` sem problema**, mesmo com `GET /tenants/DVOP/allowed-models` devolvendo `allowed_models: []`. Além disso, a UI não expõe nada relacionado a allowed_models.

**Conclusão: `allowed_models` NÃO é o portão de execução que se supunha desde 13/08.** Aquele endpoint aparentemente reflete uma lista de restrição opcional (vazia = sem restrição), não uma allowlist obrigatória. Toda a priorização anterior — que tratava isso como "o único bloqueio duro" e como o pedido nº 1 ao time da AgentiX — **estava errada e não deve ser repetida**. Não pedir liberação de modelo ao time da AgentiX com base nisso.

**Não sobra bloqueio de plataforma conhecido.** O que resta é decisão nossa: credencial de serviço para produção (hoje só ROPC com senha pessoal), promoção do bundle de DEV para HOM/PRD (label `release-candidate` no PR), e a CA corporativa no container.

### Limites de log revistos com base em medição real (2026-08-19)

Tamanhos reais medidos em `Bradesco-Core/pdpj-bff-cartoes` run `32291972853`: job de scan que falhou = **40 KB / 322 linhas**; job de build = **664 KB / 6.783 linhas**; outro scan = 37 KB. Ou seja: o log típico cabe inteiro, mas o de build não cabe em contexto nenhum — teto continua necessário, só que generoso.

**Bug conceitual corrigido:** o corte anterior mantinha só o *final* do log, o que **contradiz a instrução nº 1 do agente** ("localize a **primeira** falha real na ordem cronológica; erros posteriores costumam ser consequência dela"). Numa falha de teste/compilação a primeira falha está no meio, e o fim traz só o resumo do runner — a estratégia antiga escondia exatamente o que o agente procura. Passou despercebido porque no exemplo do ACS os erros calham de estar no fim.

Novo comportamento de `trimLogTail(text, maxChars)` (assinatura mudou: não recebe mais `maxLines`):
- Cabe no orçamento → devolve **inteiro**, sem marcador.
- Não cabe → ancora na **primeira** linha que casa `ERROR_MARKERS` (`##[error]`, `ERROR`, `ERR!`, `FAIL/FAILED/FAILURE`, `Exception`, `Traceback`, `exit code`, `fatal`), mantendo 40 linhas de contexto antes dela.
- Nem a partir do erro cabe → metade do orçamento no começo da falha + metade no fim (resumo do runner), com `[... trecho do log omitido ...]` marcando cada corte.
- Sem marcador de erro reconhecível → cai para o final (melhor palpite restante).

Novos tetos: **60 KB por job** (era 20 KB / 200 linhas) em `github.js`; **120 KB no payload inteiro** (era 45 KB) em `agentixPayload.js`.

Validado contra os logs reais: o job de 40 KB agora vai **inteiro** (30.424 chars após remover timestamps e linhas em branco, sem truncamento); o de 664 KB reduz para 60 KB com 2 marcadores de omissão. 130/130 testes.

### 🔑 Sessão v2 REAL capturada (2026-08-19) — dois achados que quebravam a integração

O usuário rodou o agente pela ferramenta com o payload gerado e **a resposta foi boa**. A sessão ficou registrada e foi baixada via ROPC (`GET /sessions/{id}`). Shape real de uma sessão concluída:

```
session_id, tenant_id, entity_type: "AGENT", entity_name: "changes-observability-agent",
entity_version: "0.1.0", bundle_name: "dvop-agx-ssol-changes-observability",
bundle_version: "0.1.0.dev2+g47231a1", bundle_content_hash: "sha256:...",
state: "DONE", created_at, updated_at, partial_output: null, error_message: null,
stages: [], token_usage: null, triggered_by: "m538425", feedback, feedback_note, feedback_at
```

**Achado 1 — o estado vem em `state`, NÃO em `status`.** O `POST /sessions/invoke` responde `status`, mas o detalhe da sessão usa `state`. O cliente fazia polling em `session.status`, que vinha `undefined` ⇒ nunca casava com os estados de execução ⇒ **toda sessão seria tratada como concluída no primeiro poll**. Corrigido com `sessionState()` lendo os dois. Também: o erro vem em **`error_message`**, não `error`.

**Achado 2 — a sessão concluída NÃO traz a saída.** `partial_output: null`, `stages: []`, `token_usage: null`, e nenhum campo `result`/`output`/`messages`. **O texto da resposta não está em `GET /sessions/{id}`.** Isso invalida a premissa do desenho atual (polling em vez de SSE): o polling dá o estado, mas não o resultado. Onde a saída vive ainda é desconhecido — script `agentix-output-probe.mjs` (scratchpad) sonda `/output`, `/result`, `/messages`, `/artifacts`, `/logs`, `/events`, `/stages`, `/conversation`, `/history`, `?include=output`, `/full` e o SSE `/sessions/{id}/stream`. **Este é o próximo passo bloqueante do lado do código.** Suspeita principal: só o SSE entrega, como no plugin oficial — e aí é preciso descobrir se ele reproduz o histórico de uma sessão já encerrada ou se é preciso conectar antes/durante.

Confirmado também: **`entity_version` é `0.1.0`** (a versão do agente), separada de `bundle_version` (`0.1.0.dev2+g...`). Então `AGENTIX_ENTITY_VERSION=0.1.0` está certo — não usar a string do bundle ali.

### ✅ RESOLVIDO — onde vive a saída de uma sessão v2 (sondagem, 2026-08-19)

Sondados 11 endpoints + SSE contra a sessão `61897eb7-...`. Resultado (404 nos demais):

| endpoint | status | conteúdo |
|---|---|---|
| `/sessions/{id}/artifacts` | 200 | **6 KB** — `{ partial_output, files, event_outputs }`. `partial_output` é **a resposta já parseada como objeto**. ✅ **usar este** |
| `/sessions/{id}/messages` | 200 | 40 KB — array `[{role, content, tool_calls, tool_call_id, tool_name, run_id, created_at}]` com `system`/`user`/`assistant`; `assistant.content` é o mesmo JSON como string. Fallback (grande porque ecoa o prompt inteiro de volta) |
| `/sessions/{id}/conversation` | 200 | 40 KB — `[{entry_id, author, log, agent_id, ordinal}]`, formato diferente, não usado |
| `/sessions/{id}/events` | 200 | 384 KB — telemetria de execução, não a resposta |
| `/sessions/{id}/stream` | 200 | SSE `text/event-stream` — **reproduz o histórico de sessão já encerrada** (`ExecutionDequeued`, `execution_dispatched`, com `pod_name`, `namespace`...). Funciona, mas é caro e desnecessário |
| `/output`, `/result`, `/logs`, `/stages`, `/history`, `/full` | 404 | não existem |

`?include=output` no detalhe é ignorado (mesmo corpo de sempre).

**Implementado:** `getSessionArtifacts()`, `getSessionMessages()` e `fetchAnalysis(sessionId)` (tenta `/artifacts.partial_output`, cai para o último turno `assistant` de `/messages`, devolve null se nenhum tiver). `analyzeFailure()` passou a chamar `fetchAnalysis` depois do polling. `extractAnalysis()` **foi removido** — era o palpite que essa sondagem tornou desnecessário. `parseAnalysis()` agora aceita objeto **ou** string. 132/132 testes, lint limpo.

**Validação do trimming pela resposta real do agente:** com o log inteiro, ele classificou `category: "permission"` e apontou como causa primária a **negação de permissão no Azure Key Vault** (`secrets get` em `kvazuhobraplattecgit001`), tratando a violação de policy do ACS como falha *posterior*. Ou seja, o corte antigo (só o final) teria escondido a causa real e levado a um diagnóstico errado — a mudança para ancorar na primeira falha se provou necessária num caso concreto.

### 🔑 Contrato do `POST /sessions/invoke` — resolvido empiricamente (2026-08-19)

Primeira chamada real da aplicação deu **422 `{"detail":"Bundle 'dvop-agx-ssol-changes-observability' not found"}`**, mesmo com o bundle publicado e listado em `/bundles`. Sondagem de 6 combinações de corpo esclareceu:

| corpo | resultado |
|---|---|
| sem `bundle` | 422 `[{loc:["body","bundle"], msg:"Field required"}]` — **`bundle` é obrigatório** |
| `bundle`, sem `version` | ✅ **201** |
| `bundle` + `entity_version: "0.1.0"`, sem `version` | ✅ **201** |
| `bundle` + `version: "0.1.0"` (versão do agente) | ❌ 422 `Bundle not found` |
| `bundle` + `version` real do bundle (`0.1.0.dev2+ge6e81a9`) | ❌ **409** `Execution blocked: bundle ... is not fully approved. Pending or disabled components:` |
| `bundle_name` no lugar de `bundle` | 422 `Field required` — o nome do campo é `bundle` mesmo |

**Regra:** o `version` de topo é a versão **DO BUNDLE**, não do agente — e **não deve ser enviado**. Enviar a versão do agente ali dá "Bundle not found"; enviar a versão real do bundle dispara o gate de aprovação do registry e dá 409. Omitindo, a plataforma resolve o build corrente. Isso também sobrevive ao CI, que reconstrói o bundle com novo sufixo a cada merge (visto `gdf82879` → `g47231a1` → `ge6e81a9` em poucas horas). `entity_version` (versão do agente, `0.1.0`) é seguro e opcional.

**Atenção para o futuro:** o 409 revela que existe um gate de aprovação por versão no registry e que a versão corrente do bundle **não está totalmente aprovada** ("Pending or disabled components"). Hoje isso não bloqueia porque não mandamos `version`, mas se a plataforma passar a exigir versão explícita, esse gate volta.

Também implementado: `apiErrorMessage()` — o axios só diz "Request failed with status code NNN", e o detalhe acionável está no corpo (`detail` string ou array de validação do FastAPI). Agora a mensagem que chega na tela é o texto real da API.

**Isolamento de teste:** criar um `.env` local com `AGENTIX_*` quebrou o teste que espera 503 (integração não configurada) — a suíte estava lendo o `.env` do desenvolvedor. Corrigido em `src/config/env.js`: `dotenv.config()` só roda quando `NODE_ENV !== 'test'`. 135/135.
