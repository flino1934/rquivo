# AgentiX API — confirmed contracts (v1 GraphQL and v2 REST)

Source of truth for this file: reverse-engineered from the official AgentiX VS Code plugin (`bradesco.agentix-plugin-1.0.9`, repo `Bradesco-Core/dvop-cmn-agx-engpdp-plugin`) source code and its internal ADR (`docs/runner/platform-api-reference.md`, JIRA ENGPBIA-6053), plus live debug-log capture and a working end-to-end test. The 9 conceptual PDFs from the AgentiX team describe a simplified/aspirational v2 REST model that diverges from what the plugin actually calls in several places — treat the plugin's real code as authoritative over the PDFs.

**Revalidated against plugin 1.0.10 (2026-08-19)** — the installed extension lives at `~/.vscode/extensions/bradesco.agentix-plugin-1.0.10/` and ships as a full source checkout (`src/`, `docs/`, tests), not a packed build, so it can be read directly. Every auth/API contract below was re-confirmed; 1.0.9 → 1.0.10 changed no contract at all (only two new files, `V2WorkspaceFileWriter.ts` and `v2WorkspaceStructure.ts`; `apiAdapter.ts`, `endpointResolver.ts`, `auth/constants.ts`, `config/environment.ts` and `AuthManager.ts` differ only in line endings).

## v1 GraphQL (legacy) — PROVEN WORKING END-TO-END (2026-08-07)

Use this path unless a service credential for v2 becomes available.

### Environments — four, not three

`config/environment.ts` defines `dev | lab | hml | prod`, selected at build time via `AGENTIX_ENVIRONMENT` (default `dev`), overridable per-URL by `AGENTIX_V1_BASE_URL` / `AGENTIX_V2_BASE_URL` / `AGENTIX_V2_KEYCLOAK_BASE_URL`. **`lab` sits on a completely different host** — easy to miss:

| env | v1 Keycloak | v1 base |
|---|---|---|
| dev | `https://agentix.corpti.bradesco.com.br:444` | `https://agentix.corpti.bradesco.com.br` |
| lab | `https://devopsadmin.bradesco.com.br:8446` | `https://devopsadmin.bradesco.com.br:8445/` |
| hml | `https://agentixcp.prebanco.com.br:444` | `https://agentixcp.prebanco.com.br` |
| prod | `https://agentix.bradesco.com.br:444` | `https://agentix.bradesco.com.br` |

v2 base is always `{v1 base}/v2/api` with Keycloak realm `Omega-AGX` (v1 uses realm `master`). All testing so far has been against **dev** — these are the URLs a BFF integration will need on promotion.

### Auth

Resource Owner Password Credentials grant:
```
POST https://agentix.corpti.bradesco.com.br:444/realms/master/protocol/openid-connect/token
grant_type: password
client_id: legacyx
username / password: <personal credentials — not yet a service account>
```
Returns a Bearer access token.

### Tenant discovery

```
POST https://agentix.corpti.bradesco.com.br/orchestrator/auth/tenant-mapping
Authorization: Bearer <token>
```
Maps the user's Keycloak group (e.g. `brad-legacyx-dvop-editor`) to a `tenant_id`. Confirmed dvop team tenant: `tenant_id: 9106a80c-dc62-535a-a3d8-c71dddc6eb22`.

Full response shape (`platformService.ts::TenantMappingResponse`):
```ts
{
  success: boolean;                        // false ⇒ treat as failure even on HTTP 200
  is_multi_tenant: boolean;
  group_mappings: Record<string, string>;  // keycloak group key → tenant_id
  available_tenants: string[];
  selected_tenant: string;                 // ← the server already resolves the preferred tenant
  default_tenant_available: boolean;
}
```
**Use `selected_tenant` directly** — deriving the tenant from `group_mappings` is only the fallback path. When several group keys map to the same `tenant_id`, the plugin keeps the highest-privilege name using priority `viewer(0) < editor(1) < admin(2)`; the display name is the group key with prefix `brad-legacyx-` stripped and the trailing role segment removed. The plugin caches tenants and bundles for 5 minutes (TTL), invalidating on API-version switch or bundle upload.

### GraphQL endpoint

```
POST https://agentix.corpti.bradesco.com.br/graphql/
Authorization: Bearer <token>
x-lx-tenant: <tenant_id>
```

Key queries/mutations:

- `listGroups(bundle)` — list executable groups (≈ workflows) in a bundle.
- `listAgents(bundle, squadId)` / `getAgent(id)` — **must pass `squadId` explicitly (even `null`)** — the resolver requires the arg present or it throws `resolve_lidst_agents() missing 1 required positional argument: 'squadId'`. Query needs `squadId: $squadId` with `squadId: null` in variables if not filtering.
- `isAgentValid(id)` / `runnable(input)` — pre-execution validation.
- `invoke(input: InvokeInput!)` — triggers execution asynchronously, returns `sessionId`. Shape:
  ```graphql
  input: {
    entityId
    type        # GROUP | TRANSFORMER | FLOW | TOOL
    name
    version
    bundleName
    bundleVersion
    tenantId
    payload:   [{key, value}]   # ARRAY of {key,value} pairs, not a plain object
    constants: [{key, value}]   # same — array of {key,value}, and this is where {{variaveis}} used in goal.yaml resolve from
  }
  ```
  Defaults the plugin applies when the caller omits them: `entityId` falls back to `entityName`, and `description` falls back to `` `Flow - ${entityName}` ``. Selected response fields: `sessionId tenantId bundleName bundleVersion entityType entityName entityVersion payload constants`.
- `session(input: {sessionId})` — poll execution state: `CREATED|PENDING|RUNNING|DONE|FAILED|CANCELLED`. Recommended polling backoff (from internal ADR): 2s for the first 10s, 5s up to 60s, 10s after that.

  ⚠️ **Do not copy the plugin here.** `apiAdapter.ts::getSessionStatus` builds its v1 branch as `session(id: $sessionId) { id status createdAt error }` — a different argument shape from the `session(input: { sessionId })` proven live. The plugin's own comment gives it away (`// v1: Use GraphQL fallback or HTTP GET (depending on existing implementation) / For now, assume GraphQL availability`): it is unexercised dead code, because the plugin's Runner is v2-only. The live-tested `input:` form in this document wins.
- `conversationLogs(input: ConversationLogsInput!)` — **THE REAL RESULT SOURCE.** `session.result` is always `null`, even on `state: DONE` with real cost captured — do not rely on it; this was verified minutes after completion, not a consistency-lag issue. Query:
  ```graphql
  query GetConversationLogs($input: ConversationLogsInput!) {
    conversationLogs(input: $input) {
      sessionId
      ordinal        # timestamp string — sort by this
      author         # "session/<id>" | "user" | "default" | agent name (e.g. "orquestrador")
      log
      promptTokens
      completionTokens
    }
  }
  ```
  variables: `{ input: { sessionId } }`.

  **No reference implementation exists for this.** `conversationLogs` appears nowhere in the plugin's `src/extension` (searched in 1.0.10) — the plugin's Runner follows v2 sessions over SSE (`/sessions/{id}/stream`) and never reads a v1 result. The extraction algorithm below comes purely from live testing, so there is no vendor code to check it against.
- `notifications` — GraphQL subscription over WebSocket, alternative to polling.
- Other useful introspected fields on Query: `questionsBySession`, `events` (EventPage — relevant for future HITL support), `sessionFiles`, `costCaptureAgents`, `sessionCount`, `sessions` (paginated).

REST complements (not GraphQL): `GET /sessions/{sessionId}/logs/download` (zip), `GET /metadata/variables`.

Bundle transfer on v1 is REST too (`auth/constants.ts`):
- `POST {base}/orchestrator/lxzupload/raw` — upload a bundle. ⚠️ **Not an available path in practice — see "Bundle upload is not self-service" below.**
- `GET {base}/orchestrator/lxzdownload` — download a bundle.
- After an upload the plugin waits `BUNDLE_PROCESSING_DELAY_MS = 5_000` before the bundle is usable — the platform needs ~5s to process it. Expect the same lag in any automated publish flow.

Also in that file: `PLATFORM_SESSIONS_URL = {base}/v2/sessions` (the web UI page for a session — useful to deep-link a user to an execution) and `TOKEN_EXPIRY_BUFFER_SECONDS = 60`.

### Client-side patterns worth reusing in a backend

From `auth/apiClient.ts` — both are directly applicable to the dvop-bff integration:

- **TLS is explicit**: every request goes through `new undici.Agent({ connect: { rejectUnauthorized } })`, with the flag coming from a `TLSValidator` config rather than a global `NODE_TLS_REJECT_UNAUTHORIZED`. Worth mirroring — it keeps corporate-CA handling scoped to AgentiX calls instead of disabling verification process-wide (which matters for the Fortify Insecure Transport findings).
- **Single-flight token refresh**: on HTTP 401 the client refreshes once (`grant_type: refresh_token`) and retries the request; concurrent 401s share one in-flight promise (`_refreshPromise`) so a burst of parallel calls triggers a single refresh.

Known bug in the plugin — do not copy the signature: v1 calls pass `gqlRequest(query, vars, { tenantId, ...authHeaders } as any)`, but `GqlRequestOptions` only reads `tenantId` and `headers`, so explicitly-supplied auth headers are silently dropped. It works only because `apiClient` injects the Bearer itself.

### Result-extraction algorithm

1. Fetch `conversationLogs` for the session, sort by `ordinal`.
2. Walk backward from the end.
3. Find the last entry whose `author` is a real agent name (not `session/...`, not `default`, not `user`) whose `log` contains a valid JSON block appearing before a `TERMINATE` line.
4. That JSON is the final result. In the tested bundle, this was the leader agent's (`orquestrador`) closing message, which echoed the specialist agent's (`escrevente`) output.

### Bundle structure on disk (for reference / building a new bundle)

```
components/
  manifest.yaml
  goals/<goal-name>/<version>/goal.yaml       # objective, business rules, {{variaveis}}, startpoint
  groups/<group-name>/<version>/group.yaml    # ties goal_ref + squads, model, max_rounds, planner_guidance
  squads/<squad-name>/<version>/squad.yaml    # list of agents (guidance, role, talk_with, tools, leader)
  flows/<flow-name>/<version>/flow.yaml       # stages — sequence of groups/squads to trigger
  tools/                                       # optional custom Python tools
  transformers/                                # optional data transformers
```
Based on the official template `Bradesco-Core/agx-template`. The README in a cloned bundle repo is generic boilerplate — always read the actual YAMLs under `components/`, not the README, to know what a bundle really does.

### Verified test bundle

`dvop-agx-ssol-triagem` (repo `Bradesco-Core/dvop-agx-ssol-triagem`, bundle `0.1.0-dev`, group `triagem-group` id `ca22f04c-ea01-5829-9c8a-bf039c57fd86` version `1.0.0` — note bundle version ≠ group version). 4-agent conversational squad (Orquestrador, Triagem, Confiança, Escrevente), zero tools/code execution — safe to invoke repeatedly. Takes `{{descrição}}` (with accent — must go in `constants`) and returns `{time_resposavel, tipo_solicitacao, descricao_melhorada}`.

Real successful invocation: session `a3f25f69-dffa-4a1e-b3ad-7f3df6ca0b89`, `state: DONE`, ~20.3k prompt tokens / 873 completion tokens, ~22s wall time.

## v2 REST — live but currently blocked for this use case

Base URL: `https://agentix.corpti.bradesco.com.br/v2/api` (varies by `AGENTIX_ENVIRONMENT`: dev/hml/prod).

Auth, three modes now confirmed:
- `login`: `POST {base}/auth/login` with `{username, password}` → `{api_key, ...}`, subsequent calls use header `x-api-key`. In practice this endpoint 404'd in testing — likely not actually available to end users in this environment.
- `keycloak` (what the plugin uses): OIDC Authorization Code Flow + PKCE via browser (Keycloak base `https://agentix.corpti.bradesco.com.br:444/`, realm `Omega-AGX`, client `agx-front`). Header `Authorization: Bearer <token>`. **Confirmed working** live via the plugin's debug logs. Inherently interactive (human must click through a browser) — **cannot be automated in an unattended backend** on its own.
- **ROPC (Resource Owner Password Credentials) — confirmed working 2026-08-13, undocumented but real:** `POST https://agentix.corpti.bradesco.com.br:444/realms/Omega-AGX/protocol/openid-connect/token` with `grant_type=password&client_id=agx-front&username=...&password=...&scope=openid profile email` returns a valid access token, exchangeable for full v2 API access. This is the same `agx-front` client the browser flow uses — Keycloak evidently has Direct Access Grants enabled on it. **This is the strongest lead so far for an automatable v2 credential** — still a personal username/password in testing, but proves the grant type is enabled; worth asking the AgentiX team for a dedicated service account using this same client/grant instead of a personal one.

Every v2 request also needs header `x-tenant-id`.

### Confirmed via ROPC test (2026-08-13), tenant `DVOP`

- `GET /auth/me` → `{tenant_id: "DVOP", role: "tenant_admin", effective_permissions: [admin, editor, tenant_admin, tenant_developer, tenant_executor, tenant_user, tenant_viewer, viewer], ...}` — full admin control of this tenant confirmed.
- `GET /tenants/{tenantId}/agents` → **404 "Not Found"**. This endpoint, taken from the plugin's `endpointResolver.ts`, does not actually exist server-side (or its real path differs) — a confirmed divergence between the plugin's code and the live API.
- `GET /bundles` → 200, **empty** (`total: 0`). No bundle is published in tenant `DVOP` yet — nothing to reuse, a new one must be authored from scratch.
- `GET /tenants/{tenantId}/allowed-models` → 200, **`allowed_models: []` — confirmed empty, not a logging artifact.** Even with full tenant-admin rights, no LLM model is allowed for this tenant, which blocks running any Agent until this is fixed platform-side. **This is currently the single most blocking item** for any v2 execution — more urgent than authoring a bundle, since a bundle is useless without an allowed model.
- `GET /tools?limit=500&offset=0` → 200, 8 built-in tenant-agnostic tools (`bundle: null`, `source: "builtin"`) with full arg schemas: `http_request`, `json_extract`, `list_files`, `read_file`, `write_file` (tenant-scoped file store), `regex_extract`, `template_render` (Jinja2), `text_summarize`. Useful reference when designing a future Agent's tool usage.

Execution (`apiAdapter.ts::invokeFlow`) — diverges from the PDFs, which imply separate `/agents/{name}/run` etc. endpoints that do not actually exist in the plugin code. Real call is always:
```
POST {base}/sessions/invoke
{
  "entity_type": "agent" | "team" | "workflow",
  "entity_name": "...",
  "entity_version": "...",
  "entity_id": "...",       // optional
  "version": "...",         // same as entity_version
  "bundle": "...",
  "payload": { "input": "..." },   // workflow requires "prompt" instead of "input"
  "constants": { ... }             // plain object here, unlike v1's array-of-{key,value}
}
```
Response: `{ session_id, status, component, tenant_id }`.

Other real v2 endpoints (`endpointResolver.ts::buildV2Endpoints`):
- `GET {base}/sessions/{session_id}/stream` (SSE — primary way to follow a session)
- `GET {base}/sessions/{session_id}` (detail) / `GET {base}/sessions/` (list)
- `POST {base}/sessions/{session_id}/cancel` — abort a running session.
- `POST {base}/sessions/{session_id}/feedback` — human feedback on a finished session: `{ feedback: "positive" | "negative", feedback_note?: string }`.
- `GET {base}/auth/oidc-config` — OIDC discovery for the browser login flow.
- `GET {base}/bundles` / `POST {base}/bundles/ingest?auto_convert=false&force=false` / `GET {base}/bundles/{name}/export/archive` (download adds `?version=<v>`)
- `GET {base}/tenants/{tenantId}/agents`
- **Tenant resolution on v2 is just `GET {base}/auth/me`** — `endpointResolver` maps `tenantMappingEndpoint` straight to it; there is no v2 equivalent of the v1 `/orchestrator/auth/tenant-mapping`.
- Bundle registry status (`RunnerExecutionService.ts`) gates execution with states `approved | reject | pending_review | not_found | version_not_found`, plus a version-fallback step when the requested version does not match exactly. The bundle must reach `approved` before the Runner will execute it — a **review** gate that is separate from the role check. Note the two failure paths produce different messages: the registry rejection says `Bundle rejeitado pela plataforma.`, whereas the role check reads `You do not have permission to run Runner for this tenant…` (see the unresolved permission gap below — that one came from the role check, not from the registry).

Note that `buildV2Endpoints` sets its `graphql` field to the `/sessions/invoke` URL with an explicit comment that **v2 exposes no GraphQL at all** — the field only exists to satisfy a shared interface. Do not read it as a v2 GraphQL endpoint.
- `GET {base}/auth/me` — the account tested here (`m538425`) authenticated successfully but got no `tenant_id` back, blocking `getTenants` — likely an incomplete "Habilitação AgentiX" onboarding step (cost-center/Jira-project/access-manager linkage), not resolved as of last check.

Session states in v2: `CREATED → RUNNING → (DONE | FAILED | AWAITING)`. `AWAITING` = paused for HITL.

## Real v2 bundle schema, confirmed by exporting an actual bundle from the extension's builder UI (2026-08-13)

This supersedes the generic OAF description from the conceptual PDFs — that description was accurate in spirit but the real generated files differ in structure and field names. Built via the extension's visual wizard (sidebar stages: Workflow → Agents → Review; "Tools" checkboxes come straight from the confirmed `/v2/api/tools` builtin list, NOT a `skills:` catalog like `http-client`/`github`), then exported/imported as a zip containing exactly three files:

**`manifest.yaml`** (far simpler than assumed):
```yaml
manifest_version: "3.0"
name: "changes-observability"
version: 1.0.0
kind: bundle
```

**`AGENTS.md`** — TWO YAML frontmatter blocks concatenated in one file (not one): first a `kind: workflow` block, then a `kind: agent` block, then a Markdown body with a `# Instructions` section and one `##`-level subsection per agent:
```yaml
---
name: <workflow-name>
kind: workflow
version: 1.0.0
description: "..."
entrypoint:
  step: <agent-name>
steps:
  - name: <agent-name>
    agent: <agent-name>
---

---
name: <agent-name>
kind: agent
version: "1.0.0"
description: "..."
model: "gpt-5.4"          # auto-filled by the builder even with allowed_models empty — likely a placeholder, unverified as actually runnable
temperature: 0.2
max_tokens: 8192
hitl: false                # UI checkbox "HITL (Human in the Loop)"
expected_output: "..."     # UI field "Expected Output"
max_rounds: 10              # UI field "Max Rounds"
tools:                      # UI field "Tools" — checkboxes from GET /tools (builtin list)
  - text_summarize
markdown: false
show_tool_calls: false
harnessConfig:
  agentix-agx:
    streaming: true
    execution:
      mode: worker
      timeout_seconds: 120
---

# Instructions

## <agent-name>

<the instructions text typed in the UI>
```

**`SKILL.md`** — a new, previously-undocumented artifact the builder also generates, describing the same agent as a reusable Skill:
```yaml
---
name: <agent-name>
description: <same as agent description>
license: MIT
metadata:
  author: <username>
  version: 1.0.0
allowed-tools:
  - text_summarize
---
```

Practical notes:
- The UI enforces "at least one tool or skill must be selected" before letting you proceed past the Agents stage.
- No `Rules`/`Profile`/`Error Handling` sections like the PDFs described — the UI collapses those concerns into `expected_output` and the free-text instructions body.
- Exporting from the UI writes the zip to wherever you point the export dialog — it does NOT know about the working directory being a git repo; move it out before committing anything.

## Runner permission gap (2026-08-13, unresolved)

Trying to run this bundle via the extension's **Runner** tab (`Send Bundle` / `Start Execution`) returned: `Bundle status: Rejected — "You do not have permission to run Runner for this tenant. Verify that the tenant has one of the allowed roles: platform_admin, platform_viewer, tenant_admin, tenant_developer, or tenant_executor."` — despite `/auth/me` (same day, via ROPC) confirming `role: tenant_admin` with every one of those roles present in `effective_permissions`.

**Narrowed down 2026-08-19 by reading `RunnerExecutionService.ts` (1.0.10): that message is generated client-side by the plugin, not returned by the server.** The class holds a hardcoded `RUNNER_ALLOWED_ROLES = {platform_admin, platform_viewer, tenant_admin, tenant_developer, admin, editor, tenant_executor}` and formats the text in `_getPermissionMessage(role)` from a **single `role` string**, not from the `effective_permissions` array. Since `tenant_admin` is in that set, the block implies the plugin read some *other* value into `role` — its `V2MeContext` type allows both a top-level `role` and a nested `permissions.role`, so a mismatch between the two (or a stale/empty webview session) is the likely cause. Practical consequences:

- This is a **plugin-side gate, not a platform denial** — a backend integration calling `/sessions/invoke` directly is not subject to it at all.
- The AgentiX team question should therefore be about the empty `allowed_models` (a real platform block), not about this message.
- Separately: bundle **upload** via the Runner is restricted to `global_admin` only, per the same file — consistent with the policy below.

## Bundle upload is not self-service (told to the user, 2026-08-19)

**Uploading a bundle straight from the VS Code plugin is not permitted.** The user was informed of this by the AgentiX side; treat it as policy, not as a bug to work around. It corroborates what the code already hints at — the Runner gates upload behind `global_admin`, and the plugin waits on a registry review (`pending_review` → `approved | reject`) before anything can execute.

Consequences:
- Do not propose `POST /orchestrator/lxzupload/raw` (v1), `POST /bundles/ingest` (v2), or the plugin's "Send Bundle" button as the way to publish a bundle.
- The plugin's export function is still fine — it produces the bundle zip locally. Only the *upload* leg is blocked.

**Open question — the sanctioned publish path was not stated.** Most likely it runs through the governance flow already described in the onboarding material (a corporate GitHub repo created via form, plus a pipeline, plus the approval screen), which would make publishing a commit-and-pipeline operation rather than an API call. That is an inference, not confirmed — ask before building anything that depends on it.

## Bottom line for building a real integration

1. Prefer v1 GraphQL — it's proven and the calling account already has a working tenant there.
2. Whatever path is used, production needs a service credential (client_credentials or equivalent) — testing so far has only used a personal username/password, which is not appropriate to hardcode into a backend service.
3. Always pull results from `conversationLogs` (v1) — never trust `session.result`.

## 📖 OpenAPI completo exposto (descoberto 2026-08-19) — pare de adivinhar endpoints

**`GET {v2 base}/openapi.json` responde 200 com o spec inteiro: 212 rotas.** Requer apenas o bearer token normal. Isso torna obsoleta qualquer sondagem às cegas de endpoint v2 — **sempre consultar o spec primeiro**. (Também existem `/docs` e `/redoc`.)

### File store do tenant (o "sistema de arquivos" da AgentiX)

Duas faces, com contratos independentes:

**1. Lado do agente — tools nativas** (`GET /tools`, `source: builtin`), usadas *durante* a execução, com caminhos relativos à raiz do tenant:
- `list_files({ prefix?, tenant_id?, max_keys? })` — "List files in the tenant file store under a given path prefix", ex. `output/`
- `read_file({ path, tenant_id? })` — ex. `output/report.md`
- `write_file({ path, content, tenant_id? })` — conteúdo UTF-8
- `tenant_id` é opcional: sem ele, usa `AGENTIX_TENANT_ID`/`TENANT_ID` do runtime.

**⚠️ A tool só existe para o agente se estiver declarada em `tools:` no frontmatter do `AGENTS.md` dele.** O `changes-observability-agent` **não declara `tools:` nenhuma**, então hoje ele não consegue ler arquivo algum — usar o file store exigiria alterar e republicar o agente.

**2. Lado da aplicação — REST** (`/files`):

| método | rota | observação |
|---|---|---|
| POST | `/files` | multipart: `file` (obrigatório), `parent_id`, `origin` (`user`\|`agent`), `session_id`, `bundle_name`. **Sobe para QUARENTENA** |
| POST | `/files/{id}/approve` | "promotes it into approved tenant context" — **necessário antes do arquivo virar contexto utilizável** |
| POST | `/files/{id}/reject` | fica em disco para auditoria |
| GET | `/files` | filtros: `parent_id`, `rag_status`, `is_folder`, `search`, `origin`, `session_id`, `bundle_name`, `status`, `page`, `page_size` |
| GET | `/files/{id}` · `/download` · `/stream` | download devolve URL temporária (`expires_in`) |
| POST | `/files/folder` | pasta virtual (só no banco) |
| DELETE | `/files/{id}` | remove de storage + projeção + banco |
| POST/DELETE | `/files/{id}/rag` | indexação para RAG (`rag_status`, `chunk_count`, `embedding_model`) |
| PUT | `/files/{id}/availability` | flags `rag_enabled`/`context_enabled`/`download_enabled` (tenant_admin+) |
| POST | `/files/register` · `/sync` · `/reconcile-input-projections` · `/batch-download` | operacional |

Campos de um item: `file_id, tenant_id, parent_id, name, path, mime_type, size_bytes, s3_key, is_folder, rag_enabled, context_enabled, download_enabled, rag_status, chunk_count, embedding_model, origin, session_id, bundle_name, status, reviewed_by, reviewed_at, reject_reason, detected_mime, analysis_json, created_by, created_at, updated_at`.

**Árvore padrão já existente no tenant `DVOP`** (8 pastas, `status: approved`, nenhum arquivo): `/artifacts/`, `/input/`, `/knowledge/`, `/output/`, `/sessions/`, `/staging/`, `/suporte/`, `/uploads/`.

**Consequência prática:** upload pela aplicação **não é um passo só** — cai em quarentena e precisa de `approve` (que o papel `tenant_admin` pode fazer). Para um fluxo por clique, são 2 chamadas extras + mudança no agente. Só compensa quando o insumo não couber no prompt ou quando se quiser trilha de auditoria do que foi enviado.

### RAG — superfície real da API (2026-08-19)

Só existem **três** rotas de RAG, e nenhuma delas é de consulta:

| método | rota | o que faz |
|---|---|---|
| POST | `/files/{file_id}/rag?embedding_model=...` | "Mark a file for RAG indexing and trigger **async** background indexing" → `RagToggleResult { file_id, rag_enabled, rag_status }` |
| DELETE | `/files/{file_id}/rag` | remove a indexação |
| GET | `/sessions/{session_id}/knowledge` | **telemetria pós-execução**: `KnowledgeRetrieval { id, query, agent_name, documents_found, search_type (default "vector"), score, timestamp }` |

**Não há endpoint de busca/consulta ao índice.** A recuperação acontece *dentro* da execução do agente; de fora só se observa que ela ocorreu, via `/sessions/{id}/knowledge`. Também **não existe tool `knowledge`/`search` na lista builtin** (`http_request, json_extract, list_files, read_file, regex_extract, template_render, text_summarize, write_file`) — ou seja, a injeção de contexto parece ser implícita, feita pela plataforma a partir dos arquivos do tenant com `rag_enabled`. **Isso não foi confirmado** — nenhum agente com RAG foi executado ainda.

Estado por arquivo: `rag_enabled`, `rag_status`, `chunk_count`, `embedding_model`, `context_enabled` (este último alternável em `PUT /files/{id}/availability`, tenant_admin+).

**`rag` é feature flag** (`FeatureFlags.rag`, default `true` no schema). `GET /admin/feature-flags` exige **`platform_admin`** — com `tenant_admin` dá 403, então não dá para confirmar o valor efetivo nesta instância.

Não descobri quais `embedding_model` são aceitos: `/models` dá 404 e `allowed-models` do tenant continua `[]`.

### 🔓 A quarentena de upload pode ser desligada por tenant

`PATCH /admin/tenants/{tenant_id}/file-settings` aceita **`file_auto_approve`** (boolean) e `file_max_size_mb`. Ou seja, o passo de `approve` após cada `POST /files` **não é obrigatório por natureza** — é configuração de tenant. Rota sob `/admin/`, então provavelmente exige `platform_admin`: é um pedido a fazer ao time da AgentiX, não algo que o `tenant_admin` resolve sozinho.
