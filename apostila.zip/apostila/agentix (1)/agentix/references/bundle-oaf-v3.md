# Bundle OAF v3 — estrutura, autoria e pipeline de entrega

Fonte: repositório-template oficial `agx-v2-template` (owner `Bradesco-Core`), lido em 2026-08-19
a partir do clone `c:\Users\opereirm\labs\agentix\dvop-agx-ssol-encerramento-chamados-bex-access`
(HEAD `3d7b4ea`, ainda não customizado). Cobre `manifest_version: "3.0"` — o formato usado pelo
AgentiX v2. Todos os repositórios de bundle nascem deste template e recebem atualizações de CI
automaticamente via `repo-self-update.yaml`.

## Regra central: só `bundle/` é implantável

`AGENTS.md` da raiz, `.github/`, `docs/` e `examples/` **nunca** entram no pacote. Nada dentro de
`bundle/` pode depender, em tempo de execução, de arquivo fora de `bundle/`.

```text
bundle/
|-- PACKAGE.yaml            # manifesto: identidade + versão do bundle  (NÃO é manifest.yaml)
|-- README.md               # documentação entregue junto com o pacote
|-- constants.yaml          # constantes compartilhadas, não sensíveis
`-- <componente>/           # um diretório por executável
    |-- AGENTS.md           # definição do agente/workflow
    `-- skills/<skill>/
        |-- SKILL.md
        `-- scripts/<ferramenta>.py
```

Gotchas que quebram o CI:

- **Nunca crie `bundle/AGENTS.md`.** Cada executável tem o seu próprio `bundle/<componente>/AGENTS.md`.
- O nome do diretório da skill e o campo `name` do `SKILL.md` **devem coincidir**.
- Identificadores técnicos em minúsculas com hífen; não renomeie componente que já tenha consumidores.
- Sem credenciais, `.env` ou secrets resolvidos dentro de `bundle/`.

Vários componentes convivem no mesmo bundle (ex.: `atendimento-agent/`, `triagem-workflow/`,
`shared-skills/pesquisa/`), desde que compartilhem ciclo de vida e objetivo de negócio.

## `PACKAGE.yaml`

```yaml
manifest_version: "3.0"

metadata:
  name: agx-v2-template        # nome durável do bundle ao longo das versões
  version: "0.0.0"             # SemVer; primeira entrega real = 0.1.0
  author: Bradesco-Core
  description: >-
    Objetivo do bundle em uma frase.
  tags: [template, oaf-v3, reference]

execution:
  mode: worker
  timeout_seconds: 600

constants:
  template_name: agx-v2-template
```

`constants.yaml` na raiz do bundle espelha valores compartilhados não sensíveis. Secrets são apenas
*referenciados* pelo componente e configurados fora do código (ver `$(vault:...)` no `SKILL.md` da skill).

## `AGENTS.md` de componente (frontmatter real do template)

```yaml
---
name: template-agent
kind: agent                  # agent | workflow
version: 0.0.0               # SemVer próprio do componente
display_name: Agente de referência
description: Valida o bundle oficial OAF v3 e sua ferramenta de script local.
role: Assistente de validação de bundles Agentix
model: gpt-4o-mini
temperature: 0.1
max_tokens: 2048
skills:
  - name: template-tools
    provider: bundle         # skill local ao componente
tools:
  - template-tools.describe_bundle
markdown: true
show_tool_calls: true
max_rounds: 6
harnessConfig:
  agentix-agx:
    streaming: true
---
```

O frontmatter é o contrato técnico; o corpo Markdown é o comportamento (objetivo, regras numeradas,
ordem de execução, critérios de encerramento). `kind: workflow` declara `steps` no frontmatter, para
processos com sequência conhecida — não use workflow para esconder lógica que deveria ser ferramenta testável.

## `SKILL.md` de skill local

```yaml
---
name: template-tools
description: Inspeciona a estrutura instalada do bundle de referência.
version: 0.0.0
tools:
  - template-tools.describe_bundle
disclosure: standard
tags: [template, validation]
---
```

Nota de nomenclatura: a tool é declarada como `template-tools.describe_bundle` (ponto), mas o agente
a **invoca** como `template-tools_describe_bundle` (underscore) — conforme as instruções do agente de
referência do template.

Scripts de ferramenta devem: validar entradas, retornar dados estruturados, escrever erro útil em
`stderr`, sair com código diferente de zero em falha, evitar estado global e caminhos fixos da máquina
do dev, e nunca imprimir credenciais.

## Validação local antes do PR

```bash
python -m pip install packaging pyyaml
python -m compileall -q bundle
python -c 'import yaml; print(yaml.safe_load(open("bundle/PACKAGE.yaml"))["metadata"])'
```

Checklist: não existe `bundle/AGENTS.md`; cada executável tem `name`, `kind` e `version`; sem bytecode
ou temporários; YAMLs válidos; sem credenciais; nada referenciado fora de `bundle/`.

## Pipeline de entrega — artefatos imutáveis

```text
Pull request -> DEV -> label release-candidate -> HOM -> merge -> PRD
```

HOM e PRD **não recompilam** o conteúdo: promovem o mesmo artefato validado em DEV. Os callers em
`.github/workflows/` são finos e delegam a `Bradesco-Core/reusable-workflows`:

| Caller | Gatilho | Chama |
|---|---|---|
| `bundle-ci-dev.yaml` | PR opened/reopened/synchronize | `agentix-v2-bundle-build.yaml@latest` (`bundle-root: bundle`) + `agentix-v2-bundle-deploy.yaml@latest` (`environment: DEV`) |
| `bundle-ci-dev.yaml` | PR `labeled` = `release-candidate` | `agentix-v2-bundle-deploy.yaml@latest` (`environment: HOM`) |
| `bundle-promotion.yaml` | PR `closed` + merged + label presente | `agentix-v2-bundle-deploy.yaml@latest` (`environment: PRD`, `create-github-release: true`) |
| `repo-self-update.yaml` | `workflow_dispatch` / `repository_dispatch` | `files-update.yaml@main` — ressincroniza os próprios callers a partir de `reusable-callers/agentix-bundle` |

Variáveis de repositório consumidas: `vars.TENANT` e `vars.BUNDLE_NAME`. `secrets: inherit` em todos.
CODEOWNERS: `*` → `@Bradesco-Core/ssol-gh-agx-analista`; `.github/workflows` → `@Bradesco-Core/gh-dvp-bradesco-core`.

Armadilhas de promoção:

- Novo commit depois da label invalida a homologação — **remova e re-adicione** `release-candidate`.
- "HOM não encontrou a versão" = o commit atual não passou por DEV antes da label.
- Promoção bloqueada: não recrie nem renomeie artefatos manualmente; confirme incremento de versão,
  HOM concluído e que o PR promovido é o mesmo homologado.
- Nunca reutilize uma versão final para conteúdo diferente.

## Versionamento

SemVer em três níveis: `SKILL.md` → `AGENTS.md` → `PACKAGE.yaml`. Incremente a skill alterada, depois
o agente que a usa, depois o pacote conforme o **maior** impacto entre os componentes.
`PATCH` = correção de prompt/descrição/ferramenta; `MINOR` = nova skill/ferramenta/fluxo compatível;
`MAJOR` = remoção, renomeação ou mudança incompatível.

## Repositórios conhecidos derivados do template

- `dvop-agx-ssol-encerramento-chamados-bex-access` — encerramento de chamados BEX Access. Em
  2026-08-19 ainda era o template puro (`agx-v2-template` / `0.0.0` / `template-agent`), sem nenhum
  conteúdo do caso de uso.
- `dvop-agx-ssol-triagem` — agente de triagem, o alvo usado no teste end-to-end da API v1
  (ver `api-v1-guide.md`).
