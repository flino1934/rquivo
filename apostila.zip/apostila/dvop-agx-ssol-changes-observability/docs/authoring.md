# Como criar componentes

Este guia mostra como transformar o exemplo do template em um bundle real. A
regra central é simples: `bundle/` contém o produto; o restante do repositório
apoia seu desenvolvimento.

## 1. Defina o objetivo

Antes de editar arquivos, responda:

- Quem usará este componente?
- Qual problema ele resolve?
- Qual entrada recebe?
- Qual resultado deve entregar?
- Quais ações são proibidas ou exigem confirmação?

Use essas respostas na descrição e nas instruções. Um agente com escopo claro é
mais previsível que um agente descrito apenas como "assistente geral".

## 2. Configure o pacote

`bundle/PACKAGE.yaml` identifica o conjunto entregue:

```yaml
manifest_version: "3.0"

metadata:
  name: atendimento-digital
  version: "0.1.0"
  author: time-atendimento
  description: >-
    Agentes e skills para apoiar o atendimento digital.
  tags:
    - atendimento
    - suporte
```

O `name` identifica o bundle ao longo de suas versões. Escolha um nome durável,
em minúsculas e separado por hífens.

## 3. Crie um agente

Cada agente vive em um diretório próprio:

```text
bundle/<nome-do-agente>/AGENTS.md
```

Exemplo reduzido:

```markdown
---
name: atendimento-agent
kind: agent
version: 0.1.0
display_name: Assistente de atendimento
description: Orienta atendentes a partir da base interna.
role: Especialista em atendimento e políticas operacionais
model: gpt-4o-mini
temperature: 0.1
skills:
  - name: consulta-politicas
    provider: bundle
---

# Objetivo

Responda com base apenas nas políticas disponíveis.

# Regras

1. Confirme o assunto antes de consultar uma política.
2. Cite a fonte utilizada.
3. Se não encontrar orientação, informe a limitação.
4. Nunca invente procedimento ou prazo.
```

O frontmatter define o contrato técnico. O Markdown define o comportamento.
Evite instruções vagas; prefira regras observáveis, ordem de execução e critérios
de encerramento.

## 4. Crie um workflow

Escolha `kind: workflow` quando o processo tiver etapas conhecidas, por exemplo:

1. validar a entrada;
2. consultar uma fonte;
3. aplicar uma regra;
4. produzir um relatório.

Mantenha o workflow em `bundle/<nome>/AGENTS.md` e declare `steps` no
frontmatter. Dê a cada etapa uma responsabilidade e uma saída clara. Não use um
workflow para esconder lógica que deveria estar em uma ferramenta testável.

## 5. Crie uma skill

Uma skill deve explicar uma capacidade reutilizável:

```text
bundle/atendimento-agent/skills/consulta-politicas/
|-- SKILL.md
`-- scripts/
    `-- consultar.py
```

Exemplo de `SKILL.md`:

```markdown
---
name: consulta-politicas
description: Localiza orientações na base de políticas de atendimento.
version: 0.1.0
tools:
  - consulta-politicas.consultar
---

# Quando usar

Use esta skill quando a solicitação depender de uma política operacional.

# Resultado esperado

Retorne título, trecho relevante e identificação da fonte.
```

O diretório e o campo `name` devem coincidir. Descreva o gatilho de uso e o
formato esperado da resposta, não apenas a implementação interna.

## 6. Escreva ferramentas testáveis

Scripts devem:

- validar entradas;
- retornar dados estruturados quando possível;
- escrever erros úteis em `stderr`;
- usar código de saída diferente de zero em falhas;
- evitar estado global e caminhos fixos da máquina do desenvolvedor;
- nunca imprimir ou armazenar credenciais.

Teste cada script diretamente antes de depender dele em um agente.

## 7. Organize arquivos compartilhados

Use `bundle/constants.yaml` para valores não sensíveis compartilhados pelo
pacote. Documente em `bundle/README.md` qualquer convenção necessária para quem
mantém ou consome o bundle.

Não use constantes para credenciais. Secrets devem ser apenas referenciados pelo
componente e configurados fora do código.

## 8. Atualize versões

Use SemVer em `PACKAGE.yaml`, `AGENTS.md` e `SKILL.md`:

- `PATCH`: correção compatível;
- `MINOR`: nova capacidade compatível;
- `MAJOR`: mudança incompatível ou remoção.

Quando alterar uma skill, incremente a versão dela. Quando alterar um agente,
incremente a versão dele. Em seguida, ajuste a versão do pacote de acordo com o
maior impacto entre os componentes.

## 9. Revise o pacote

Antes de abrir o PR:

- confirme que não existe `bundle/AGENTS.md`;
- confirme que cada executável possui `name`, `kind` e `version`;
- remova arquivos temporários e bytecode;
- teste scripts e YAMLs;
- procure credenciais e dados sensíveis;
- verifique se tudo que o componente usa está dentro de `bundle/`.

## Próximo passo

Depois da validação local, siga o [guia de entrega](delivery.md) para publicar em
DEV e solicitar homologação.
