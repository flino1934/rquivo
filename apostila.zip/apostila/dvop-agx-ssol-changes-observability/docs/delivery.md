# Como entregar seu bundle

O template já inclui os workflows necessários. Para o autor do bundle, o fluxo
acontece pelo pull request e pela label de promoção; não é necessário publicar
arquivos manualmente.

## Visão geral

```text
Pull request -> DEV -> release-candidate -> HOM -> merge -> PRD
```

Cada etapa promove o conteúdo validado anteriormente. O pipeline não reconstrói
uma versão diferente durante a promoção.

## 1. Abra o pull request

Ao abrir ou atualizar o PR, o pipeline:

- valida a estrutura do bundle;
- verifica manifestos e versões;
- compila scripts Python;
- procura credenciais incluídas por engano;
- cria o pacote de forma determinística;
- publica e registra a versão em DEV.

Use DEV para conferir o comportamento do bundle, suas ferramentas e sua
documentação. Se precisar corrigir algo, envie um novo commit ao mesmo PR.

## 2. Confira o resultado de DEV

Antes de solicitar homologação:

- confirme que todos os checks passaram;
- abra o bundle no Agentix;
- confira nome, versão e componentes instalados;
- teste entradas normais e casos de erro;
- verifique se o agente respeita limites e instruções;
- revise a saída das ferramentas sem expor dados sensíveis.

O pipeline confirma a instalação e aprovação do bundle, mas não executa o agente
automaticamente. A avaliação funcional deve refletir o caso de uso real.

## 3. Solicite HOM

Quando DEV estiver aprovado, adicione a label `release-candidate` ao PR. Essa
ação solicita a promoção para HOM e pode depender de uma aprovação do ambiente.

Se você enviar outro commit depois disso, a versão anterior deixa de representar
o estado atual do PR. Remova e adicione novamente a label `release-candidate`
para homologar o novo commit.

Em HOM, valide:

- o fluxo completo com dados representativos;
- permissões e integrações esperadas;
- mensagens de erro e caminhos alternativos;
- compatibilidade com consumidores existentes;
- critérios de aceite definidos pelo time.

## 4. Promova para PRD

Depois que HOM estiver aprovado, conclua o PR conforme o processo do seu time. A
promoção para PRD só aceita o mesmo bundle e a mesma versão homologados.

Uma entrega bem-sucedida gera uma versão rastreável e uma GitHub Release com o
pacote e seus metadados de integridade.

## Correções durante o fluxo

### O check de DEV falhou

Abra o step que falhou e corrija a causa indicada. Erros comuns:

- YAML inválido;
- versão não incrementada;
- componente sem `name` ou `version`;
- script Python com erro de sintaxe;
- arquivo sensível incluído no bundle.

Envie um novo commit. O PR executará a validação novamente.

### HOM não encontrou a versão

Confirme se o último commit do PR passou por DEV antes da inclusão da label. Se
o PR mudou após a primeira homologação, remova e adicione novamente
`release-candidate`.

### A promoção foi bloqueada

Não tente recriar ou renomear artefatos manualmente. Confirme que a versão do
pacote foi incrementada, que HOM terminou com sucesso e que o PR promovido é o
mesmo que foi homologado.

## Estratégia de versão

Planeje a versão antes de solicitar HOM:

| Situação | Incremento sugerido |
|---|---|
| Correção de prompt, descrição ou ferramenta | `PATCH` |
| Nova skill, ferramenta ou fluxo compatível | `MINOR` |
| Remoção, renomeação ou mudança incompatível | `MAJOR` |

Não reutilize uma versão final para conteúdo diferente. A imutabilidade permite
saber exatamente o que foi testado e entregue.

## Checklist de promoção

- [ ] O PR contém apenas mudanças relacionadas à entrega.
- [ ] Os checks de DEV passaram no commit atual.
- [ ] O bundle foi testado com entradas representativas.
- [ ] As versões dos componentes foram incrementadas.
- [ ] A versão do `PACKAGE.yaml` corresponde ao impacto da mudança.
- [ ] Não existem credenciais ou dados sensíveis no pacote.
- [ ] A label `release-candidate` foi aplicada ao commit atual.
- [ ] A homologação foi concluída antes do merge.
