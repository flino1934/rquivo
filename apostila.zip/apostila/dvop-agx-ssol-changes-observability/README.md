# Template de bundle Agentix

Um ponto de partida prático para criar, organizar e publicar agentes, workflows
e skills no Agentix.

Este repositório já traz um bundle mínimo funcional. Use o exemplo para entender
o formato, substitua o conteúdo pelo seu caso de uso e evolua um componente por
vez.

## Comece aqui

1. Crie seu repositório a partir deste template.
2. Renomeie o bundle em `bundle/PACKAGE.yaml`.
3. Renomeie `bundle/template-agent/` para o nome do seu primeiro componente.
4. Edite o `AGENTS.md` do componente com papel, instruções, modelo e ferramentas.
5. Adicione ou remova skills conforme a necessidade do agente.
6. Execute as verificações locais.
7. Abra um pull request para validar e publicar em DEV.

> Tudo que será entregue ao Agentix deve ficar em `bundle/`. Documentação do
> projeto, exemplos auxiliares e automações permanecem fora desse diretório.

## O que você vai editar

```text
bundle/
|-- PACKAGE.yaml                       # identidade e versão do bundle
|-- README.md                          # documentação entregue com o pacote
|-- constants.yaml                     # constantes compartilhadas
`-- template-agent/                    # um componente
    |-- AGENTS.md                      # definição e instruções do agente
    `-- skills/
        `-- template-tools/
            |-- SKILL.md               # descrição e contrato da skill
            `-- scripts/
                `-- describe_bundle.py # implementação de uma ferramenta
```

Você pode ter vários componentes no mesmo bundle:

```text
bundle/
|-- PACKAGE.yaml
|-- atendimento-agent/
|   `-- AGENTS.md
|-- triagem-workflow/
|   `-- AGENTS.md
`-- shared-skills/
    `-- pesquisa/
        `-- SKILL.md
```

Não crie `bundle/AGENTS.md`. Cada agente ou workflow deve possuir seu próprio
`bundle/<componente>/AGENTS.md`.

## Escolha seu componente

### Agente

Use `kind: agent` para um componente que recebe instruções, escolhe ferramentas
e produz uma resposta. Comece pelo arquivo
`bundle/template-agent/AGENTS.md`.

Personalize principalmente:

- `name`: identificador técnico estável;
- `display_name`: nome apresentado às pessoas;
- `description`: objetivo do agente;
- `role`: comportamento e especialidade esperados;
- `model`: modelo utilizado;
- corpo Markdown: instruções, limites e critérios de sucesso;
- `skills` e `tools`: capacidades disponíveis.

### Workflow

Use `kind: workflow` quando o processo tiver uma sequência explícita e
previsível de etapas. Um workflow usa a mesma organização por diretório e possui
seu próprio `AGENTS.md`, mas declara seus `steps` em vez de depender apenas da
decisão autônoma de um agente.

### Skill

Uma skill reúne conhecimento, instruções e ferramentas reutilizáveis. Mantenha
cada skill próxima do componente que a utiliza:

```text
<componente>/skills/<nome-da-skill>/SKILL.md
<componente>/skills/<nome-da-skill>/scripts/<ferramenta>.py
```

O diretório e o campo `name` do `SKILL.md` devem ter o mesmo nome. Descreva
claramente quando usar a skill, quais entradas ela espera e o que ela retorna.

## Personalize o bundle

Em `bundle/PACKAGE.yaml`, altere pelo menos:

```yaml
metadata:
  name: meu-bundle
  version: "0.1.0"
  author: meu-time
  description: >-
    Objetivo do bundle em uma frase clara.
  tags:
    - meu-dominio
```

Use nomes em minúsculas e com hífen para identificadores técnicos. Evite
renomear um componente depois que ele já tiver consumidores.

## Valide antes do pull request

```bash
python -m pip install packaging pyyaml
python -m compileall -q bundle
python -c 'import yaml; print(yaml.safe_load(open("bundle/PACKAGE.yaml"))["metadata"])'
```

Também teste diretamente qualquer script adicionado às skills. Uma ferramenta
deve produzir uma saída clara, falhar com mensagem útil e nunca depender de
credenciais gravadas no código.

## Publique com segurança

O fluxo normal é simples:

1. Abra ou atualize um pull request para construir e validar o bundle em DEV.
2. Teste a versão publicada no Agentix.
3. Quando estiver pronta para homologação, adicione a label
   `release-candidate`.
4. Após a homologação, conclua o pull request para promover a mesma versão.

O pipeline promove artefatos imutáveis. HOM e PRD não recompilam silenciosamente
o conteúdo que foi validado em DEV.

## Versione mudanças

O bundle e seus componentes usam SemVer: `MAJOR.MINOR.PATCH`.

| Mudança | Exemplo | Incremento |
|---|---|---|
| Correção sem alterar contrato | Ajustar uma instrução incorreta | `PATCH` |
| Nova capacidade compatível | Adicionar uma ferramenta | `MINOR` |
| Mudança incompatível | Remover ou alterar um contrato existente | `MAJOR` |

Atualize a versão de cada componente alterado e depois a versão de
`bundle/PACKAGE.yaml`. Na primeira entrega, use `0.1.0`.

## Boas práticas

- Escreva instruções objetivas e verificáveis.
- Diga ao agente o que fazer e também o que não fazer.
- Prefira skills pequenas, com uma responsabilidade clara.
- Mantenha exemplos próximos do contrato que explicam.
- Não inclua tokens, senhas, chaves ou arquivos `.env` no bundle.
- Não dependa de arquivos que estejam fora de `bundle/` em tempo de execução.
- Incremente a versão sempre que alterar comportamento ou contrato.

## Guias

- [Como criar agentes, workflows e skills](docs/authoring.md)
- [Como o bundle percorre DEV, HOM e PRD](docs/delivery.md)
- [Exemplos e caminhos para evolução](examples/README.md)
- [Conteúdo do pacote de referência](bundle/README.md)

## Checklist do primeiro PR

- [ ] Renomeei o bundle e o componente de exemplo.
- [ ] Atualizei descrição, autor e tags.
- [ ] Escrevi instruções específicas para o meu caso de uso.
- [ ] Removi ferramentas e skills que não serão utilizadas.
- [ ] Testei os scripts localmente.
- [ ] Conferi as versões do bundle e dos componentes.
- [ ] Revisei `bundle/` para garantir que não há credenciais.
