# Ideias para evoluir o template

O exemplo funcional está em `bundle/template-agent`. Use os cenários abaixo como
roteiro para transformá-lo em um componente real.

## Agente com conhecimento especializado

1. Renomeie `template-agent` para o domínio desejado.
2. Atualize `name`, `display_name`, `description` e `role`.
3. Escreva regras sobre fontes permitidas, limites e formato da resposta.
4. Crie uma skill para cada capacidade independente.

Exemplos: políticas internas, atendimento, análise de documentos ou apoio a
desenvolvimento.

## Agente com ferramentas

Use `template-tools` como referência para uma skill que expõe scripts. Uma boa
ferramenta recebe entradas simples, retorna dados estruturados e trata erros sem
expor detalhes sensíveis.

Exemplos: consultar catálogo, validar conteúdo, resumir arquivos ou preparar um
relatório.

## Workflow previsível

Crie um componente com `kind: workflow` quando a ordem das etapas fizer parte do
contrato. Modele validação, processamento e apresentação como passos separados.

Exemplos: triagem, revisão, enriquecimento e aprovação de uma solicitação.

## Mais de um componente

Um bundle pode reunir componentes relacionados. Evite transformar o pacote em
um catálogo sem coesão: mantenha juntos apenas agentes, workflows e skills que
tenham o mesmo ciclo de vida e objetivo de negócio.

Os arquivos deste diretório servem apenas como documentação e nunca entram no
pacote publicado.
