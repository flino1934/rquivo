# Instruções do repositório

Este repositório é a referência oficial para construir e promover um bundle
Agentix OAF v3.

Somente `bundle/` é implantável. Nunca inclua este `AGENTS.md`, `.github/`,
`docs/` ou `examples/` no pacote.

Regras do bundle:

- mantenha o manifesto em `bundle/PACKAGE.yaml`;
- defina executáveis em `bundle/<componente>/AGENTS.md`;
- mantenha skills locais em `bundle/<componente>/skills/<skill>/SKILL.md`;
- nunca crie `bundle/AGENTS.md`;
- informe no `PACKAGE.yaml` a versão SemVer final pretendida;
- não inclua credenciais nem valores resolvidos de secrets;
- preserve a separação entre conteúdo implantável e documentação do repositório.

Os callers devem permanecer pequenos. A implementação de CI/CD pertence aos
workflows reutilizáveis em `Bradesco-Core/reusable-workflows`.
