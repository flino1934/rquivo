# Meu bundle Agentix

Este diretório é o pacote entregue ao Agentix. Substitua este texto pela
documentação útil para quem mantém e utiliza o seu bundle.

## Objetivo

Explique em poucas frases:

- qual problema o bundle resolve;
- para quem ele foi criado;
- quais agentes, workflows e skills oferece;
- quais resultados podem ser esperados.

## Componentes

O template inclui:

- `template-agent/AGENTS.md`: agente mínimo de referência;
- `template-agent/skills/template-tools`: skill local com script de exemplo;
- `constants.yaml`: valores não sensíveis compartilhados pelo pacote.

Renomeie ou remova esses itens ao adaptar o template. Liste aqui os componentes
reais e descreva a responsabilidade de cada um.

## Como usar

Documente exemplos de solicitação e resultado esperado:

```text
Entrada: descreva uma solicitação típica
Saída: descreva a resposta ou ação esperada
```

Inclua também limites conhecidos, pré-requisitos e situações em que o componente
não deve ser utilizado.

## Manutenção

Ao alterar comportamento, atualize a versão do componente correspondente e a
versão do pacote. Nunca inclua credenciais ou dados sensíveis neste diretório.
