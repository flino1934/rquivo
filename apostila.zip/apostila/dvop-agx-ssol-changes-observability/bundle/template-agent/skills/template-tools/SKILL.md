---
name: template-tools
description: Inspeciona a estrutura instalada do bundle de referência.
version: 0.0.0
tools:
  - template-tools.describe_bundle
disclosure: standard
tags:
  - template
  - validation
---

# Ferramentas do template

Use esta skill para verificar o pacote e a estrutura local do componente em
tempo de execução.
