#!/usr/bin/env python3

from __future__ import annotations

import json
from pathlib import Path


def main() -> int:
    root = Path(".")
    manifests = sorted(str(path) for path in root.glob("*/AGENTS.md"))
    skills = sorted(str(path) for path in root.glob("*/skills/*/SKILL.md"))
    print(
        json.dumps(
            {
                "has_package": (root / "PACKAGE.yaml").is_file(),
                "component_manifests": manifests,
                "component_skills": skills,
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
